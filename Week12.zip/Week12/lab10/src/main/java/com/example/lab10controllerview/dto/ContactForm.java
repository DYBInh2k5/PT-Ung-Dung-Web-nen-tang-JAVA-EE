package com.example.lab10controllerview.dto;

/**
 * DTO nhận dữ liệu từ form liên hệ.
 *
 * DTO giúp Controller nhận dữ liệu form theo một object rõ ràng,
 * thay vì nhận nhiều biến rời rạc bằng @RequestParam.
 */
public class ContactForm {

    // Họ tên người nhập form.
    private String fullName;

    // Email người nhập form.
    private String email;

    // Nội dung người dùng gửi.
    private String message;

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
