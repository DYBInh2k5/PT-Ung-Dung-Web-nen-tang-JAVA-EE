package com.example.lab10controllerview.controller;

import com.example.lab10controllerview.dto.ContactForm;
import com.example.lab10controllerview.model.Product;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Controller minh họa các cách truyền dữ liệu từ Controller sang Thymeleaf View.
 *
 * Các cách được minh họa:
 * 1. Model              - /lab10/model
 * 2. ModelMap           - /lab10/model-map
 * 3. ModelAndView       - /lab10/model-and-view
 * 4. @ModelAttribute    - /lab10/form  (GET + POST)
 * 5. RedirectAttributes - /lab10/flash (POST -> redirect)
 * 6. HttpSession        - /lab10/session
 * 7. HttpServletRequest - /lab10/request
 */
@Controller
public class Lab10Controller {

    // Dữ liệu mẫu trong bộ nhớ để lab không cần database.
    private final List<Product> products = List.of(
            new Product(1L, "Laptop Dell", new BigDecimal("18500000")),
            new Product(2L, "Chuột Logitech", new BigDecimal("350000")),
            new Product(3L, "Bàn phím cơ", new BigDecimal("1200000"))
    );

    /**
     * Tạo dữ liệu dùng chung cho nhiều View trong Controller này.
     * Method này được gọi tự động trước mỗi request handler trong class này.
     *
     * @return tên môn học được tự động đưa vào Model với key courseName
     */
    @ModelAttribute("courseName")
    public String courseName() {
        return "J2EE Spring Boot";
    }

    /**
     * Chuyển request trang chủ sang trang chính của lab.
     *
     * @return redirect đến /lab10
     */
    @GetMapping("/")
    public String home() {
        return "redirect:/lab10";
    }

    /**
     * Hiển thị trang menu các ví dụ truyền dữ liệu.
     *
     * @param model dùng để gửi tiêu đề trang sang View
     * @return tên template index.html
     */
    @GetMapping("/lab10")
    public String index(Model model) {
        model.addAttribute("pageTitle", "Lab10 - Controller sang View");
        return "index";
    }

    // CÁCH 1: Model
    @GetMapping("/lab10/model")
    public String useModel(Model model) {
        model.addAttribute("pageTitle", "Cách 1: Dùng Model");
        model.addAttribute("products", products);
        model.addAttribute("note", "Model phù hợp cho dữ liệu của request hiện tại.");
        return "demo";
    }

    // CÁCH 2: ModelMap
    @GetMapping("/lab10/model-map")
    public String useModelMap(ModelMap modelMap) {
        modelMap.addAttribute("pageTitle", "Cách 2: Dùng ModelMap");
        modelMap.addAttribute("products", products);
        modelMap.addAttribute("note", "ModelMap có thể dùng addAttribute giống Model.");
        return "demo";
    }

    // CÁCH 3: ModelAndView
    @GetMapping("/lab10/model-and-view")
    public ModelAndView useModelAndView() {
        ModelAndView mav = new ModelAndView("demo");
        mav.addObject("pageTitle", "Cách 3: Dùng ModelAndView");
        mav.addObject("products", products);
        mav.addObject("note", "ModelAndView gom cả model data và view name trong một object.");
        return mav;
    }

    // CÁCH 4: @ModelAttribute với Form - GET
    @GetMapping("/lab10/form")
    public String showForm(Model model) {
        model.addAttribute("contactForm", new ContactForm());
        return "form";
    }

    // CÁCH 4: @ModelAttribute với Form - POST
    @PostMapping("/lab10/form")
    public String submitForm(@ModelAttribute("contactForm") ContactForm contactForm, Model model) {
        model.addAttribute("pageTitle", "Kết quả submit form");
        model.addAttribute("submittedForm", contactForm);
        return "result";
    }

    // CÁCH 5: RedirectAttributes + FlashMap - POST
    @PostMapping("/lab10/flash")
    public String flashMessage(RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("message",
                "Thông báo này đi qua FlashMap và chỉ tồn tại ngắn hạn.");
        return "redirect:/lab10/flash-result";
    }

    // CÁCH 5: RedirectAttributes + FlashMap - GET result
    @GetMapping("/lab10/flash-result")
    public String flashResult() {
        return "flash-result";
    }

    // CÁCH 6: HttpSession
    @GetMapping("/lab10/session")
    public String useSession(HttpSession session, Model model) {
        Integer count = (Integer) session.getAttribute("visitCount");
        if (count == null) {
            count = 0;
        }
        count++;
        session.setAttribute("visitCount", count);
        model.addAttribute("pageTitle", "Cách 6: Dùng HttpSession");
        model.addAttribute("visitCount", count);
        model.addAttribute("sessionId", session.getId());
        return "session";
    }

    // CÁCH 7: HttpServletRequest
    @GetMapping("/lab10/request")
    public String useRequest(HttpServletRequest request) {
        request.setAttribute("pageTitle", "Cách 7: Dùng HttpServletRequest");
        request.setAttribute("message", "Dữ liệu này được đặt bằng request.setAttribute().");
        request.setAttribute("serverTime", LocalDateTime.now());
        return "request";
    }
}
