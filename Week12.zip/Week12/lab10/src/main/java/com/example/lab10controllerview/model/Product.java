package com.example.lab10controllerview.model;

import java.math.BigDecimal;

/**
 * Mô tả một sản phẩm mẫu để hiển thị trên View.
 *
 * Class này chỉ dùng dữ liệu tĩnh trong bộ nhớ, không ánh xạ database.
 */
public class Product {

    // ID mẫu giúp View có dữ liệu để hiển thị trong bảng.
    private Long id;

    // Tên sản phẩm mẫu.
    private String name;

    // BigDecimal phù hợp để biểu diễn tiền tệ hơn double/float.
    private BigDecimal price;

    /**
     * Khởi tạo sản phẩm mẫu.
     *
     * @param id    mã sản phẩm
     * @param name  tên sản phẩm
     * @param price giá sản phẩm
     */
    public Product(Long id, String name, BigDecimal price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getPrice() {
        return price;
    }
}
