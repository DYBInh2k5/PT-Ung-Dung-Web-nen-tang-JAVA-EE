package com.example.lab10controllerview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Điểm khởi động của ứng dụng Lab10 - Controller sang View.
 *
 * Lab này minh họa các cách truyền dữ liệu từ Controller sang Thymeleaf View:
 * Model, ModelMap, ModelAndView, @ModelAttribute, RedirectAttributes,
 * HttpSession, HttpServletRequest.
 */
@SpringBootApplication
public class Lab10ControllerViewApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab10ControllerViewApplication.class, args);
    }
}
