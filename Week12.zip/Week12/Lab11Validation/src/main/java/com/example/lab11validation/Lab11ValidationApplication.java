package com.example.lab11validation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab11ValidationApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab11ValidationApplication.class, args);
    }

}
