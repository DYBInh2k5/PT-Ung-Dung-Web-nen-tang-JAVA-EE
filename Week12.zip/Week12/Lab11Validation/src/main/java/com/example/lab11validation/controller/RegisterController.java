package com.example.lab11validation.controller;

import com.example.lab11validation.dto.RegisterForm;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * Controller xử lý form đăng ký để minh họa @Valid và BindingResult.
 */
@Controller
public class RegisterController {

    /**
     * Chuyển trang chủ sang form đăng ký.
     *
     * @return redirect đến /register
     */
    @GetMapping("/")
    public String home() {
        return "redirect:/register";
    }

    /**
     * Hiển thị form đăng ký rỗng.
     *
     * @param model dùng để gửi registerForm sang Thymeleaf
     * @return tên template register.html
     */
    @GetMapping("/register")
    public String showForm(Model model) {
        // Form cần object này để th:object="${registerForm}" hoạt động.
        model.addAttribute("registerForm", new RegisterForm());
        return "register";
    }

    /**
     * Nhận dữ liệu đăng ký, chạy validation và hiển thị kết quả.
     *
     * @param registerForm  object được bind từ form và được kiểm tra bởi @Valid
     * @param bindingResult nơi chứa lỗi validation của registerForm
     * @param model         dùng để gửi dữ liệu hợp lệ sang trang success
     * @return register.html nếu có lỗi, success.html nếu dữ liệu hợp lệ
     */
    @PostMapping("/register")
    public String submitForm(@Valid @ModelAttribute("registerForm") RegisterForm registerForm,
                             BindingResult bindingResult,
                             Model model) {

        // Validation nghiệp vụ: chỉ chấp nhận email thuộc domain trường.
        if (registerForm.getEmail() != null
                && !registerForm.getEmail().isBlank()
                && !registerForm.getEmail().endsWith("@hoasen.edu.vn")) {
            // rejectValue thêm lỗi vào field email để th:errors="*{email}" hiển thị được.
            bindingResult.rejectValue("email", "email.domain", "Email phải thuộc domain @hoasen.edu.vn");
        }

        // Nếu có lỗi, trả lại form để người dùng sửa dữ liệu.
        if (bindingResult.hasErrors()) {
            return "register";
        }

        // Khi hợp lệ, gửi dữ liệu sang trang success.
        model.addAttribute("registerForm", registerForm);
        return "success";
    }
}
