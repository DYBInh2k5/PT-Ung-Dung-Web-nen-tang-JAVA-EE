package com.example.lab11validation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab11ValidationApplicationTests {

    @Test
    void contextLoads() {
    }

}
