package com.example.lab12uploadexception.service;

import com.example.lab12uploadexception.exception.FileUploadException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Service xử lý lưu, đọc và kiểm tra file upload.
 *
 * Tách logic file ra khỏi Controller giúp Controller chỉ tập trung nhận request và trả response.
 */
@Service
public class FileStorageService {

    // Chỉ cho phép các đuôi file ảnh phổ biến.
    private static final Set<String> ALLOWED_EXTENSIONS = Set.of("jpg", "jpeg", "png", "webp");

    // Kiểm tra thêm Content-Type để giảm rủi ro user đổi đuôi file giả.
    private static final Set<String> ALLOWED_CONTENT_TYPES = Set.of(
            "image/jpeg", "image/png", "image/webp"
    );

    // Đọc thư mục upload từ application.properties, có giá trị mặc định nếu không cấu hình.
    @Value("${app.upload-dir:uploads/gallery}")
    private String uploadDir;

    /**
     * Lưu file ảnh vào thư mục upload.
     *
     * @param file file người dùng gửi lên từ form
     * @return tên file mới sau khi lưu thành công
     */
    public String store(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new FileUploadException("Vui lòng chọn file ảnh");
        }

        // Kiểm tra file trước khi ghi xuống ổ đĩa.
        validateImage(file);

        // Lấy tên file đã được làm sạch để đọc extension.
        String cleanName = getSafeOriginalName(file);
        String extension = StringUtils.getFilenameExtension(cleanName);

        // Dùng UUID để tránh trùng tên file và không phụ thuộc tên file gốc.
        String savedName = UUID.randomUUID() + "." + extension.toLowerCase(Locale.ROOT);

        try {
            Path uploadPath = getUploadPath();
            // Tạo thư mục upload nếu chưa tồn tại.
            Files.createDirectories(uploadPath);

            // normalize giúp chuẩn hóa đường dẫn trước khi ghi file.
            Path target = uploadPath.resolve(savedName).normalize();
            try (InputStream inputStream = file.getInputStream()) {
                Files.copy(inputStream, target, StandardCopyOption.REPLACE_EXISTING);
            }
            return savedName;
        } catch (IOException ex) {
            throw new FileUploadException("Không thể lưu file upload", ex);
        }
    }

    /**
     * Lấy danh sách tên file ảnh đã upload.
     *
     * @return danh sách tên file, sắp xếp theo alphabet
     */
    public List<String> listImages() {
        Path uploadPath = getUploadPath();
        if (!Files.exists(uploadPath)) {
            return List.of();
        }
        try {
            return Files.list(uploadPath)
                    .filter(Files::isRegularFile)
                    .map(path -> path.getFileName().toString())
                    .sorted()
                    .toList();
        } catch (IOException ex) {
            throw new FileUploadException("Không thể đọc danh sách file", ex);
        }
    }

    /**
     * Đọc một file ảnh dưới dạng Resource để Controller trả về browser.
     *
     * @param fileName tên file cần đọc
     * @return Resource đại diện cho file ảnh
     */
    public Resource loadAsResource(String fileName) {
        try {
            Path uploadPath = getUploadPath();
            Path filePath = uploadPath.resolve(fileName).normalize();

            // Chặn path traversal, ví dụ ../../application.properties.
            if (!filePath.startsWith(uploadPath)) {
                throw new FileUploadException("Tên file không hợp lệ");
            }

            Resource resource = new UrlResource(filePath.toUri());
            if (!resource.exists() || !resource.isReadable()) {
                throw new FileUploadException("Không tìm thấy file: " + fileName);
            }
            return resource;
        } catch (MalformedURLException ex) {
            throw new FileUploadException("Không thể đọc file: " + fileName, ex);
        }
    }

    /**
     * Kiểm tra file upload có phải ảnh hợp lệ không.
     *
     * @param file file cần kiểm tra
     */
    private void validateImage(MultipartFile file) {
        String cleanName = getSafeOriginalName(file);
        String extension = StringUtils.getFilenameExtension(cleanName);
        String contentType = file.getContentType();

        if (extension == null || !ALLOWED_EXTENSIONS.contains(extension.toLowerCase(Locale.ROOT))) {
            throw new FileUploadException("Chỉ cho phép file jpg, jpeg, png, webp");
        }
        if (contentType == null || !ALLOWED_CONTENT_TYPES.contains(contentType)) {
            throw new FileUploadException("Content-Type của file không hợp lệ");
        }
    }

    /**
     * Lấy và làm sạch tên file gốc.
     *
     * @param file file upload cần đọc tên
     * @return tên file đã được cleanPath
     */
    private String getSafeOriginalName(MultipartFile file) {
        String originalName = file.getOriginalFilename();
        if (!StringUtils.hasText(originalName)) {
            throw new FileUploadException("Tên file không hợp lệ");
        }
        return StringUtils.cleanPath(originalName);
    }

    /**
     * Lấy đường dẫn tuyệt đối tới thư mục upload.
     *
     * @return Path đã được normalize
     */
    private Path getUploadPath() {
        return Paths.get(uploadDir).toAbsolutePath().normalize();
    }
}
