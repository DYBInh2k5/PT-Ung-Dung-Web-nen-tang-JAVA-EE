package com.example.lab12uploadexception.controller;

import com.example.lab12uploadexception.exception.FileUploadException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

/**
 * Class xử lý lỗi tập trung cho toàn bộ Controller trong ứng dụng.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Xử lý lỗi upload file không hợp lệ.
     *
     * @param ex    exception chứa message lỗi upload
     * @param model dùng để gửi thông tin lỗi sang View
     * @return tên template lỗi tùy chỉnh
     */
    @ExceptionHandler(FileUploadException.class)
    public String handleFileUpload(FileUploadException ex, Model model) {
        model.addAttribute("status", 400);
        model.addAttribute("title", "File upload không hợp lệ");
        model.addAttribute("message", ex.getMessage());
        return "error/custom-error";
    }

    /**
     * Xử lý lỗi file vượt quá dung lượng cấu hình.
     *
     * @param ex    exception do Spring ném ra khi file quá lớn
     * @param model dùng để gửi thông tin lỗi sang View
     * @return tên template lỗi tùy chỉnh
     */
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public String handleMaxUploadSize(MaxUploadSizeExceededException ex, Model model) {
        model.addAttribute("status", 400);
        model.addAttribute("title", "File quá lớn");
        model.addAttribute("message", "Dung lượng file vượt quá giới hạn 2MB");
        return "error/custom-error";
    }

    /**
     * Xử lý các lỗi còn lại để tránh Whitelabel Error Page.
     *
     * @param ex    exception bất kỳ chưa được xử lý bởi method cụ thể hơn
     * @param model dùng để gửi thông tin lỗi sang View
     * @return tên template lỗi tùy chỉnh
     */
    @ExceptionHandler(Exception.class)
    public String handleGeneralException(Exception ex, Model model) {
        model.addAttribute("status", 500);
        model.addAttribute("title", "Lỗi hệ thống");
        model.addAttribute("message", "Ứng dụng gặp lỗi ngoài dự kiến");
        return "error/custom-error";
    }
}
