package com.example.lab12uploadexception.exception;

/**
 * Exception đại diện cho lỗi upload file.
 *
 * Tạo exception riêng giúp ControllerAdvice phân biệt lỗi upload với lỗi hệ thống khác.
 */
public class FileUploadException extends RuntimeException {

    /**
     * Tạo lỗi upload với message ngắn gọn.
     *
     * @param message nội dung lỗi hiển thị cho người dùng
     */
    public FileUploadException(String message) {
        super(message);
    }

    /**
     * Tạo lỗi upload có kèm exception gốc.
     *
     * @param message nội dung lỗi hiển thị cho người dùng
     * @param cause   exception gốc phát sinh trong quá trình xử lý file
     */
    public FileUploadException(String message, Throwable cause) {
        super(message, cause);
    }
}
