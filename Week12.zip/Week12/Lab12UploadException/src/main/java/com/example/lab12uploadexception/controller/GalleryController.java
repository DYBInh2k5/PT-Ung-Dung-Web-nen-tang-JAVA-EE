package com.example.lab12uploadexception.controller;

import com.example.lab12uploadexception.service.FileStorageService;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.nio.file.Files;

/**
 * Controller xử lý trang gallery, upload file và trả ảnh đã upload.
 */
@Controller
public class GalleryController {

    private final FileStorageService fileStorageService;

    /**
     * Inject FileStorageService để Controller không tự xử lý logic file.
     *
     * @param fileStorageService service lưu và đọc file
     */
    public GalleryController(FileStorageService fileStorageService) {
        this.fileStorageService = fileStorageService;
    }

    /**
     * Chuyển trang chủ sang gallery.
     *
     * @return redirect đến /gallery
     */
    @GetMapping("/")
    public String home() {
        return "redirect:/gallery";
    }

    /**
     * Hiển thị form upload và danh sách ảnh.
     *
     * @param model dùng để gửi danh sách ảnh sang View
     * @return tên template gallery.html
     */
    @GetMapping("/gallery")
    public String gallery(Model model) {
        model.addAttribute("images", fileStorageService.listImages());
        return "gallery";
    }

    /**
     * Nhận file upload từ form và lưu vào thư mục local.
     *
     * @param imageFile          file ảnh được gửi từ input name="imageFile"
     * @param redirectAttributes dùng để gửi thông báo thành công sau redirect
     * @return redirect về gallery
     */
    @PostMapping("/gallery/upload")
    public String upload(@RequestParam("imageFile") MultipartFile imageFile,
                         RedirectAttributes redirectAttributes) {
        String savedName = fileStorageService.store(imageFile);
        redirectAttributes.addFlashAttribute("message", "Upload thành công: " + savedName);
        return "redirect:/gallery";
    }

    /**
     * Trả file ảnh đã upload cho browser.
     *
     * @param fileName tên file ảnh cần hiển thị
     * @return response chứa nội dung file ảnh
     * @throws IOException khi không đọc được content type của file
     */
    @GetMapping("/uploads/gallery/{fileName:.+}")
    public ResponseEntity<Resource> image(@PathVariable String fileName) throws IOException {
        Resource resource = fileStorageService.loadAsResource(fileName);
        // probeContentType giúp browser biết đây là image/jpeg, image/png...
        String contentType = Files.probeContentType(resource.getFile().toPath());
        if (contentType == null) {
            contentType = MediaType.APPLICATION_OCTET_STREAM_VALUE;
        }
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .body(resource);
    }

    /**
     * Tạo lỗi chủ động để kiểm tra GlobalExceptionHandler.
     *
     * @return không trả về View vì method luôn ném exception
     */
    @GetMapping("/error-demo")
    public String errorDemo() {
        throw new IllegalStateException("Lỗi demo để kiểm tra @ControllerAdvice");
    }
}
