package com.example.lab12uploadexception;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab12UploadExceptionApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab12UploadExceptionApplication.class, args);
    }

}
