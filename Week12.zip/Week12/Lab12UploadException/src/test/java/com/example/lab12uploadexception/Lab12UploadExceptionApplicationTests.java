package com.example.lab12uploadexception;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab12UploadExceptionApplicationTests {

    @Test
    void contextLoads() {
    }

}
