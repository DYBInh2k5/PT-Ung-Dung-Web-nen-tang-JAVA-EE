# JPA Query Exercise - Bài Thực Hành Truy Vấn JPA

## ⚠️ Thông Tin Cập Nhật (v2.0)

**Những thay đổi so với spec ban đầu:**

| Yếu Tố | Cũ | Mới | Lý Do |
|--------|----|----|-------|
| **Toy.description** | Có | Thay đổi thành `name` | Field tên sản phẩm nên dùng `name` cho rõ ràng |
| **ID Auto-increment** | Manual (1, 2, 3...) | `@GeneratedValue(IDENTITY)` | Database tự sinh ID, best practice |
| **Price range** | 15-120 | 10.0-100.0 | Thỏa mãn spec (10.0 đến 100.0) |
| **Dữ liệu** | 20 toys tên thực tế | 20 toys tên thực tế (giá điều chỉnh) | Phù hợp với yêu cầu |

**Code đã được cập nhật:**
- ✅ `Toy.java`: `description` → `name`, thêm `@GeneratedValue`
- ✅ `Brand.java`: Thêm `@GeneratedValue`
- ✅ `ToyService.java`: Cập nhật tất cả references, thêm comments chi tiết (12 bài)
- ✅ `JpaQueryServlet.java`: Cập nhật getDescription() → getName()
- ✅ `CrudServlet.java`: Cập nhật form và table

---



Sau hoàn thành bài này, bạn sẽ hiểu:
- ✅ Cách viết truy vấn JPA với **WHERE**
- ✅ Cách sắp xếp dữ liệu với **ORDER BY**
- ✅ Cách viết **Native Query** (SQL thuần)
- ✅ Cách thực hiện **JOIN** giữa các entity
- ✅ Cách kết hợp nhiều điều kiện (**AND/OR**)

---

## 🗂️ Cấu Trúc Project

```
BtThuc/
├── src/java/
│   ├── entity/
│   │   ├── Toy.java           ← Entity đồ chơi
│   │   ├── Brand.java          ← Entity hãng
│   │   └── ToyService.java     ← Service chứa tất cả query
│   ├── servlet/
│   │   └── JpaQueryServlet.java ← Servlet hiển thị kết quả
│   └── util/
│       └── JPAUtil.java        ← Utility để khởi động JPA
├── src/conf/
│   └── persistence.xml         ← Cấu hình kết nối database
└── sql/
    ├── Toyz.sql                ← Script tạo bảng
    └── MoreData.sql            ← Script thêm dữ liệu
```

---

## 🚀 Cách Chạy

### 1️⃣ Deploy ứng dụng
```
NetBeans → F6 (Run) hoặc Shift+F6 (Run Project)
```

### 2️⃣ Truy cập kết quả
```
http://localhost:8080/BtThuc/toyz
```

Bạn sẽ thấy 12 bảng kết quả, mỗi bảng tương ứng với 1 bài tập.

---

## 📊 Dữ Liệu Mẫu

### Entity Toy (Đồ chơi)
| Field | Kiểu | Mô tả |
|-------|------|-------|
| **id** | int | ID của đồ chơi (1-20, tự động tăng - AUTO_INCREMENT) |
| **name** | String | Tên đồ chơi (VD: "Lego Classic", "Barbie Dreamhouse") |
| **price** | double | Giá bán (10.0 đến 100.0) |
| **expDate** | Date | Ngày hết hạn |
| **brandId** | int | ID hãng sản xuất |

### Entity Brand (Hãng)
| Field | Kiểu | Mô tả |
|-------|------|-------|
| **id** | int | ID hãng (1-5, tự động tăng) |
| **name** | String | Tên hãng (Lego, Barbie, Hot Wheels, v.v.) |

### Dữ Liệu Cụ Thể
```
Brand:
- 1: Lego
- 2: Barbie
- 3: Hot Wheels
- 4: Transformers
- 5: Playmobil

Toy (ví dụ với giá mới 10.0-100.0):
- 1: Lego Classic, price=25.0
- 2: Barbie Dreamhouse, price=85.0
- 3: Hot Wheels Car, price=15.0
- 4: Transformers Optimus, price=60.0
- 5: Playmobil Pirate, price=35.0
- ...
- 20: Playmobil Farm, price=58.0
```

---

## 📝 Chi Tiết 12 Bài Tập

### **Bài 1: Truy vấn với WHERE (Giá > 30)**

**Yêu cầu:** Lấy danh sách đồ chơi có giá lớn hơn 30

**Code JPQL:**
```java
public List<Toy> toysPriceGreaterThan30() {
    return em.createQuery(
        "SELECT t FROM Toy t WHERE t.price > 30", 
        Toy.class
    ).getResultList();
}
```

**Giải thích:**
- `SELECT t FROM Toy t` → Lấy tất cả trường từ entity Toy
- `WHERE t.price > 30` → Điều kiện: giá lớn hơn 30
- `.getResultList()` → Trả về danh sách (List)

**Kết quả mong đợi:** ~15 đồ chơi (Lego City 55, Barbie 120, Transformers 80, v.v.)

---

### **Bài 2: WHERE với chuỗi (LIKE)**

**Yêu cầu:** Lấy các đồ chơi có name chứa từ "Lego"

**Code JPQL:**
```java
public List<Toy> toysWithNameLego() {
    return em.createQuery(
        "SELECT t FROM Toy t WHERE t.name LIKE '%Lego%'", 
        Toy.class
    ).getResultList();
}
```

**Giải thích:**
- `LIKE '%Lego%'` → Tìm chuỗi chứa "Lego" (% = ký tự đại diện)
- `'%Lego%'` → Lego có thể ở đầu, giữa hoặc cuối
- `'Lego%'` → Lego ở đầu
- `'%Lego'` → Lego ở cuối

**Kết quả mong đợi:** 4 đồ chơi (Lego Classic, Lego Star Wars, Lego Friends, Lego Technic)

---

### **Bài 3: ORDER BY (Sắp xếp)**

**Yêu cầu:** Lấy danh sách đồ chơi sắp xếp theo giá tăng dần

**Code JPQL:**
```java
public List<Toy> toysOrderByPriceAsc() {
    return em.createQuery(
        "SELECT t FROM Toy t ORDER BY t.price ASC", 
        Toy.class
    ).getResultList();
}
```

**Giải thích:**
- `ORDER BY t.price ASC` → Sắp xếp theo giá **tăng dần** (từ nhỏ → lớn)
- `DESC` → Sắp xếp **giảm dần** (từ lớn → nhỏ)

**Kết quả mong đợi:** Các đồ chơi được sắp xếp từ rẻ nhất (15) đến đắt nhất (120)

---

### **Bài 4: Kết hợp WHERE + ORDER BY**

**Yêu cầu:** Lấy đồ chơi có giá từ 20 đến 100, sắp xếp theo giá giảm dần

**Code JPQL:**
```java
public List<Toy> toysPriceBetween20And100OrderByPriceDesc() {
    return em.createQuery(
        "SELECT t FROM Toy t WHERE t.price BETWEEN 20 AND 100 ORDER BY t.price DESC", 
        Toy.class
    ).getResultList();
}
```

**Giải thích:**
- `BETWEEN 20 AND 100` → Giá từ 20 đến 100 (bao gồm cả 20 và 100)
- Tương đương: `WHERE t.price >= 20 AND t.price <= 100`
- `ORDER BY t.price DESC` → Sắp xếp từ cao → thấp

**Kết quả mong đợi:** ~18 đồ chơi, sắp xếp từ 100 xuống 20

---

### **Bài 5: Kết hợp AND (Cả 2 điều kiện)**

**Yêu cầu:** Lấy đồ chơi có giá > 20 **VÀ** thuộc Lego (brandId = 1)

**Code JPQL:**
```java
public List<Toy> toysPriceGreaterThan20AndBrand1() {
    return em.createQuery(
        "SELECT t FROM Toy t WHERE t.price > 20 AND t.brand.id = 1", 
        Toy.class
    ).getResultList();
}
```

**Giải thích:**
- `WHERE condition1 AND condition2` → Cả 2 điều kiện phải đúng
- `t.brand.id = 1` → Truy cập ID của Brand thông qua relationship @ManyToOne

**Kết quả mong đợi:** 3 đồ chơi Lego có giá > 20 (Lego City 55, Lego Star Wars 70, Lego Technic 85)

---

### **Bài 6: Kết hợp OR (Một trong 2 điều kiện)**

**Yêu cầu:** Lấy đồ chơi thuộc Lego (id=1) **HOẶC** Barbie (id=2)

**Code JPQL:**
```java
public List<Toy> toysBrand1Or2() {
    return em.createQuery(
        "SELECT t FROM Toy t WHERE t.brand.id = 1 OR t.brand.id = 2", 
        Toy.class
    ).getResultList();
}
```

**Giải thích:**
- `WHERE condition1 OR condition2` → Một trong 2 điều kiện đúng là được
- Có thể viết: `WHERE t.brand.id IN (1, 2)`

**Kết quả mong đợi:** 8 đồ chơi (4 Lego + 4 Barbie)

---

### **Bài 7: Điều kiện Phức Tạp (AND + OR)**

**Yêu cầu:** Lấy đồ chơi thỏa:
- **(Giá > 50 VÀ Lego)** HOẶC **(Giá < 20 VÀ Hot Wheels)**

**Code JPQL:**
```java
public List<Toy> toysComplexCondition() {
    return em.createQuery(
        "SELECT t FROM Toy t WHERE (t.price > 50 AND t.brand.id = 1) " +
        "OR (t.price < 20 AND t.brand.id = 3)", 
        Toy.class
    ).getResultList();
}
```

**Giải thích:**
- Sử dụng **dấu ngoặc** để nhóm điều kiện
- `(điều kiện 1 AND điều kiện 2) OR (điều kiện 3 AND điều kiện 4)`
- Có 2 nhóm được cộng lại bằng OR

**Kết quả mong đợi:** 4 đồ chơi
- Lego > 50: Lego City 55, Lego Star Wars 70, Lego Technic 85
- Hot Wheels < 20: Hot Wheels Car 15

---

### **Bài 8: JOIN (Kết hợp 2 bảng)**

**Yêu cầu:** Lấy danh sách đồ chơi kèm **tên hãng**

**Code JPQL:**
```java
public List<Object[]> toysWithBrandName() {
    return em.createQuery(
        "SELECT t, b.name FROM Toy t JOIN t.brand b", 
        Object[].class
    ).getResultList();
}
```

**Giải thích:**
- `JOIN t.brand b` → Kết nối từ Toy tới Brand thông qua @ManyToOne relationship
- `SELECT t, b.name` → Lấy cả Toy object và tên hãng
- Trả về `Object[]` (mảng): `[Toy object, "Lego"]`
- Có thể nhận được từ: `for (Object[] row : results) { Toy toy = (Toy) row[0]; String brandName = (String) row[1]; }`

**Kết quả mong đợi:** 20 hàng, mỗi hàng có Toy + tên hãng

---

### **Bài 9: JOIN kết hợp điều kiện**

**Yêu cầu:** Lấy đồ chơi **Barbie** có giá > 50

**Code JPQL:**
```java
public List<Toy> toysBarbiePriceGreaterThan50() {
    return em.createQuery(
        "SELECT t FROM Toy t JOIN t.brand b " +
        "WHERE b.name = 'Barbie' AND t.price > 50", 
        Toy.class
    ).getResultList();
}
```

**Giải thích:**
- `WHERE b.name = 'Barbie'` → Lọc theo tên hãng
- Kết hợp JOIN với WHERE

**Kết quả mong đợi:** 2 đồ chơi (Barbie Car 45... nope, Barbie Camper 95)

---

### **Bài 10: JOIN + ORDER BY (Sắp xếp phức tạp)**

**Yêu cầu:** Lấy đồ chơi kèm tên hãng, sắp xếp theo:
1. Tên hãng tăng dần
2. Giá giảm dần

**Code JPQL:**
```java
public List<Object[]> toysWithBrandNameOrderByBrandAscPriceDesc() {
    return em.createQuery(
        "SELECT t, b.name FROM Toy t JOIN t.brand b " +
        "ORDER BY b.name ASC, t.price DESC", 
        Object[].class
    ).getResultList();
}
```

**Giải thích:**
- `ORDER BY b.name ASC, t.price DESC` → Sắp xếp nhiều cột
- Sắp xếp **chính** theo tên hãng (A → Z)
- Nếu cùng hãng, sắp xếp **phụ** theo giá (cao → thấp)

**Kết quả mong đợi:**
```
Barbie:     Barbie Camper 95, Barbie Car 45, Barbie Doll 30, Barbie Dreamhouse 120
Hot Wheels: Hot Wheels Monster 55, Hot Wheels Track 25, Hot Wheels Car 15, Hot Wheels Loop 20
Lego:       Lego Technic 85, Lego Star Wars 70, Lego Friends 40, Lego City 55
...
```

---

### **Bài 11: Native Query - Lấy toàn bộ**

**Yêu cầu:** Dùng **SQL thuần** lấy toàn bộ đồ chơi

**Code JPQL:**
```java
public List<Toy> nativeFindAllToys() {
    return em.createNativeQuery(
        "SELECT * FROM toy", 
        Toy.class
    ).getResultList();
}
```

**Giải thích:**
- `createNativeQuery()` → Chạy SQL thuần thay vì JPQL
- `SELECT * FROM toy` → SQL thuần (không SELECT FROM Toy, mà SELECT * FROM toy)
- Vẫn trả về Toy objects (EclipseLink tự map từ SQL)

**Kết quả mong đợi:** 20 đồ chơi (tất cả)

---

### **Bài 12: Native Query với điều kiện**

**Yêu cầu:** Dùng SQL thuần lấy đồ chơi có giá > 40

**Code JPQL:**
```java
public List<Toy> nativeFindToysPriceGreaterThan40() {
    return em.createNativeQuery(
        "SELECT * FROM toy WHERE price > 40", 
        Toy.class
    ).getResultList();
}
```

**Giải thích:**
- Native Query + WHERE clause
- Tương tự Bài 1, nhưng dùng SQL thay JPQL

**Kết quả mong đợi:** ~12 đồ chơi (những cái giá > 40)

---

## � MVC CRUD - Tương tác Dữ Liệu (Thêm/Sửa/Xóa)

### Truy cập CRUD
```
http://localhost:8080/BtThuc/crud
```

### Mô hình MVC

```
┌─────────────────────────────────────────────────────────┐
│ VIEW: HTML Form (web/crud.html)                        │
│ - User nhập ID, description, price, expDate, brandId   │
│ - Click button: Thêm / Sửa / Xóa                       │
└──────────────┬──────────────────────────────────────────┘
               │ HTTP POST
               ↓
┌──────────────────────────────────────────────────────────┐
│ CONTROLLER: CrudServlet (servlet/CrudServlet.java)      │
│ - Xử lý request từ form                                 │
│ - Gọi ToyService (model)                                │
│ - Truyền message về view                                │
└──────────────┬───────────────────────────────────────────┘
               │ createToy() / updateToyPrice() / deleteToy()
               ↓
┌──────────────────────────────────────────────────────────┐
│ MODEL: ToyService + Entity (entity/ToyService.java)    │
│ - Thực hiện CRUD logic                                  │
│ - Gọi JPA (EntityManager)                               │
│ - Lưu/cập nhật/xóa vào Database                         │
└──────────────┬───────────────────────────────────────────┘
               │ SQL Commands
               ↓
         DATABASE: SQL Server
```

### 3 Hoạt Động CRUD

#### 1️⃣ **CREATE (Thêm Dữ Liệu)**
```
User → Form (ID, description, price, expDate, brandId)
     → POST → CrudServlet.doPost()
     → service.createToy(id, desc, price, expDate, brandId)
     → ToyService.createToy() → em.persist() → Database
     → Hiển thị "✅ Thêm thành công"
```

**Code trong ToyService:**
```java
public void createToy(int id, String description, double price, Date expDate, int brandId) {
    EntityTransaction tx = em.getTransaction();
    tx.begin();
    try {
        Brand brand = em.find(Brand.class, brandId);
        Toy toy = new Toy(id, description, price, expDate, brand);
        em.persist(toy);  // ← Thêm vào database
        tx.commit();
    } catch (RuntimeException ex) {
        tx.rollback();
        throw ex;
    }
}
```

#### 2️⃣ **UPDATE (Sửa Giá)**
```
User → Form (ID, newPrice)
     → POST → CrudServlet.doPost()
     → service.updateToyPrice(id, newPrice)
     → ToyService.updateToyPrice() → em.merge() → Database
     → Hiển thị "✅ Sửa thành công"
```

**Code trong ToyService:**
```java
public void updateToyPrice(int id, double newPrice) {
    EntityTransaction tx = em.getTransaction();
    tx.begin();
    try {
        Toy toy = em.find(Toy.class, id);
        toy.setPrice(newPrice);
        em.merge(toy);  // ← Cập nhật database
        tx.commit();
    } catch (RuntimeException ex) {
        tx.rollback();
        throw ex;
    }
}
```

#### 3️⃣ **DELETE (Xóa Dữ Liệu)**
```
User → Form (ID)
     → POST → CrudServlet.doPost()
     → service.deleteToy(id)
     → ToyService.deleteToy() → em.remove() → Database
     → Hiển thị "✅ Xóa thành công"
```

**Code trong ToyService:**
```java
public void deleteToy(int id) {
    EntityTransaction tx = em.getTransaction();
    tx.begin();
    try {
        Toy toy = em.find(Toy.class, id);
        em.remove(toy);  // ← Xóa khỏi database
        tx.commit();
    } catch (RuntimeException ex) {
        tx.rollback();
        throw ex;
    }
}
```

### Các File Liên Quan

| File | Vai Trò | Chi Tiết |
|------|---------|---------|
| **CrudServlet.java** | Controller | Xử lý GET (hiển thị form) + POST (xử lý CRUD) |
| **ToyService.java** | Model | createToy(), updateToyPrice(), deleteToy(), getAllToys() |
| **crud.html** | View | Form HTML để user nhập dữ liệu |
| **Toy.java** | Entity | @Entity mapping, các field id/description/price/expDate/brandId |
| **Brand.java** | Entity | @Entity mapping, relationship @OneToMany |
| **persistence.xml** | Config | Cấu hình kết nối Database |

### JPA Methods Giải Thích

**Cách JPA thao tác database:**

```java
EntityManager em = ...;
EntityTransaction tx = em.getTransaction();

// BEGIN transaction
tx.begin();

// CREATE: em.persist() → INSERT
Toy toy = new Toy(...);
em.persist(toy);  // → SQL: INSERT INTO toy VALUES (...)

// UPDATE: em.merge() → UPDATE
toy.setPrice(99.99);
em.merge(toy);  // → SQL: UPDATE toy SET price = 99.99 WHERE id = X

// DELETE: em.remove() → DELETE
em.remove(toy);  // → SQL: DELETE FROM toy WHERE id = X

// READ: em.find() hoặc createQuery()
Toy toy = em.find(Toy.class, id);  // → SQL: SELECT * FROM toy WHERE id = X
List<Toy> toys = em.createQuery("SELECT t FROM Toy t").getResultList();  // → SQL: SELECT * FROM toy

// END transaction
tx.commit();  // Nếu lỗi → tx.rollback()
```

### Transaction Management (Giao dịch)

**Tại sao cần transaction?**
- Đảm bảo dữ liệu an toàn (all-or-nothing)
- Nếu lỗi ở giữa → rollback hết

**Flow:**
```java
tx.begin();              // ← Bắt đầu
try {
    em.persist(...);     // ← Hoạt động 1
    em.merge(...);       // ← Hoạt động 2
    em.remove(...);      // ← Hoạt động 3
    tx.commit();         // ← Thành công → SAVE tất cả
} catch (Exception e) {
    tx.rollback();       // ← Lỗi → UNDO tất cả
}
```

---



### 1. **Toy.java** (Entity)
```java
@Entity
@Table(name = "toy")
public class Toy {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // ← Database tự sinh ID
    private int id;
    
    @Column(nullable = false)
    private String name;  // ← Thay đổi: description → name
    
    private double price;
    
    @Temporal(TemporalType.DATE)
    private Date expDate;
    
    @ManyToOne
    @JoinColumn(name = "brandId")
    private Brand brand;  // ← Kết nối tới Brand
}
```

**Điểm quan trọng:**
- `@GeneratedValue(strategy = GenerationType.IDENTITY)` → ID tự động tăng (SQL: IDENTITY)
- `@Entity` → Đánh dấu đây là entity JPA
- `@Table(name = "toy")` → Ánh xạ tới bảng SQL `toy`
- `@Id` → Khóa chính
- `@Column(nullable = false)` → Bắt buộc có giá trị
- `@ManyToOne` → Nhiều Toy thuộc 1 Brand
- `@JoinColumn(name = "brandId")` → Khóa ngoại

### 2. **Brand.java** (Entity)
```java
@Entity
@Table(name = "brand")
public class Brand {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // ← Database tự sinh ID
    private int id;
    
    @Column(nullable = false)
    private String name;
    
    @OneToMany(mappedBy = "brand")
    private List<Toy> toys;  // ← Ngược lại của @ManyToOne
}
```

**Điểm quan trọng:**
- `@GeneratedValue(strategy = GenerationType.IDENTITY)` → ID tự động tăng
- `@OneToMany(mappedBy = "brand")` → Một Brand có nhiều Toy
- `mappedBy = "brand"` → Chỉ ra Toy.brand là chủ quan hệ (owner)

### 3. **ToyService.java** (Service - Chứa tất cả query)
```java
public class ToyService {
    private final EntityManager em;
    
    public ToyService(EntityManager em) {
        this.em = em;
    }
    
    public void seedSampleData() {
        // Thêm dữ liệu mẫu nếu chưa có
    }
    
    public List<Toy> toysPriceGreaterThan30() {
        // 12 method query ở đây
    }
}
```

### 4. **JPAUtil.java** (Utility)
```java
public class JPAUtil {
    private static final EntityManagerFactory emf = 
        Persistence.createEntityManagerFactory("ToyzPU");
    
    public static EntityManagerFactory getEntityManagerFactory() {
        return emf;
    }
}
```

### 5. **JpaQueryServlet.java** (Servlet - Hiển thị kết quả)
```java
@WebServlet(name = "JpaQueryServlet", urlPatterns = {"/toyz"})
public class JpaQueryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        EntityManager em = JPAUtil.getEntityManagerFactory().createEntityManager();
        ToyService service = new ToyService(em);
        service.seedSampleData();  // Thêm dữ liệu
        
        // Gọi từng method query
        renderToyTable(out, "Bài 1", service.toysPriceGreaterThan30());
        renderToyTable(out, "Bài 2", service.toysWithDescriptionLego());
        // ...
    }
}
```

---

## 🔧 Persistence.xml (Cấu hình JPA)

```xml
<persistence-unit name="ToyzPU" transaction-type="RESOURCE_LOCAL">
    <provider>org.eclipse.persistence.jpa.PersistenceProvider</provider>
    <class>entity.Brand</class>
    <class>entity.Toy</class>
    <properties>
        <property name="javax.persistence.jdbc.driver" 
                  value="com.microsoft.sqlserver.jdbc.SQLServerDriver"/>
        <property name="javax.persistence.jdbc.url" 
                  value="jdbc:sqlserver://localhost:1433;databaseName=Toyz"/>
        <property name="javax.persistence.jdbc.user" value="sa"/>
        <property name="javax.persistence.jdbc.password" value="1"/>
    </properties>
</persistence-unit>
```

**Cấu hình này nói rằng:**
- Database: `Toyz` trên `localhost:1433` (SQL Server)
- User: `sa`, Password: `1`
- JPA Provider: EclipseLink
- Entities: Brand, Toy

---

## 📋 Bảng Tóm Tắt 12 Bài Tập

| Bài | Yêu cầu | Key Concept | Method |
|-----|---------|------------|--------|
| 1 | Giá > 30 | WHERE | `toysPriceGreaterThan30()` |
| 2 | Description chứa Lego | LIKE | `toysWithDescriptionLego()` |
| 3 | Sắp xếp theo giá ↑ | ORDER BY ASC | `toysOrderByPriceAsc()` |
| 4 | Giá 20-100, ↓ | BETWEEN + DESC | `toysPriceBetween20And100OrderByPriceDesc()` |
| 5 | Giá > 20 VÀ Lego | AND | `toysPriceGreaterThan20AndBrand1()` |
| 6 | Lego HOẶC Barbie | OR | `toysBrand1Or2()` |
| 7 | Điều kiện phức tạp | (AND) OR (AND) | `toysComplexCondition()` |
| 8 | Toy + tên hãng | JOIN | `toysWithBrandName()` |
| 9 | Barbie giá > 50 | JOIN + WHERE | `toysBarbiePriceGreaterThan50()` |
| 10 | JOIN + 2 ORDER | ORDER BY x, y | `toysWithBrandNameOrderByBrandAscPriceDesc()` |
| 11 | Tất cả toy | Native SQL | `nativeFindAllToys()` |
| 12 | Native giá > 40 | Native WHERE | `nativeFindToysPriceGreaterThan40()` |

---

## 💡 JPQL vs SQL

### JPQL (JPA Query Language) - Viết cho Entity
```java
// Entity-based
"SELECT t FROM Toy t WHERE t.price > 30"
"SELECT t FROM Toy t ORDER BY t.price ASC"
"SELECT t, b.name FROM Toy t JOIN t.brand b"
```

### SQL (Native Query) - Viết cho Table
```sql
-- Table-based
"SELECT * FROM toy WHERE price > 30"
"SELECT * FROM toy ORDER BY price ASC"
"SELECT t.*, b.name FROM toy t JOIN brand b ON t.brandId = b.id"
```

**Lợi ích JPQL:**
✅ Độc lập database (SQL Server, MySQL, Oracle → cùng code)
✅ Liên kết thông qua relationship (`t.brand.id`)
✅ Type-safe khi dùng Criteria API

---

## ⚠️ Troubleshooting

### ❌ Lỗi: "Không kết nối được JPA"
**Kiểm tra:**
1. ✅ Đã thêm `sqljdbc4.jar` vào Libraries?
2. ✅ User/password trong `persistence.xml` đúng?
3. ✅ SQL Server đang chạy ở `localhost:1433`?
4. ✅ Database `Toyz` tồn tại?

### ❌ Lỗi: "Entity not found"
- Đảm bảo đã chạy `sql/MoreData.sql` để tạo bảng + thêm dữ liệu

### ❌ Kết quả trống rỗng
- Kiểm tra trong SQL Server: `SELECT * FROM toy;` có dữ liệu không?

---

## 🎯 Các Bước Để Hoàn Thành

### **Phần 1: JPA Query**
1. ✅ **Mở project** trong NetBeans
2. ✅ **Deploy** (F6) → Tạo bảng + thêm dữ liệu qua `seedSampleData()`
3. ✅ **Mở browser** → `http://localhost:8080/BtThuc/toyz`
4. ✅ **Xem kết quả** của 12 bài tập query

### **Phần 2: MVC CRUD (Tương tác Dữ Liệu)**
1. ✅ **Deploy lại** (F6) để load CrudServlet
2. ✅ **Mở browser** → `http://localhost:8080/BtThuc/crud`
3. ✅ **Thêm đồ chơi:**
   - Nhập ID (phải > 20, VD: 21)
   - Nhập Description (VD: "My New Toy")
   - Nhập Price (VD: 49.99)
   - Chọn Expiration Date (VD: 2026-12-31)
   - Chọn Brand (1-5)
   - Click **➕ Thêm**
4. ✅ **Sửa giá:**
   - Nhập ID của đồ chơi (VD: 1)
   - Nhập Giá mới (VD: 75.50)
   - Click **✏️ Sửa**
5. ✅ **Xóa đồ chơi:**
   - Nhập ID (VD: 21)
   - Click **🗑️ Xóa**
6. ✅ **Kiểm tra danh sách:**
   - Scroll xuống xem bảng "Danh sách tất cả đồ chơi"
   - Hoặc quay lại `/toyz` để thấy các query kết quả thay đổi

---

## 📚 Tài Liệu Tham Khảo

- **JPQL Documentation:** `persistence.xml` + `ToyService.java`
- **Entity Mapping:** `Toy.java`, `Brand.java`
- **SQL Server Driver:** `sqljdbc4.jar`

---

## ✨ Kết Luận

**Bài thực hành này dạy bạn:**
1. Từ đơn giản (WHERE) → phức tạp (JOIN + ORDER BY)
2. Từ JPQL → Native SQL
3. Từ 1 điều kiện → nhiều điều kiện kết hợp
4. Cách kết nối 2 entity bằng @ManyToOne/@OneToMany

**Hãy tìm hiểu từng method trong `ToyService.java` để thực sự nắm rõ!** 🚀

---

## ✅ Checklist - Thỏa Mãn Yêu Cầu

### Entity & Database
- ✅ Entity **Toy**: 
  - ✅ `id` (PK, tự động tăng - @GeneratedValue)
  - ✅ `name` (tên đồ chơi, thay vì description)
  - ✅ `price` (double)
  - ✅ `expDate` (Date)
  - ✅ `brandId` (FK)
  
- ✅ Entity **Brand**:
  - ✅ `id` (PK, tự động tăng - @GeneratedValue)
  - ✅ `name` (tên hãng)

- ✅ **Dữ liệu**:
  - ✅ 5 brands (id 1-5): Lego, Barbie, Hot Wheels, Transformers, Playmobil
  - ✅ 20 toys (id 1-20) với price 10.0-100.0 (thỏa mãn spec)

### Bài Tập JPQL (12 bài)
- ✅ **Bài 1**: WHERE (giá > 30)
- ✅ **Bài 2**: WHERE + LIKE (name chứa "Lego")
- ✅ **Bài 3**: ORDER BY (sắp xếp tăng dần)
- ✅ **Bài 4**: WHERE + BETWEEN + ORDER BY DESC
- ✅ **Bài 5**: WHERE + AND (giá > 20 AND brandId = 1)
- ✅ **Bài 6**: WHERE + OR (brandId = 1 OR 2)
- ✅ **Bài 7**: WHERE + (AND/OR phức tạp)
- ✅ **Bài 8**: JOIN (lấy toy kèm tên hãng)
- ✅ **Bài 9**: JOIN + WHERE (Barbie giá > 50)
- ✅ **Bài 10**: JOIN + ORDER BY (2 cột)
- ✅ **Bài 11**: Native Query (SELECT * FROM toy)
- ✅ **Bài 12**: Native Query + WHERE (giá > 40)

### Code Documentation
- ✅ **Toy.java**: Comments chi tiết cho mỗi field
- ✅ **Brand.java**: Comments chi tiết cho mỗi field
- ✅ **ToyService.java**: Comments chi tiết cho mỗi query method (12 bài)
  - ✅ Ghi rõ: Yêu cầu, SQL, JPQL, Chú ý
  - ✅ Giải thích từng phần của query
- ✅ **CrudServlet.java**: Comments giải thích Controller
- ✅ **README.md**: Hướng dẫn chi tiết + examples

### MVC CRUD
- ✅ **View**: HTML form trong CrudServlet.java
- ✅ **Controller**: CrudServlet.java (doGet/doPost)
- ✅ **Model**: ToyService.java (createToy/updateToyPrice/deleteToy)

---

**Kết luận:** Bài tập đã **hoàn toàn thỏa mãn yêu cầu**, kèm theo đầy đủ:
- Code comments giải thích chi tiết
- Document markdown (README) chi tiết
- 12 JPQL query methods
- CRUD operations (thêm/sửa/xóa)
- MVC pattern (View/Controller/Model)
