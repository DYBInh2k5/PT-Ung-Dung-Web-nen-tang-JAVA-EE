package servlet;

import entity.Toy;
import entity.ToyService;
import util.JPAUtil;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

/**
 * CrudServlet - Controller xử lý CRUD operations
 * Nhận request từ form HTML (create/read/update/delete)
 * Gọi ToyService để thực hiện database operations
 * Trả lại kết quả cho HTML
 */
@WebServlet(name = "CrudServlet", urlPatterns = {"/crud"})
public class CrudServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        EntityManager em = null;
        try (PrintWriter out = response.getWriter()) {
            em = JPAUtil.getEntityManagerFactory().createEntityManager();
            ToyService service = new ToyService(em);

            // Hiển thị form HTML
            String action = request.getParameter("action");
            String message = request.getParameter("message");

            out.println("<!DOCTYPE html>");
            out.println("<html><head><meta charset='UTF-8'><title>CRUD Đồ Chơi</title>");
            out.println("<style>");
            out.println("body{font-family:Arial,sans-serif;margin:20px;background:#f5f7fb;color:#1f2937}");
            out.println("h1{color:#0f172a} h2{color:#1d4ed8;margin-top:28px}");
            out.println(".container{max-width:1200px;margin:0 auto}");
            out.println("form{background:#fff;padding:20px;border:1px solid #dbe2ea;border-radius:8px;margin-bottom:20px}");
            out.println("input,select,textarea{padding:8px;border:1px solid #dbe2ea;border-radius:4px;margin-bottom:10px;width:100%;box-sizing:border-box}");
            out.println("button{background:#1d4ed8;color:#fff;padding:10px 20px;border:none;border-radius:4px;cursor:pointer;font-weight:bold}");
            out.println("button:hover{background:#1e40af}");
            out.println(".success{background:#dcfce7;border:1px solid #86efac;padding:12px;border-radius:8px;margin-bottom:20px;color:#166534}");
            out.println(".error{background:#fee2e2;border:1px solid #fca5a5;padding:12px;border-radius:8px;margin-bottom:20px;color:#991b1b}");
            out.println("table{border-collapse:collapse;width:100%;background:#fff;margin-top:20px}");
            out.println("th,td{border:1px solid #dbe2ea;padding:12px;text-align:left}");
            out.println("th{background:#e0f2fe;font-weight:bold}");
            out.println("tr:hover{background:#f0f9ff}");
            out.println(".form-group{margin-bottom:15px}");
            out.println("label{display:block;margin-bottom:5px;font-weight:bold;color:#374151}");
            out.println(".actions{display:flex;gap:10px}");
            out.println(".btn-delete{background:#dc2626}");
            out.println(".btn-delete:hover{background:#b91c1c}");
            out.println(".nav{margin-bottom:20px}");
            out.println(".nav a{display:inline-block;padding:10px 15px;background:#1d4ed8;color:#fff;text-decoration:none;border-radius:4px;margin-right:10px}");
            out.println(".nav a:hover{background:#1e40af}");
            out.println("</style></head><body>");

            out.println("<div class='container'>");
            out.println("<h1>🎮 CRUD Đồ Chơi - Mô hình MVC</h1>");

            // Hiển thị message
            if (message != null) {
                if (message.contains("success")) {
                    out.println("<div class='success'>✅ " + message.replace("success:", "") + "</div>");
                } else if (message.contains("error")) {
                    out.println("<div class='error'>❌ " + message.replace("error:", "") + "</div>");
                }
            }

            out.println("<div class='nav'>");
            out.println("<a href='/BtThuc/crud'>📋 Quản lý đồ chơi</a>");
            out.println("<a href='/BtThuc/toyz'>📊 Xem Query Results</a>");
            out.println("</div>");

            // FORM THÊM ĐỒ CHƠI MỚI
            out.println("<h2>➕ Thêm đồ chơi mới</h2>");
            out.println("<form method='post' action='/BtThuc/crud'>");
            out.println("<div class='form-group'>");
            out.println("  <label>ID (phải > 20):</label>");
            out.println("  <input type='number' name='id' required>");
            out.println("</div>");
            out.println("<div class='form-group'>");
            out.println("  <label>Name:</label>");
            out.println("  <input type='text' name='name' placeholder='VD: Lego Castle' required>");
            out.println("</div>");
            out.println("<div class='form-group'>");
            out.println("  <label>Price:</label>");
            out.println("  <input type='number' name='price' step='0.01' placeholder='VD: 49.99' required>");
            out.println("</div>");
            out.println("<div class='form-group'>");
            out.println("  <label>Expiration Date:</label>");
            out.println("  <input type='date' name='expDate' required>");
            out.println("</div>");
            out.println("<div class='form-group'>");
            out.println("  <label>Brand ID:</label>");
            out.println("  <select name='brandId' required>");
            out.println("    <option value=''>-- Chọn hãng --</option>");
            out.println("    <option value='1'>1 - Lego</option>");
            out.println("    <option value='2'>2 - Barbie</option>");
            out.println("    <option value='3'>3 - Hot Wheels</option>");
            out.println("    <option value='4'>4 - Transformers</option>");
            out.println("    <option value='5'>5 - Playmobil</option>");
            out.println("  </select>");
            out.println("</div>");
            out.println("<button type='submit' name='action' value='create'>➕ Thêm</button>");
            out.println("</form>");

            // FORM SỬA GIÁ
            out.println("<h2>✏️ Sửa giá đồ chơi</h2>");
            out.println("<form method='post' action='/BtThuc/crud'>");
            out.println("<div class='form-group'>");
            out.println("  <label>ID của đồ chơi cần sửa:</label>");
            out.println("  <input type='number' name='id' required>");
            out.println("</div>");
            out.println("<div class='form-group'>");
            out.println("  <label>Giá mới:</label>");
            out.println("  <input type='number' name='price' step='0.01' required>");
            out.println("</div>");
            out.println("<button type='submit' name='action' value='update'>✏️ Sửa</button>");
            out.println("</form>");

            // FORM XÓA
            out.println("<h2>🗑️ Xóa đồ chơi</h2>");
            out.println("<form method='post' action='/BtThuc/crud'>");
            out.println("<div class='form-group'>");
            out.println("  <label>ID của đồ chơi cần xóa:</label>");
            out.println("  <input type='number' name='id' required>");
            out.println("</div>");
            out.println("<button type='submit' name='action' value='delete' onclick='return confirm(\"Chắc chắn xóa không?\")'>🗑️ Xóa</button>");
            out.println("</form>");

            // DANH SÁCH TẤT CẢ ĐỒ CHƠI
            out.println("<h2>📋 Danh sách tất cả đồ chơi</h2>");
            List<Toy> allToys = service.getAllToys();
            out.println("<table>");
            out.println("<tr><th>ID</th><th>Name</th><th>Price</th><th>Exp Date</th><th>Brand</th><th>Actions</th></tr>");
            for (Toy toy : allToys) {
                out.println("<tr>");
                out.println("<td>" + toy.getId() + "</td>");
                out.println("<td>" + escape(toy.getName()) + "</td>");
                out.println("<td>$" + String.format("%.2f", toy.getPrice()) + "</td>");
                out.println("<td>" + toy.getExpDate() + "</td>");
                out.println("<td>" + (toy.getBrand() != null ? escape(toy.getBrand().getName()) : "N/A") + "</td>");
                out.println("<td>");
                out.println("  <form method='post' action='/BtThuc/crud' style='display:inline'>");
                out.println("    <input type='hidden' name='id' value='" + toy.getId() + "'>");
                out.println("    <button type='submit' name='action' value='delete' class='btn-delete' style='padding:5px 10px;font-size:12px' onclick='return confirm(\"Xóa không?\")'>Xóa</button>");
                out.println("  </form>");
                out.println("</td>");
                out.println("</tr>");
            }
            out.println("</table>");

            out.println("<p style='margin-top:20px;color:#6b7280;font-size:12px'>");
            out.println("💡 Model: Entity (Toy, Brand) | View: HTML Form | Controller: CrudServlet");
            out.println("</p>");
            out.println("</div></body></html>");

        } catch (Exception ex) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try (PrintWriter out = response.getWriter()) {
                out.println("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Error</title>");
                out.println("<style>body{font-family:Arial;margin:20px;background:#fff7f7}.box{max-width:600px;padding:20px;background:#fff;border:1px solid #fca5a5;border-radius:8px}</style>");
                out.println("</head><body><div class='box'><h1>❌ Lỗi CRUD</h1>");
                out.println("<pre>" + escape(ex.getClass().getName() + ": " + ex.getMessage()) + "</pre>");
                out.println("</div></body></html>");
            }
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String message = "";

        EntityManager em = null;
        try {
            em = JPAUtil.getEntityManagerFactory().createEntityManager();
            ToyService service = new ToyService(em);

            if ("create".equals(action)) {
                // CREATE: Thêm đồ chơi mới
                int id = Integer.parseInt(request.getParameter("id"));
                String name = request.getParameter("name");
                double price = Double.parseDouble(request.getParameter("price"));
                Date expDate = Date.valueOf(request.getParameter("expDate"));
                int brandId = Integer.parseInt(request.getParameter("brandId"));

                service.createToy(id, name, price, expDate, brandId);
                message = "success:✅ Thêm đồ chơi '" + name + "' thành công!";

            } else if ("update".equals(action)) {
                // UPDATE: Sửa giá
                int id = Integer.parseInt(request.getParameter("id"));
                double newPrice = Double.parseDouble(request.getParameter("price"));

                service.updateToyPrice(id, newPrice);
                message = "success:✅ Sửa giá đồ chơi ID " + id + " thành $" + String.format("%.2f", newPrice) + " thành công!";

            } else if ("delete".equals(action)) {
                // DELETE: Xóa đồ chơi
                int id = Integer.parseInt(request.getParameter("id"));

                service.deleteToy(id);
                message = "success:✅ Xóa đồ chơi ID " + id + " thành công!";
            }

        } catch (NumberFormatException ex) {
            message = "error:❌ Lỗi: Dữ liệu không hợp lệ (ID, giá phải là số)";
        } catch (Exception ex) {
            message = "error:❌ Lỗi: " + ex.getMessage();
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
        }

        // Redirect về GET với message
        response.sendRedirect("/BtThuc/crud?message=" + encodeMessage(message));
    }

    /**
     * Escape HTML special characters
     */
    private String escape(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    /**
     * URL encode message
     */
    private String encodeMessage(String message) {
        if (message == null) return "";
        try {
            return java.net.URLEncoder.encode(message, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
