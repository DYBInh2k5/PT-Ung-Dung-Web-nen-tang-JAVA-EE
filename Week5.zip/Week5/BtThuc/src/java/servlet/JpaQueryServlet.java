package servlet;

import entity.Toy;
import entity.ToyService;
import util.JPAUtil;

import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "JpaQueryServlet", urlPatterns = {"/toyz"})
public class JpaQueryServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        EntityManager em = null;
        try (PrintWriter out = response.getWriter()) {
            em = JPAUtil.getEntityManagerFactory().createEntityManager();
            ToyService service = new ToyService(em);
            service.seedSampleData();

            out.println("<!DOCTYPE html>");
            out.println("<html><head><meta charset='UTF-8'><title>JPA Query Demo</title>");
            out.println("<style>");
            out.println("body{font-family:Arial,sans-serif;margin:20px;background:#f5f7fb;color:#1f2937}");
            out.println("h1{color:#0f172a} h2{margin-top:28px;color:#1d4ed8} table{border-collapse:collapse;width:100%;background:#fff;margin-top:8px}");
            out.println("th,td{border:1px solid #dbe2ea;padding:8px;text-align:left} th{background:#e0f2fe}");
            out.println(".note{background:#fff7ed;border:1px solid #fdba74;padding:12px;border-radius:8px}");
            out.println("</style></head><body>");
            out.println("<h1>Bài thực hành JPA Query</h1>");
            out.println("<div class='note'>Đã nạp dữ liệu mẫu vào bảng brand và toy. Kéo xuống xem kết quả từng bài.</div>");

            renderToyTable(out, "Bài 1 - Giá > 30", service.toysPriceGreaterThan30());
            renderToyTable(out, "Bài 2 - Name chứa Lego", service.toysWithNameLego());
            renderToyTable(out, "Bài 3 - Order by price ASC", service.toysOrderByPriceAsc());
            renderToyTable(out, "Bài 4 - Price 20..100, DESC", service.toysPriceBetween20And100OrderByPriceDesc());
            renderToyTable(out, "Bài 5 - Price > 20 AND brandId = 1", service.toysPriceGreaterThan20AndBrand1());
            renderToyTable(out, "Bài 6 - brandId = 1 OR 2", service.toysBrand1Or2());
            renderToyTable(out, "Bài 7 - Điều kiện phức tạp", service.toysComplexCondition());
            renderToyBrandRows(out, "Bài 8 - JOIN lấy toy kèm tên hãng", service.toysWithBrandName());
            renderToyTable(out, "Bài 9 - Hãng Barbie và giá > 50", service.toysBarbiePriceGreaterThan50());
            renderToyBrandRows(out, "Bài 10 - JOIN + ORDER BY", service.toysWithBrandNameOrderByBrandAscPriceDesc());
            renderToyTable(out, "Bài 11 - Native query lấy toàn bộ toy", service.nativeFindAllToys());
            renderToyTable(out, "Bài 12 - Native query giá > 40", service.nativeFindToysPriceGreaterThan40());

            out.println("</body></html>");
        } catch (Exception ex) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try (PrintWriter out = response.getWriter()) {
                out.println("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>JPA Query Error</title>");
                out.println("<style>body{font-family:Arial,sans-serif;margin:20px;background:#fff7f7;color:#7f1d1d}.box{max-width:900px;padding:20px;background:#fff;border:1px solid #fca5a5;border-radius:12px}</style>");
                out.println("</head><body><div class='box'>");
                out.println("<h1>Không kết nối được JPA</h1>");
                out.println("<p>Kiểm tra lại 3 điểm sau:</p>");
                out.println("<ol>");
                out.println("<li>Đã thêm JDBC driver SQL Server vào Libraries của project.</li>");
                out.println("<li>User/password trong persistence.xml đúng với connection NetBeans.</li>");
                out.println("<li>Database Toyz đang chạy ở localhost:1433.</li>");
                out.println("</ol>");
                out.println("<pre>" + escape(ex.getClass().getName() + ": " + ex.getMessage()) + "</pre>");
                out.println("</div></body></html>");
            }
        } finally {
            if (em != null && em.isOpen()) {
                em.close();
            }
        }
    }

    private void renderToyTable(PrintWriter out, String title, List<Toy> toys) {
        out.println("<h2>" + title + "</h2>");
        out.println("<table>");
        out.println("<tr><th>ID</th><th>Name</th><th>Price</th><th>Exp Date</th><th>Brand</th></tr>");
        for (Toy toy : toys) {
            out.println("<tr>");
            out.println("<td>" + toy.getId() + "</td>");
            out.println("<td>" + escape(toy.getName()) + "</td>");
            out.println("<td>" + toy.getPrice() + "</td>");
            out.println("<td>" + toy.getExpDate() + "</td>");
            out.println("<td>" + (toy.getBrand() != null ? escape(toy.getBrand().getName()) : "") + "</td>");
            out.println("</tr>");
        }
        out.println("</table>");
    }

    private void renderToyBrandRows(PrintWriter out, String title, List<Object[]> rows) {
        out.println("<h2>" + title + "</h2>");
        out.println("<table>");
        out.println("<tr><th>Toy</th><th>Brand</th></tr>");
        for (Object[] row : rows) {
            Toy toy = (Toy) row[0];
            String brandName = String.valueOf(row[1]);
            out.println("<tr><td>" + escape(toy.getDescription()) + "</td><td>" + escape(brandName) + "</td></tr>");
        }
        out.println("</table>");
    }

    private String escape(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
