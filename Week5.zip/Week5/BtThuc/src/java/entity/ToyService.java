package entity;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import java.util.List;

/**
 * ToyService - Service layer cho entity Toy
 * Chứa tất cả JPQL queries và CRUD operations
 * Mô hình: View → Controller (CrudServlet/JpaQueryServlet) → ToyService → EntityManager → Database
 */
public class ToyService {
    private final EntityManager em;

    public ToyService(EntityManager em) {
        this.em = em;
    }

    /**
     * Seed dữ liệu mẫu: 5 brands + 20 toys
     * Chỉ chạy lần đầu khi table rỗng
     * 
     * Brands: Lego, Barbie, Hot Wheels, Transformers, Playmobil
     * Toys: 20 sản phẩm với giá từ 10.0 đến 100.0
     */
    public void seedSampleData() {
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        try {
            // Kiểm tra xem đã có brand chưa
            Long brandCount = em.createQuery("SELECT COUNT(b) FROM Brand b", Long.class).getSingleResult();
            if (brandCount == 0) {
                em.persist(new Brand(1, "Lego"));
                em.persist(new Brand(2, "Barbie"));
                em.persist(new Brand(3, "Hot Wheels"));
                em.persist(new Brand(4, "Transformers"));
                em.persist(new Brand(5, "Playmobil"));
            }

            // Kiểm tra xem đã có toy chưa
            Long toyCount = em.createQuery("SELECT COUNT(t) FROM Toy t", Long.class).getSingleResult();
            if (toyCount == 0) {
                Brand lego = em.find(Brand.class, 1);
                Brand barbie = em.find(Brand.class, 2);
                Brand hotWheels = em.find(Brand.class, 3);
                Brand transformers = em.find(Brand.class, 4);
                Brand playmobil = em.find(Brand.class, 5);

                // Thêm 20 đồ chơi với giá từ 10.0 đến 100.0
                em.persist(new Toy(1, "Lego Classic", 25.0, java.sql.Date.valueOf("2026-12-31"), lego));
                em.persist(new Toy(2, "Barbie Dreamhouse", 85.0, java.sql.Date.valueOf("2027-01-15"), barbie));
                em.persist(new Toy(3, "Hot Wheels Car", 15.0, java.sql.Date.valueOf("2026-08-20"), hotWheels));
                em.persist(new Toy(4, "Transformers Optimus", 60.0, java.sql.Date.valueOf("2027-03-10"), transformers));
                em.persist(new Toy(5, "Playmobil Pirate", 35.0, java.sql.Date.valueOf("2026-11-05"), playmobil));
                em.persist(new Toy(6, "Lego Star Wars", 55.0, java.sql.Date.valueOf("2026-09-09"), lego));
                em.persist(new Toy(7, "Barbie Car", 45.0, java.sql.Date.valueOf("2027-02-14"), barbie));
                em.persist(new Toy(8, "Hot Wheels Track", 22.0, java.sql.Date.valueOf("2026-10-10"), hotWheels));
                em.persist(new Toy(9, "Transformers Bumblebee", 52.0, java.sql.Date.valueOf("2027-04-01"), transformers));
                em.persist(new Toy(10, "Playmobil Castle", 65.0, java.sql.Date.valueOf("2026-12-12"), playmobil));
                em.persist(new Toy(11, "Lego Friends", 40.0, java.sql.Date.valueOf("2026-07-07"), lego));
                em.persist(new Toy(12, "Barbie Doll", 28.0, java.sql.Date.valueOf("2027-05-05"), barbie));
                em.persist(new Toy(13, "Hot Wheels Monster", 18.0, java.sql.Date.valueOf("2026-06-06"), hotWheels));
                em.persist(new Toy(14, "Transformers Megatron", 75.0, java.sql.Date.valueOf("2027-06-06"), transformers));
                em.persist(new Toy(15, "Playmobil Zoo", 48.0, java.sql.Date.valueOf("2026-05-05"), playmobil));
                em.persist(new Toy(16, "Lego Technic", 72.0, java.sql.Date.valueOf("2026-04-04"), lego));
                em.persist(new Toy(17, "Barbie Camper", 95.0, java.sql.Date.valueOf("2027-07-07"), barbie));
                em.persist(new Toy(18, "Hot Wheels Loop", 20.0, java.sql.Date.valueOf("2026-03-03"), hotWheels));
                em.persist(new Toy(19, "Transformers Starscream", 68.0, java.sql.Date.valueOf("2027-08-08"), transformers));
                em.persist(new Toy(20, "Playmobil Farm", 58.0, java.sql.Date.valueOf("2026-02-02"), playmobil));
            }

            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw ex;
        }
    }

    // ========== BÀI 1: WHERE ==========
    /**
     * Bài 1: Truy vấn với WHERE
     * Yêu cầu: Lấy danh sách đồ chơi có giá > 30
     * SQL: SELECT * FROM toy WHERE price > 30
     * JPQL: SELECT t FROM Toy t WHERE t.price > 30
     */
    public List<Toy> toysPriceGreaterThan30() {
        return em.createQuery("SELECT t FROM Toy t WHERE t.price > 30", Toy.class).getResultList();
    }

    // ========== BÀI 2: WHERE + LIKE ==========
    /**
     * Bài 2: Truy vấn với WHERE theo chuỗi (LIKE)
     * Yêu cầu: Lấy đồ chơi có name chứa "Lego"
     * SQL: SELECT * FROM toy WHERE name LIKE '%Lego%'
     * JPQL: SELECT t FROM Toy t WHERE t.name LIKE '%Lego%'
     * Chú ý: Đổi từ description → name
     */
    public List<Toy> toysWithNameLego() {
        return em.createQuery("SELECT t FROM Toy t WHERE t.name LIKE '%Lego%'", Toy.class).getResultList();
    }

    // ========== BÀI 3: ORDER BY ==========
    /**
     * Bài 3: Truy vấn với ORDER BY
     * Yêu cầu: Sắp xếp đồ chơi theo giá tăng dần (ASC = Ascending)
     * SQL: SELECT * FROM toy ORDER BY price ASC
     * JPQL: SELECT t FROM Toy t ORDER BY t.price ASC
     */
    public List<Toy> toysOrderByPriceAsc() {
        return em.createQuery("SELECT t FROM Toy t ORDER BY t.price ASC", Toy.class).getResultList();
    }

    // ========== BÀI 4: WHERE + ORDER BY + BETWEEN ==========
    /**
     * Bài 4: Kết hợp WHERE và ORDER BY
     * Yêu cầu: Giá 20-100, sắp xếp giảm dần (DESC = Descending)
     * SQL: SELECT * FROM toy WHERE price BETWEEN 20 AND 100 ORDER BY price DESC
     * JPQL: SELECT t FROM Toy t WHERE t.price BETWEEN 20 AND 100 ORDER BY t.price DESC
     * Chú ý: BETWEEN bao gồm cả giá trị đầu và cuối (20 ≤ price ≤ 100)
     */
    public List<Toy> toysPriceBetween20And100OrderByPriceDesc() {
        return em.createQuery("SELECT t FROM Toy t WHERE t.price BETWEEN 20 AND 100 ORDER BY t.price DESC", Toy.class).getResultList();
    }

    // ========== BÀI 5: WHERE + AND ==========
    /**
     * Bài 5: Kết hợp nhiều điều kiện với AND
     * Yêu cầu: Giá > 20 VÀ brandId = 1
     * SQL: SELECT * FROM toy WHERE price > 20 AND brandId = 1
     * JPQL: SELECT t FROM Toy t WHERE t.price > 20 AND t.brand.id = 1
     * Chú ý: AND = cả 2 điều kiện phải đúng cùng lúc
     */
    public List<Toy> toysPriceGreaterThan20AndBrand1() {
        return em.createQuery("SELECT t FROM Toy t WHERE t.price > 20 AND t.brand.id = 1", Toy.class).getResultList();
    }

    // ========== BÀI 6: WHERE + OR ==========
    /**
     * Bài 6: Kết hợp nhiều điều kiện với OR
     * Yêu cầu: brandId = 1 HOẶC brandId = 2
     * SQL: SELECT * FROM toy WHERE brandId = 1 OR brandId = 2
     * JPQL: SELECT t FROM Toy t WHERE t.brand.id = 1 OR t.brand.id = 2
     * Chú ý: OR = một trong hai điều kiện đúng là được
     */
    public List<Toy> toysBrand1Or2() {
        return em.createQuery("SELECT t FROM Toy t WHERE t.brand.id = 1 OR t.brand.id = 2", Toy.class).getResultList();
    }

    // ========== BÀI 7: WHERE + (AND/OR kết hợp phức tạp) ==========
    /**
     * Bài 7: Kết hợp nhiều điều kiện phức tạp
     * Yêu cầu: (Giá > 50 VÀ brandId = 1) HOẶC (Giá < 20 VÀ brandId = 3)
     * SQL: SELECT * FROM toy WHERE (price > 50 AND brandId = 1) OR (price < 20 AND brandId = 3)
     * JPQL: SELECT t FROM Toy t WHERE (t.price > 50 AND t.brand.id = 1) OR (t.price < 20 AND t.brand.id = 3)
     * Chú ý: Dùng dấu ngoặc để nhóm điều kiện, kết hợp AND + OR
     */
    public List<Toy> toysComplexCondition() {
        return em.createQuery("SELECT t FROM Toy t WHERE (t.price > 50 AND t.brand.id = 1) OR (t.price < 20 AND t.brand.id = 3)", Toy.class).getResultList();
    }

    // ========== BÀI 8: JOIN ==========
    /**
     * Bài 8: Truy vấn JOIN
     * Yêu cầu: Lấy danh sách đồ chơi kèm tên hãng
     * SQL: SELECT t.*, b.name FROM toy t JOIN brand b ON t.brandId = b.id
     * JPQL: SELECT t, b.name FROM Toy t JOIN t.brand b
     * Chú ý: 
     * - JOIN t.brand b → Kết nối bảng Toy với Brand qua relationship @ManyToOne
     * - SELECT t, b.name → Lấy cả Toy object và tên hãng
     * - Trả về Object[] = [Toy, "Lego"]
     */
    public List<Object[]> toysWithBrandName() {
        return em.createQuery("SELECT t, b.name FROM Toy t JOIN t.brand b", Object[].class).getResultList();
    }

    // ========== BÀI 9: JOIN + WHERE ==========
    /**
     * Bài 9: JOIN kết hợp điều kiện
     * Yêu cầu: Hãng "Barbie" và giá > 50
     * SQL: SELECT t.* FROM toy t JOIN brand b ON t.brandId = b.id WHERE b.name = 'Barbie' AND t.price > 50
     * JPQL: SELECT t FROM Toy t JOIN t.brand b WHERE b.name = 'Barbie' AND t.price > 50
     * Chú ý: Lọc theo tên hãng (b.name) trong WHERE
     */
    public List<Toy> toysBarbiePriceGreaterThan50() {
        return em.createQuery("SELECT t FROM Toy t JOIN t.brand b WHERE b.name = 'Barbie' AND t.price > 50", Toy.class).getResultList();
    }

    // ========== BÀI 10: JOIN + ORDER BY (nhiều cột) ==========
    /**
     * Bài 10: JOIN + ORDER BY
     * Yêu cầu: Lấy toy kèm tên hãng, sắp xếp theo tên hãng (A→Z), rồi giá (cao→thấp)
     * SQL: SELECT t.*, b.name FROM toy t JOIN brand b ON t.brandId = b.id ORDER BY b.name ASC, t.price DESC
     * JPQL: SELECT t, b.name FROM Toy t JOIN t.brand b ORDER BY b.name ASC, t.price DESC
     * Chú ý: ORDER BY multiple columns: sắp xếp chính theo b.name, phụ theo t.price
     */
    public List<Object[]> toysWithBrandNameOrderByBrandAscPriceDesc() {
        return em.createQuery("SELECT t, b.name FROM Toy t JOIN t.brand b ORDER BY b.name ASC, t.price DESC", Object[].class).getResultList();
    }

    // ========== BÀI 11: NATIVE QUERY cơ bản ==========
    /**
     * Bài 11: Native Query cơ bản
     * Yêu cầu: Lấy toàn bộ đồ chơi (dùng SQL thuần thay vì JPQL)
     * SQL: SELECT * FROM toy
     * JPQL: Không có (dùng native query)
     * Chú ý: createNativeQuery() → SQL thuần (tên bảng phải viết đúng: "toy" không phải "Toy")
     */
    public List<Toy> nativeFindAllToys() {
        return em.createNativeQuery("SELECT * FROM toy", Toy.class).getResultList();
    }

    // ========== BÀI 12: NATIVE QUERY có điều kiện ==========
    /**
     * Bài 12: Native Query có điều kiện
     * Yêu cầu: SQL thuần để lấy đồ chơi có giá > 40
     * SQL: SELECT * FROM toy WHERE price > 40
     * JPQL: Không có (dùng native query)
     * Chú ý: Tương tự bài 1, nhưng dùng SQL thuần thay JPQL
     */
    public List<Toy> nativeFindToysPriceGreaterThan40() {
        return em.createNativeQuery("SELECT * FROM toy WHERE price > 40", Toy.class).getResultList();
    }

    // ========== CRUD OPERATIONS ==========

    /**
     * READ: Lấy tất cả đồ chơi
     */
    public List<Toy> getAllToys() {
        return em.createQuery("SELECT t FROM Toy t ORDER BY t.id", Toy.class).getResultList();
    }

    /**
     * CREATE: Thêm đồ chơi mới
     */
    public void createToy(int id, String name, double price, java.sql.Date expDate, int brandId) {
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        try {
            Brand brand = em.find(Brand.class, brandId);
            if (brand == null) {
                throw new RuntimeException("Brand ID " + brandId + " không tồn tại");
            }
            Toy toy = new Toy(id, name, price, expDate, brand);
            em.persist(toy);
            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw ex;
        }
    }

    /**
     * UPDATE: Sửa giá đồ chơi
     */
    public void updateToyPrice(int id, double newPrice) {
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        try {
            Toy toy = em.find(Toy.class, id);
            if (toy == null) {
                throw new RuntimeException("Toy ID " + id + " không tồn tại");
            }
            toy.setPrice(newPrice);
            em.merge(toy);
            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw ex;
        }
    }

    /**
     * DELETE: Xóa đồ chơi
     */
    public void deleteToy(int id) {
        EntityTransaction tx = em.getTransaction();
        tx.begin();
        try {
            Toy toy = em.find(Toy.class, id);
            if (toy == null) {
                throw new RuntimeException("Toy ID " + id + " không tồn tại");
            }
            em.remove(toy);
            tx.commit();
        } catch (RuntimeException ex) {
            if (tx.isActive()) {
                tx.rollback();
            }
            throw ex;
        }
    }
}