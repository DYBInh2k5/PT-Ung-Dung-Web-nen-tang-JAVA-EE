package entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Toy Entity - Đại diện cho sản phẩm đồ chơi
 * Mapping: Lớp Java ↔ Bảng SQL "toy"
 */
@Entity
@Table(name = "toy")
public class Toy implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false)
    private String name;
    private double price;

    @Temporal(TemporalType.DATE)
    private Date expDate;

    @ManyToOne
    @JoinColumn(name = "brandId")
    private Brand brand;

    // Constructors
    public Toy() {}
    public Toy(int id, String name, double price, Date expDate, Brand brand) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.expDate = expDate;
        this.brand = brand;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public Date getExpDate() { return expDate; }
    public void setExpDate(Date expDate) { this.expDate = expDate; }
    public Brand getBrand() { return brand; }
    public void setBrand(Brand brand) { this.brand = brand; }
}
