package entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * Brand Entity - Đại diện cho hãng sản xuất đồ chơi
 * Mapping: Lớp Java ↔ Bảng SQL "brand"
 */
@Entity
@Table(name = "brand")
public class Brand implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false)
    private String name;

    // Constructors
    public Brand() {}
    public Brand(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}
