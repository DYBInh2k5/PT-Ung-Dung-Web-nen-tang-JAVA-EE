USE [Toyz];
GO
SET NOCOUNT ON;
SET DATEFORMAT ymd;
GO

/*
  Clean setup for the JPA exercise.
  This version uses the entity-friendly schema:
  Brand(id, name)
  Toy(id, description, price, expDate, brandId)
*/

BEGIN TRY
    BEGIN TRAN;

    IF OBJECT_ID('dbo.Toy', 'U') IS NOT NULL DROP TABLE dbo.Toy;
    IF OBJECT_ID('dbo.Brand', 'U') IS NOT NULL DROP TABLE dbo.Brand;

    CREATE TABLE dbo.Brand (
        id INT NOT NULL PRIMARY KEY,
        name NVARCHAR(100) NOT NULL
    );

    CREATE TABLE dbo.Toy (
        id INT NOT NULL PRIMARY KEY,
        description NVARCHAR(255) NULL,
        price DECIMAL(10,2) NOT NULL,
        expDate DATE NULL,
        brandId INT NOT NULL,
        CONSTRAINT FK_Toy_Brand FOREIGN KEY (brandId) REFERENCES dbo.Brand(id)
    );

    INSERT INTO dbo.Brand (id, name) VALUES
    (1, 'Lego'),
    (2, 'Barbie'),
    (3, 'Hot Wheels'),
    (4, 'Transformers'),
    (5, 'Playmobil');

    INSERT INTO dbo.Toy (id, description, price, expDate, brandId) VALUES
    (1, 'Lego City', 55.00, '2026-12-31', 1),
    (2, 'Barbie Dreamhouse', 120.00, '2027-01-15', 2),
    (3, 'Hot Wheels Car', 15.00, '2026-08-20', 3),
    (4, 'Transformers Optimus', 80.00, '2027-03-10', 4),
    (5, 'Playmobil Pirate', 35.00, '2026-11-05', 5),
    (6, 'Lego Star Wars', 70.00, '2026-09-09', 1),
    (7, 'Barbie Car', 45.00, '2027-02-14', 2),
    (8, 'Hot Wheels Track', 25.00, '2026-10-10', 3),
    (9, 'Transformers Bumblebee', 60.00, '2027-04-01', 4),
    (10, 'Playmobil Castle', 90.00, '2026-12-12', 5),
    (11, 'Lego Friends', 40.00, '2026-07-07', 1),
    (12, 'Barbie Doll', 30.00, '2027-05-05', 2),
    (13, 'Hot Wheels Monster', 55.00, '2026-06-06', 3),
    (14, 'Transformers Megatron', 100.00, '2027-06-06', 4),
    (15, 'Playmobil Zoo', 65.00, '2026-05-05', 5),
    (16, 'Lego Technic', 85.00, '2026-04-04', 1),
    (17, 'Barbie Camper', 95.00, '2027-07-07', 2),
    (18, 'Hot Wheels Loop', 20.00, '2026-03-03', 3),
    (19, 'Transformers Starscream', 110.00, '2027-08-08', 4),
    (20, 'Playmobil Farm', 75.00, '2026-02-02', 5);

    COMMIT TRAN;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
    THROW;
END CATCH;
GO

SELECT COUNT(*) AS BrandCount FROM dbo.Brand;
SELECT COUNT(*) AS ToyCount FROM dbo.Toy;
GO

/*
    CRUD examples for quick data manipulation.
    Uncomment and run the statements you need.
*/

-- INSERT: thêm 1 toy mới
-- INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
-- VALUES (47, 'Lego Special', 54.00, '2030-01-01', 1);

-- UPDATE: sửa giá và mô tả
-- UPDATE dbo.Toy
-- SET price = 59.00,
--     description = 'Lego Special Edition'
-- WHERE id = 47;

-- DELETE: xóa toy theo id
-- DELETE FROM dbo.Toy WHERE id = 47;

-- ADJUST: tăng giá 10% cho tất cả toy của hãng Lego
-- UPDATE dbo.Toy
-- SET price = price * 1.10
-- WHERE brandId = 1;

-- ADJUST: giảm giá 5 đơn vị cho toy giá trên 50
-- UPDATE dbo.Toy
-- SET price = price - 5
-- WHERE price > 50;
