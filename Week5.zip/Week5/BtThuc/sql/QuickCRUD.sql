USE [Toyz];
GO
SET NOCOUNT ON;
SET DATEFORMAT ymd;
GO

/*
  Quick CRUD practice for Toyz database.
  Tables used:
  - Brand(id, name)
  - Toy(id, description, price, expDate, brandId)
*/

/* =====================
   1) INSERT
   ===================== */
IF NOT EXISTS (SELECT 1 FROM dbo.Brand WHERE id = 8)
    INSERT INTO dbo.Brand (id, name) VALUES (8, 'Mattel');

IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 47)
    INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
    VALUES (47, 'Mattel Truck', 38.00, '2030-01-01', 8);

IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 48)
    INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
    VALUES (48, 'Mattel Car', 52.00, '2030-02-02', 8);

/* =====================
   2) SELECT
   ===================== */
SELECT b.id, b.name
FROM dbo.Brand b
ORDER BY b.id;

SELECT t.id, t.description, t.price, t.expDate, t.brandId
FROM dbo.Toy t
ORDER BY t.id;

SELECT t.id, t.description, t.price, b.name AS brandName
FROM dbo.Toy t
JOIN dbo.Brand b ON t.brandId = b.id
WHERE t.price > 30
ORDER BY t.price DESC;

SELECT t.id, t.description
FROM dbo.Toy t
WHERE t.description LIKE '%Lego%';

/* =====================
   3) UPDATE
   ===================== */
UPDATE dbo.Toy
SET price = 42.00
WHERE id = 47;

UPDATE dbo.Toy
SET description = 'Mattel Truck Pro'
WHERE id = 47;

UPDATE dbo.Toy
SET price = price + 5
WHERE brandId = 1;

/* =====================
   4) DELETE
   ===================== */
DELETE FROM dbo.Toy
WHERE id = 48;

/* xóa brand 8 sau khi xóa hết toy thuộc brand đó */
DELETE FROM dbo.Toy
WHERE brandId = 8;

DELETE FROM dbo.Brand
WHERE id = 8;

/* =====================
   5) CHECK
   ===================== */
SELECT COUNT(*) AS BrandCount FROM dbo.Brand;
SELECT COUNT(*) AS ToyCount FROM dbo.Toy;
GO
