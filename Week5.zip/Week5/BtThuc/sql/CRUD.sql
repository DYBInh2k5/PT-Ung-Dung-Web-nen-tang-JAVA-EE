USE [Toyz];
GO
SET NOCOUNT ON;
SET DATEFORMAT ymd;
GO

/*
  CRUD script for Toyz database.
  Assumes schema:
  Brand(id INT, name NVARCHAR(100))
  Toy(id INT, description NVARCHAR(255), price DECIMAL(10,2), expDate DATE, brandId INT)
*/

BEGIN TRY
    BEGIN TRAN;

    /* =====================================================
       INSERT: thêm dữ liệu mới
       ===================================================== */
    IF NOT EXISTS (SELECT 1 FROM dbo.Brand WHERE id = 6)
        INSERT INTO dbo.Brand (id, name) VALUES (6, 'Nerf');

    IF NOT EXISTS (SELECT 1 FROM dbo.Brand WHERE id = 7)
        INSERT INTO dbo.Brand (id, name) VALUES (7, 'Disney');

    IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 21)
        INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
        VALUES (21, 'Lego Rescue', 46.00, '2028-10-10', 1);

    IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 22)
        INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
        VALUES (22, 'Barbie Fashion', 59.00, '2028-11-11', 2);

    IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 23)
        INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
        VALUES (23, 'Nerf Blaster', 39.00, '2028-12-12', 6);

    IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 24)
        INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
        VALUES (24, 'Disney Castle', 88.00, '2029-01-13', 7);

    IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 25)
        INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
        VALUES (25, 'Hot Wheels Drift', 72.00, '2029-02-14', 3);

    IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 26)
        INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
        VALUES (26, 'Lego Builder', 44.00, '2029-03-15', 1);

    IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 27)
        INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
        VALUES (27, 'Barbie Beach', 57.00, '2029-04-16', 2);

    IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 28)
        INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
        VALUES (28, 'Nerf Shooter', 29.00, '2029-05-17', 6);

    IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 29)
        INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
        VALUES (29, 'Disney Train', 91.00, '2029-06-18', 7);

    IF NOT EXISTS (SELECT 1 FROM dbo.Toy WHERE id = 30)
        INSERT INTO dbo.Toy (id, description, price, expDate, brandId)
        VALUES (30, 'TF Robot Max', 103.00, '2029-07-19', 4);

    /* =====================================================
       SELECT: xem dữ liệu
       ===================================================== */
    SELECT b.id, b.name
    FROM dbo.Brand b
    ORDER BY b.id;

    SELECT t.id, t.description, t.price, t.expDate, t.brandId
    FROM dbo.Toy t
    ORDER BY t.id;

    SELECT t.id, t.description, t.price, b.name AS brandName
    FROM dbo.Toy t
    INNER JOIN dbo.Brand b ON t.brandId = b.id
    ORDER BY b.name, t.price DESC;

    SELECT t.*
    FROM dbo.Toy t
    WHERE t.description LIKE '%Lego%';

    /* =====================================================
       UPDATE: sửa dữ liệu
       ===================================================== */
    UPDATE dbo.Toy
    SET price = 62.00
    WHERE id = 7;

    UPDATE dbo.Toy
    SET description = 'Barbie Gift Set'
    WHERE id = 12;

    UPDATE dbo.Toy
    SET price = price + 5.00
    WHERE brandId = 1;

    UPDATE dbo.Toy
    SET expDate = '2029-12-31'
    WHERE id = 4;

     UPDATE dbo.Brand
     SET name = 'Nerf Elite'
     WHERE id = 6;

     UPDATE dbo.Toy
     SET description = 'Lego Rescue Set'
     WHERE id = 21;

     /* Điều chỉnh hàng loạt */
     UPDATE dbo.Toy
     SET price = price * 1.05
     WHERE brandId = 1;

     UPDATE dbo.Toy
     SET price = price - 3.00
     WHERE price BETWEEN 20 AND 40;

     /* =====================================================
         DELETE: xóa dữ liệu
         ===================================================== */
    DELETE FROM dbo.Toy
    WHERE id = 3;

    DELETE FROM dbo.Toy
    WHERE id = 18;

    /* Nếu muốn xóa hãng thì phải xóa toy thuộc hãng đó trước */
    DELETE FROM dbo.Toy
    WHERE brandId = 7;

    DELETE FROM dbo.Brand
    WHERE id = 7;

    /* Xóa toy giá quá thấp để dữ liệu query gọn hơn */
    DELETE FROM dbo.Toy
    WHERE price < 15;

    /* Xóa một toy theo mô tả */
    DELETE FROM dbo.Toy
    WHERE description = 'Nerf Blaster';

    /* Nếu muốn xóa toàn bộ toy của hãng NERF mới đổi tên */
    DELETE FROM dbo.Toy
    WHERE brandId = 6;

    COMMIT TRAN;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
    THROW;
END CATCH;
GO

/* =====================================================
    Kiểm tra nhanh sau CRUD
    ===================================================== */
SELECT b.id, b.name
FROM dbo.Brand b
ORDER BY b.id;

SELECT t.id, t.description, t.price, t.expDate, t.brandId
FROM dbo.Toy t
ORDER BY t.id;
GO

/* =====================================================
    Thống kê để test bài JPA
    ===================================================== */
SELECT COUNT(*) AS TotalBrands FROM dbo.Brand;
SELECT COUNT(*) AS TotalToys FROM dbo.Toy;

SELECT b.name AS BrandName, COUNT(*) AS ToyCount
FROM dbo.Toy t
INNER JOIN dbo.Brand b ON t.brandId = b.id
GROUP BY b.name
ORDER BY b.name;

SELECT TOP 10 t.id, t.description, t.price
FROM dbo.Toy t
WHERE t.price > 30
ORDER BY t.price DESC;
GO
