USE [Toyz]
GO

IF OBJECT_ID('dbo.toy', 'U') IS NOT NULL DROP TABLE dbo.toy
GO
IF OBJECT_ID('dbo.brand', 'U') IS NOT NULL DROP TABLE dbo.brand
GO

CREATE TABLE dbo.brand (
    id INT NOT NULL PRIMARY KEY,
    name NVARCHAR(100) NOT NULL
)
GO

CREATE TABLE dbo.toy (
    id INT NOT NULL PRIMARY KEY,
    description NVARCHAR(255) NULL,
    price DECIMAL(10,2) NULL,
    expDate DATE NULL,
    brandId INT NULL,
    CONSTRAINT FK_toy_brand FOREIGN KEY (brandId) REFERENCES dbo.brand(id)
)
GO

INSERT INTO dbo.brand (id, name) VALUES
(1, 'Lego'),
(2, 'Barbie'),
(3, 'Hot Wheels'),
(4, 'Transformers'),
(5, 'Playmobil')
GO

INSERT INTO dbo.toy (id, description, price, expDate, brandId) VALUES
(1, 'Lego City', 55, '2026-12-31', 1),
(2, 'Barbie Dreamhouse', 120, '2027-01-15', 2),
(3, 'Hot Wheels Car', 15, '2026-08-20', 3),
(4, 'Transformers Optimus', 80, '2027-03-10', 4),
(5, 'Playmobil Pirate', 35, '2026-11-05', 5),
(6, 'Lego Star Wars', 70, '2026-09-09', 1),
(7, 'Barbie Car', 45, '2027-02-14', 2),
(8, 'Hot Wheels Track', 25, '2026-10-10', 3),
(9, 'Transformers Bumblebee', 60, '2027-04-01', 4),
(10, 'Playmobil Castle', 90, '2026-12-12', 5),
(11, 'Lego Friends', 40, '2026-07-07', 1),
(12, 'Barbie Doll', 30, '2027-05-05', 2),
(13, 'Hot Wheels Monster', 55, '2026-06-06', 3),
(14, 'Transformers Megatron', 100, '2027-06-06', 4),
(15, 'Playmobil Zoo', 65, '2026-05-05', 5),
(16, 'Lego Technic', 85, '2026-04-04', 1),
(17, 'Barbie Camper', 95, '2027-07-07', 2),
(18, 'Hot Wheels Loop', 20, '2026-03-03', 3),
(19, 'Transformers Starscream', 110, '2027-08-08', 4),
(20, 'Playmobil Farm', 75, '2026-02-02', 5)
GO
