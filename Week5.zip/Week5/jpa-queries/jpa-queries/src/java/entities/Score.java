package entities;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "Score")
@NamedQueries({
    @NamedQuery(name = "Score.findBySubjectAndStudent", query = "SELECT s FROM Score s WHERE s.subject = :subject AND s.student.id = :studentId")
})
public class Score implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "student_id", referencedColumnName = "Id")
    private Student student;

    @Column(name = "Subject")
    private String subject;

    @Column(name = "Value")
    private Double value;

    public Score() {}

    public Score(Student student, String subject, Double value) {
        this.student = student;
        this.subject = subject;
        this.value = value;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    public Double getValue() { return value; }
    public void setValue(Double value) { this.value = value; }
}
