package demo;

import entities.Student;
import entities.Score;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ManageTransactionDemo {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-queriesPU");
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();

            // Business logic: Thêm sinh viên và điểm cho sinh viên đó
            Student s = new Student(8888);
            s.setFirstName("Tran");
            s.setLastName("Action");
            s.setEmail("tran.action@example.com");
            em.persist(s);

            Score score = new Score(s, "Java", 9.5);
            em.persist(score);

            em.getTransaction().commit();
            System.out.println("Thêm sinh viên và điểm thành công!");
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}
