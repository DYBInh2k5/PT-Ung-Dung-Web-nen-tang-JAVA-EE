package demo;

import entities.Student;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TransactionDemo {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa-queriesPU");
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();

            // Business logic: ví dụ thêm sinh viên mới
            Student s = new Student(9999);
            s.setFirstName("Demo");
            s.setLastName("User");
            s.setEmail("demo@example.com");
            em.persist(s);

            em.getTransaction().commit();
            System.out.println("Thêm sinh viên thành công!");
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}
