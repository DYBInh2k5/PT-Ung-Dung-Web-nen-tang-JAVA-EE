/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sessionbeans;

import entities.Student;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author PHT
 */
@Stateless
public class StudentFacade extends AbstractFacade<Student> {
    public List<Student> findAllOrderByFirstName() {
        return em.createQuery("SELECT s FROM Student s ORDER BY s.firstName", Student.class)
                .getResultList();
    }

    @PersistenceContext(unitName = "jpa-queriesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public StudentFacade() {
        super(Student.class);
    }

    public List<Student> findByFirstName(String firstName) {
        // Tìm theo firstName
        List<Student> list = em.createQuery("SELECT s FROM Student s WHERE s.firstName = :fn", Student.class)
                .setParameter("fn", firstName)
                .getResultList();
        return list;
    }

        public List<Student> findByEmail(String email) {
            // Tìm theo email LIKE và ORDER BY firstName, lastName
            return em.createQuery(
                    "SELECT s FROM Student s WHERE s.email LIKE :email ORDER BY s.firstName, s.lastName", Student.class)
                    .setParameter("email", "%" + email + "%")
                    .getResultList();
        }
        
        
        
}
