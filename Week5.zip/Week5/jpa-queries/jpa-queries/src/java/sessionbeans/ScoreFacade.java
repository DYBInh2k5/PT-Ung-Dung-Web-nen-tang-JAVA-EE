package sessionbeans;

import entities.Score;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class ScoreFacade extends AbstractFacade<Score> {
                            public java.util.List<entities.Score> getAllScoresNative() {
                                return getEntityManager().createNativeQuery(
                                    "SELECT * FROM Score", entities.Score.class)
                                    .getResultList();
                            }
                        public java.util.List<Object[]> findScoresBySubjectNative(String subject) {
                            return getEntityManager().createNativeQuery(
                                "SELECT * FROM Score WHERE Subject = ?1")
                                .setParameter(1, subject)
                                .getResultList();
                        }

                        public java.util.List<Object[]> findScoresBySubjectAndMinValueNative(String subject, double minValue) {
                            return getEntityManager().createNativeQuery(
                                "SELECT * FROM Score WHERE Subject = ?1 AND Value > ?2")
                                .setParameter(1, subject)
                                .setParameter(2, minValue)
                                .getResultList();
                        }

                        public java.util.List<Object[]> findScoresByStudentAndValueRangeNative(int studentId, double minValue, double maxValue) {
                            return getEntityManager().createNativeQuery(
                                "SELECT * FROM Score WHERE student_id = ?1 AND Value BETWEEN ?2 AND ?3")
                                .setParameter(1, studentId)
                                .setParameter(2, minValue)
                                .setParameter(3, maxValue)
                                .getResultList();
                        }
                    public java.util.List<Object[]> avgScoreByStudentNative() {
                        return getEntityManager().createNativeQuery(
                            "SELECT student_id, AVG([Value]) as avgScore FROM Score GROUP BY student_id")
                            .getResultList();
                    }
                public entities.Score findScoreBySubjectAndStudent(String subject, int studentId) {
                    try {
                        return getEntityManager().createNamedQuery("Score.findBySubjectAndStudent", entities.Score.class)
                            .setParameter("subject", subject)
                            .setParameter("studentId", studentId)
                            .getSingleResult();
                    } catch(Exception e) {
                        return null;
                    }
                }
            public java.util.List<Object[]> avgScoreByStudent() {
                return getEntityManager().createQuery(
                    "SELECT s.student.id, s.student.firstName, s.student.lastName, AVG(s.value) FROM Score s GROUP BY s.student.id, s.student.firstName, s.student.lastName"
                ).getResultList();
            }

            public java.util.List<entities.Score> findBySubjectAndMinValue(String subject, double minValue) {
                return getEntityManager().createQuery(
                    "SELECT s FROM Score s WHERE s.subject = :subject AND s.value > :minValue", entities.Score.class)
                    .setParameter("subject", subject)
                    .setParameter("minValue", minValue)
                    .getResultList();
            }

            public java.util.List<entities.Score> findByStudentAndValueRange(int studentId, double minValue, double maxValue) {
                return getEntityManager().createQuery(
                    "SELECT s FROM Score s WHERE s.student.id = :studentId AND s.value BETWEEN :minValue AND :maxValue", entities.Score.class)
                    .setParameter("studentId", studentId)
                    .setParameter("minValue", minValue)
                    .setParameter("maxValue", maxValue)
                    .getResultList();
            }
        public java.util.List<Score> findAllOrderByStudentFirstName() {
            return getEntityManager().createQuery(
                "SELECT s FROM Score s ORDER BY s.student.firstName", Score.class)
                .getResultList();
        }
    @PersistenceContext(unitName = "jpa-queriesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ScoreFacade() {
        super(Score.class);
    }
}
