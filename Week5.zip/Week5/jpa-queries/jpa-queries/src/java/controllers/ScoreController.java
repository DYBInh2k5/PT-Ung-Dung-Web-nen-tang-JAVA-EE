package controllers;

import entities.Score;
import entities.Student;
import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sessionbeans.ScoreFacade;
import sessionbeans.StudentFacade;

@WebServlet(name = "ScoreController", urlPatterns = {"/score"})
public class ScoreController extends HttpServlet {
            protected void showAllScoresNative(HttpServletRequest request, HttpServletResponse response)
                    throws ServletException, IOException{
                java.util.List<entities.Score> list = scoreFacade.getAllScoresNative();
                response.setContentType("text/html;charset=UTF-8");
                java.io.PrintWriter out = response.getWriter();
                out.println("<html><head><title>Danh sách điểm (native)</title></head><body>");
                out.println("<h2>Danh sách điểm (native query)</h2>");
                out.println("<table border='1'><tr><th>ID</th><th>Student</th><th>Subject</th><th>Value</th></tr>");
                for(entities.Score s:list){
                    out.println("<tr><td>"+s.getId()+"</td><td>"+s.getStudent().getFirstName()+" "+s.getStudent().getLastName()+"</td><td>"+s.getSubject()+"</td><td>"+s.getValue()+"</td></tr>");
                }
                out.println("</table></body></html>");
            }
        protected void showScoresBySubjectNative(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException{
            String subject = request.getParameter("subject");
            java.util.List<Object[]> list = scoreFacade.findScoresBySubjectNative(subject);
            response.setContentType("text/html;charset=UTF-8");
            java.io.PrintWriter out = response.getWriter();
            out.println("<html><head><title>Điểm theo môn (native)</title></head><body>");
            out.println("<h2>Điểm theo môn: " + subject + " (native query)</h2>");
            out.println("<table border='1'><tr><th>ID</th><th>StudentId</th><th>Subject</th><th>Value</th></tr>");
            for(Object[] row:list){
                out.println("<tr><td>"+row[0]+"</td><td>"+row[1]+"</td><td>"+row[2]+"</td><td>"+row[3]+"</td></tr>");
            }
            out.println("</table></body></html>");
        }

        protected void showScoresBySubjectAndMinValueNative(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException{
            String subject = request.getParameter("subject");
            double minValue = Double.parseDouble(request.getParameter("minValue"));
            java.util.List<Object[]> list = scoreFacade.findScoresBySubjectAndMinValueNative(subject, minValue);
            response.setContentType("text/html;charset=UTF-8");
            java.io.PrintWriter out = response.getWriter();
            out.println("<html><head><title>Điểm theo môn và min (native)</title></head><body>");
            out.println("<h2>Điểm môn: " + subject + ", lớn hơn: " + minValue + " (native query)</h2>");
            out.println("<table border='1'><tr><th>ID</th><th>StudentId</th><th>Subject</th><th>Value</th></tr>");
            for(Object[] row:list){
                out.println("<tr><td>"+row[0]+"</td><td>"+row[1]+"</td><td>"+row[2]+"</td><td>"+row[3]+"</td></tr>");
            }
            out.println("</table></body></html>");
        }

        protected void showScoresByStudentAndValueRangeNative(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException{
            int studentId = Integer.parseInt(request.getParameter("studentId"));
            double minValue = Double.parseDouble(request.getParameter("minValue"));
            double maxValue = Double.parseDouble(request.getParameter("maxValue"));
            java.util.List<Object[]> list = scoreFacade.findScoresByStudentAndValueRangeNative(studentId, minValue, maxValue);
            response.setContentType("text/html;charset=UTF-8");
            java.io.PrintWriter out = response.getWriter();
            out.println("<html><head><title>Điểm theo sinh viên và khoảng (native)</title></head><body>");
            out.println("<h2>Điểm sinh viên: " + studentId + ", từ: " + minValue + " đến: " + maxValue + " (native query)</h2>");
            out.println("<table border='1'><tr><th>ID</th><th>StudentId</th><th>Subject</th><th>Value</th></tr>");
            for(Object[] row:list){
                out.println("<tr><td>"+row[0]+"</td><td>"+row[1]+"</td><td>"+row[2]+"</td><td>"+row[3]+"</td></tr>");
            }
            out.println("</table></body></html>");
        }

        protected void showAvgScoreByStudentNative(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException{
            java.util.List<Object[]> list = scoreFacade.avgScoreByStudentNative();
            response.setContentType("text/html;charset=UTF-8");
            java.io.PrintWriter out = response.getWriter();
            out.println("<html><head><title>Điểm TB từng sinh viên (native)</title></head><body>");
            out.println("<h2>Điểm trung bình từng sinh viên (native query)</h2>");
            out.println("<table border='1'><tr><th>StudentId</th><th>AvgScore</th></tr>");
            for(Object[] row:list){
                out.println("<tr><td>"+row[0]+"</td><td>"+row[1]+"</td></tr>");
            }
            out.println("</table></body></html>");
        }
    protected void showAddScoreForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        java.util.List<Student> students = studentFacade.findAll();
        response.setContentType("text/html;charset=UTF-8");
        java.io.PrintWriter out = response.getWriter();
        out.println("<html><head><title>Nhập điểm</title></head><body>");
        out.println("<h2>Nhập điểm cho sinh viên</h2>");
        out.println("<form method='post' action='score?action=addScore'>");
        out.println("Sinh viên: <select name='studentId'>");
        for(Student s:students){
            out.println("<option value='"+s.getId()+"'>"+s.getFirstName()+" "+s.getLastName()+"</option>");
        }
        out.println("</select><br/>");
        out.println("Môn học: <input type='text' name='subject'/><br/>");
        out.println("Điểm: <input type='text' name='value'/><br/>");
        out.println("<input type='submit' value='Nhập điểm'/>");
        out.println("</form></body></html>");
    }

    protected void addScore(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        String studentIdStr = request.getParameter("studentId");
        String subject = request.getParameter("subject");
        String valueStr = request.getParameter("value");
        try {
            Integer studentId = Integer.parseInt(studentIdStr);
            Double value = Double.parseDouble(valueStr);
            Student student = studentFacade.find(studentId);
            if (student != null) {
                Score score = new Score(student, subject, value);
                scoreFacade.create(score);
                response.getWriter().println("Đã nhập điểm thành công! <a href='score?action=showAllScores'>Xem danh sách điểm</a>");
            } else {
                response.getWriter().println("Không tìm thấy sinh viên!");
            }
        } catch(Exception e) {
            response.getWriter().println("Lỗi: " + e.getMessage());
        }
    }

        @Override
        protected void doGet(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {
            String action = request.getParameter("action");
            if (action == null) {
                response.getWriter().println("ScoreController: No action.");
                return;
            }
            switch(action) {
                case "showAllScores":
                    showAllScores(request, response);
                    break;
                case "showAllScoresNative":
                    showAllScoresNative(request, response);
                    break;
                case "showAddScoreForm":
                    showAddScoreForm(request, response);
                    break;
                case "showScoresBySubjectNative":
                    showScoresBySubjectNative(request, response);
                    break;
                case "showScoresBySubjectAndMinValueNative":
                    showScoresBySubjectAndMinValueNative(request, response);
                    break;
                case "showScoresByStudentAndValueRangeNative":
                    showScoresByStudentAndValueRangeNative(request, response);
                    break;
                case "showAvgScoreByStudentNative":
                    showAvgScoreByStudentNative(request, response);
                    break;
                default:
                    response.getWriter().println("ScoreController: Unknown action.");
            }
        }

        protected void showAllScores(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException{
            java.util.List<entities.Score> list = scoreFacade.findAll();
            response.setContentType("text/html;charset=UTF-8");
            java.io.PrintWriter out = response.getWriter();
            out.println("<html><head><title>Danh sách điểm</title></head><body>");
            out.println("<h2>Danh sách điểm</h2>");
            out.println("<table border='1'><tr><th>ID</th><th>Student</th><th>Subject</th><th>Value</th></tr>");
            for(entities.Score s:list){
                out.println("<tr><td>"+s.getId()+"</td><td>"+s.getStudent().getFirstName()+" "+s.getStudent().getLastName()+"</td><td>"+s.getSubject()+"</td><td>"+s.getValue()+"</td></tr>");
            }
            out.println("</table></body></html>");
        }
    @EJB
    private ScoreFacade scoreFacade;
    @EJB
    private StudentFacade studentFacade;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            response.getWriter().println("ScoreController: No action.");
            return;
        }
        switch(action) {
            case "addScore":
                addScore(request, response);
                break;
            default:
                response.getWriter().println("ScoreController: Unknown action.");
        }
    }
}
