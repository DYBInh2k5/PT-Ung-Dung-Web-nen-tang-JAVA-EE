/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.Student;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sessionbeans.StudentFacade;

/**
 *
 * @author PHT
 */
@WebServlet(name = "StudentController", urlPatterns = {"/student"})
public class StudentController extends HttpServlet {
                    protected void showAddStudentForm(HttpServletRequest request, HttpServletResponse response)
                            throws ServletException, IOException{
                        response.setContentType("text/html;charset=UTF-8");
                        PrintWriter out = response.getWriter();
                        out.println("<html><head><title>Thêm sinh viên</title></head><body>");
                        out.println("<h2>Thêm sinh viên mới</h2>");
                        out.println("<form method='post' action='student?action=addStudent'>");
                        out.println("ID: <input type='text' name='id'/><br/>");
                        out.println("First Name: <input type='text' name='firstName'/><br/>");
                        out.println("Last Name: <input type='text' name='lastName'/><br/>");
                        out.println("Email: <input type='text' name='email'/><br/>");
                        out.println("<input type='submit' value='Thêm'/>");
                        out.println("</form></body></html>");
                    }

                    protected void addStudent(HttpServletRequest request, HttpServletResponse response)
                            throws ServletException, IOException{
                        String idStr = request.getParameter("id");
                        String firstName = request.getParameter("firstName");
                        String lastName = request.getParameter("lastName");
                        String email = request.getParameter("email");
                        try {
                            int id = Integer.parseInt(idStr);
                            entities.Student s = new entities.Student(id);
                            s.setFirstName(firstName);
                            s.setLastName(lastName);
                            s.setEmail(email);
                            sf.create(s);
                            response.getWriter().println("Đã thêm sinh viên thành công! <a href='student?action=showAllStudents'>Xem danh sách</a>");
                        } catch(Exception e) {
                            response.getWriter().println("Lỗi: " + e.getMessage());
                        }
                    }
                protected void showAllStudents(HttpServletRequest request, HttpServletResponse response)
                        throws ServletException, IOException{
                    List<Student> list = sf.findAll();
                    response.setContentType("text/html;charset=UTF-8");
                    PrintWriter out = response.getWriter();
                    out.println("<html><head><title>Danh sách sinh viên</title></head><body>");
                    out.println("<h2>Danh sách sinh viên</h2>");
                    out.println("<table border='1'><tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Email</th></tr>");
                    for(Student s:list){
                        out.println("<tr><td>"+s.getId()+"</td><td>"+s.getFirstName()+"</td><td>"+s.getLastName()+"</td><td>"+s.getEmail()+"</td></tr>");
                    }
                    out.println("</table></body></html>");
                }
            protected void orderByFirstName(HttpServletRequest request, HttpServletResponse response)
                    throws ServletException, IOException{
                List<Student> list = sf.findAllOrderByFirstName();
                for(Student s:list){
                    System.out.println("Id: "+s.getId());
                    System.out.println("First name: "+s.getFirstName());
                    System.out.println("Last name: "+s.getLastName());
                    System.out.println("Email: "+s.getEmail());
                }
            }
        @EJB
        private sessionbeans.ScoreFacade scoreFacade;

        protected void randomScore(HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException{
            List<Student> students = sf.findAll();
            java.util.Random rand = new java.util.Random();
            for(Student s : students) {
                double value = 1.0 * Math.round(rand.nextDouble() * 1000) / 100; // 0.00 - 10.00
                entities.Score score = new entities.Score(s, "Math", value);
                scoreFacade.create(score);
                System.out.println("Student: " + s.getFirstName() + " " + s.getLastName() + ", Score: " + value);
            }
        }
    protected void findAllOrderByFirstName(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        List<Student> list = sf.findAllOrderByFirstName();
        for(Student s:list){
            System.out.println("Id: "+s.getId());
            System.out.println("First name: "+s.getFirstName());
            System.out.println("Last name: "+s.getLastName());
            System.out.println("Email: "+s.getEmail());
        }
    }

    @EJB(name = "sf")
    private StudentFacade sf;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
                                                            case "showAddStudentForm":
                                                                showAddStudentForm(request, response);
                                                                break;
                                                            case "addStudent":
                                                                addStudent(request, response);
                                                                break;
                                                case "showAllStudents":
                                                    showAllStudents(request, response);
                                                    break;
                                    case "orderByFirstName":
                                        orderByFirstName(request, response);
                                        break;
                        case "randomScore":
                            randomScore(request, response);
                            break;
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        if (action == null) {
            return;
        }
        switch(action){
            case "findByFirstName":
                findByFirstName(request, response);
                break;
            case "findByEmail":
                findByEmail(request, response);
                break;
            case "findAllOrderByFirstName":
                findAllOrderByFirstName(request, response);
                break;
            case "orderByFirstName":
                orderByFirstName(request, response);
                break;
            case "randomScore":
                randomScore(request, response);
                break;
        }
    }
    
    protected void findByFirstName(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        String firstName = request.getParameter("firstName");
        List<Student> list = sf.findByFirstName(firstName);
        for(Student s:list){
            System.out.println("Id: "+s.getId());
            System.out.println("First name: "+s.getFirstName());
            System.out.println("Last name: "+s.getLastName());
        }
    }

    protected void findByEmail(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
        String email = request.getParameter("email");
        List<Student> list = sf.findByEmail(email);
        for(Student s:list){
            System.out.println("Id: "+s.getId());
            System.out.println("First name: "+s.getFirstName());
            System.out.println("Last name: "+s.getLastName());
            System.out.println("Email: "+s.getEmail());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
