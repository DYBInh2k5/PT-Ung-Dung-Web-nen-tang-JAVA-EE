/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sessionbeans;

import entities.Student;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Voduybinhv
 */
@Stateless
public class StudentFacade extends AbstractFacade<Student> {

    @PersistenceContext(unitName = "jpa-queriesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public StudentFacade() {
        super(Student.class);
    }
    
    public List<Student> findByFirstName(String firtName) {
        // Tìm theo first
        List<Student> list = em.createQuery(
                "SELECT u FROM Student u WHERE s.firstName = :firstName", Student.class
        )
                .setParameter("first", firstName)
                .getResultList();
        return list;
        
    }
    
    
}
