﻿-- ========================================
-- CREATE DATABASE
-- ========================================
CREATE DATABASE StudentDb;
GO

USE StudentDb;
GO

-- ========================================
-- CREATE TABLE Student
-- ========================================
CREATE TABLE Student (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    DateOfBirth DATE,
    Address NVARCHAR(200),
    Phone VARCHAR(15),
    Email VARCHAR(100) -- email liên lạc
);
GO

-- ========================================
-- CREATE TABLE Account
-- (Role đặt cuối)
-- ========================================
CREATE TABLE Account (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    StudentId INT UNIQUE,

    Username VARCHAR(100),
    PasswordHash VARBINARY(256),
    Salt UNIQUEIDENTIFIER,

    Email VARCHAR(100) UNIQUE,
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME DEFAULT GETDATE(),

    Role VARCHAR(20) DEFAULT 'Student', -- đặt cuối

    FOREIGN KEY (StudentId) REFERENCES Student(Id)
);
GO

-- ========================================
-- INSERT DATA
-- ========================================
DECLARE @FirstNames TABLE (Name NVARCHAR(50));
INSERT INTO @FirstNames VALUES
('James'),('John'),('Robert'),('Michael'),('William'),
('David'),('Richard'),('Joseph'),('Thomas'),('Charles'),
('Christopher'),('Daniel'),('Matthew'),('Anthony'),('Mark');

DECLARE @LastNames TABLE (Name NVARCHAR(50));
INSERT INTO @LastNames VALUES
('Smith'),('Johnson'),('Williams'),('Brown'),('Jones'),
('Garcia'),('Miller'),('Davis'),('Rodriguez'),('Martinez');

DECLARE @i INT = 1;

WHILE @i <= 100
BEGIN
    DECLARE @FirstName NVARCHAR(50);
    DECLARE @LastName NVARCHAR(50);
    DECLARE @Email VARCHAR(100);
    DECLARE @StudentId INT;
    DECLARE @Salt UNIQUEIDENTIFIER;
    DECLARE @Password NVARCHAR(10) = '1';
    DECLARE @Hash VARBINARY(256);

    -- Random tên
    SELECT TOP 1 @FirstName = Name FROM @FirstNames ORDER BY NEWID();
    SELECT TOP 1 @LastName = Name FROM @LastNames ORDER BY NEWID();

    -- Email unique
    SET @Email = LOWER(@FirstName + '.' + @LastName + CAST(@i AS VARCHAR) + '@gmail.com');

    -- Insert Student
    INSERT INTO Student (FirstName, LastName, DateOfBirth, Address, Phone, Email)
    VALUES (
        @FirstName,
        @LastName,
        DATEADD(DAY, - (18*365 + ABS(CHECKSUM(NEWID())) % (7*365)), GETDATE()),
        CONCAT(CAST(ABS(CHECKSUM(NEWID())) % 999 AS VARCHAR), ' Street, New York'),
        CONCAT('09', RIGHT('00000000' + CAST(ABS(CHECKSUM(NEWID())) % 100000000 AS VARCHAR), 8)),
        @Email
    );

    SET @StudentId = SCOPE_IDENTITY();

    -- Salt + Hash password = '1'
    SET @Salt = NEWID();
    SET @Hash = HASHBYTES('SHA2_256', @Password + CAST(@Salt AS NVARCHAR));

    -- Insert Account
    INSERT INTO Account (StudentId, Username, PasswordHash, Salt, Email, Role)
    VALUES (
        @StudentId,
        @Email,
        @Hash,
        @Salt,
        @Email,
        'Student'
    );

    SET @i = @i + 1;
END;
GO

-- ========================================
-- TEST LOGIN
-- ========================================
DECLARE @Email VARCHAR(100) = 'john.smith1@gmail.com';
DECLARE @Password NVARCHAR(10) = '1';

SELECT *
FROM Account
WHERE Email = @Email
AND PasswordHash = HASHBYTES(
    'SHA2_256',
    @Password + CAST(Salt AS NVARCHAR)
);
GO