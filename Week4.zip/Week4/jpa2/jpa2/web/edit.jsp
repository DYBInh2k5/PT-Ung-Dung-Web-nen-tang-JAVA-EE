<%-- 
    Document   : edit
    Created on : Apr 3, 2026, 1:44:33 PM
    Author     : PHT
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Toy Edit</h1>
        <hr/>
        <form action="toy">
            Id:<br/>
            <input type="text" name="id" value="${toy.id}" readonly/><br/>
            Name:<br/>
            <!--Ưu tiên dữ liệu user vừa nhập > dữ liệu DB-->
            <input type="text" name="name" value="${param.name!=null?param.name:toy.name}"/><br/>
            Price:<br/>
            <input type="number" step="0.01" name="price" value="${param.price!=null?param.price:toy.price}"/><br/>
            Expired date:<br/>
            <c:if test="${param.expDate!=null}">
                <input type="date" name="expDate" value="${param.expDate}"/>
            </c:if>
            <c:if test="${param.expDate==null}">
                <input type="date" name="expDate" value="<fmt:formatDate value="${toy.expDate}" pattern="yyyy-MM-dd" />"/>
            </c:if>
            <br/>
            Brand:<br/>
            <select name="brandId">
                <c:forEach var="brand" items="${list}">
                    <c:if test="${param.brandId!=null}">
                        <option value="${brand.id}" ${param.brandId==brand.id?"selected":""}>${brand.name}</option>
                    </c:if>
                    <c:if test="${param.brandId==null}">
                        <option value="${brand.id}" ${toy.brand.id==brand.id?"selected":""}>${brand.name}</option>
                    </c:if>
                </c:forEach>
            </select>
            <input type="hidden" name="action" value="edit_handler" /><br/>
            <button type="submit" name="op" value="update">Update</button>
            <button type="submit" name="op" value="cancel">Cancel</button>
        </form>
        <i style="color:red;">${errorMessage}</i>
    </body>
</html>
