<%-- 
    Document   : edit
    Created on : Apr 3, 2026, 1:44:33 PM
    Author     : PHT
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Toy Create</h1>
        <hr/>
        <form action="toy">
            Id:<br/>
            <input type="text" name="id" value="${param.id}" /><br/>
            Name:<br/>
            <input type="text" name="name" value="${param.name}"/><br/>
            Price:<br/>
            <input type="number" step="0.01" name="price" value="${param.price}"/><br/>
            Expired date:<br/>
            <input type="date" name="expDate" value="${param.expDate}"/>
            <br/>
            Brand:<br/>
            <select name="brandId">
                <c:forEach var="brand" items="${list}">
                    <option value="${brand.id}" ${param.brandId==brand.id?"selected":""}>${brand.name}</option>
                </c:forEach>
            </select>
            <input type="hidden" name="action" value="create_handler" /><br/>
            <button type="submit" name="op" value="create">Create</button>
            <button type="submit" name="op" value="cancel">Cancel</button>
        </form>
        <i style="color:red;">${errorMessage}</i>
    </body>
</html>
