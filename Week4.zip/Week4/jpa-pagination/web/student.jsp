<%-- 
    Document   : student
    Created on : Apr 10, 2026, 2:21:42 PM
    Author     : PHT
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <style>
            .pagination {
                margin-top: 12px;
                display: flex;
                gap: 6px;
                flex-wrap: wrap;
                align-items: center;
            }
            .pagination a,
            .pagination span {
                display: inline-block;
                padding: 6px 10px;
                border: 1px solid #999;
                border-radius: 4px;
                text-decoration: none;
                color: #222;
                background: #f7f7f7;
                font-family: Arial, sans-serif;
                font-size: 14px;
            }
            .pagination a:hover {
                background: #e9e9e9;
            }
            .pagination .active {
                background: #1f6feb;
                color: #fff;
                border-color: #1f6feb;
                font-weight: bold;
            }
            .pagination .disabled {
                color: #999;
                background: #fafafa;
            }
        </style>
    </head>
    <body>
        <h1>Student List</h1>
        <hr/>
        <table border="1" cellspacing="0" cellpadding="4">
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Date Of Birth</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Email</th>
            </tr>
            <c:forEach var="student" items="${list}">
            <tr>
                <td>${student.id}</td>
                <td>${student.firstName}</td>
                <td>${student.lastName}</td>
                <td><fmt:formatDate value="${student.dateOfBirth}" pattern="yyyy-MM-dd"/></td>
                <td>${student.address}</td>
                <td>${student.phone}</td>
                <td>${student.email}</td>
            </tr>
            </c:forEach>
        </table>

        <div class="pagination">
            <c:choose>
                <c:when test="${currentPage > 1}">
                    <a href="student?page=1">First</a>
                    <a href="student?page=${currentPage - 1}">Previous</a>
                </c:when>
                <c:otherwise>
                    <span class="disabled">First</span>
                    <span class="disabled">Previous</span>
                </c:otherwise>
            </c:choose>

            <c:forEach begin="1" end="${totalPages}" var="pageNumber">
                <c:choose>
                    <c:when test="${pageNumber == currentPage}">
                        <span class="active">${pageNumber}</span>
                    </c:when>
                    <c:otherwise>
                        <a href="student?page=${pageNumber}">${pageNumber}</a>
                    </c:otherwise>
                </c:choose>
            </c:forEach>

            <c:choose>
                <c:when test="${currentPage < totalPages}">
                    <a href="student?page=${currentPage + 1}">Next</a>
                    <a href="student?page=${totalPages}">Last</a>
                </c:when>
                <c:otherwise>
                    <span class="disabled">Next</span>
                    <span class="disabled">Last</span>
                </c:otherwise>
            </c:choose>
        </div>
    </body>
</html>
