<%@ page contentType="text/html;charset=UTF-8" %>
<html>
<head>
    <title>Calculator</title>
</head>
<body>

<h2>Calculator MVC</h2>

<form method="post" action="calculator">
    A: <input type="text" name="a" 
        value="<%= request.getParameter("a") != null ? request.getParameter("a") : "" %>"><br><br>

    B: <input type="text" name="b" 
        value="<%= request.getParameter("b") != null ? request.getParameter("b") : "" %>"><br><br>

    <select name="op">
        <option value="add">+</option>
        <option value="sub">-</option>
        <option value="mul">*</option>
        <option value="div">/</option>
    </select><br><br>

    <input type="submit" value="Calculate">
</form>

<!-- RESULT -->
<%
    if (request.getAttribute("result") != null) {
%>
    <h3>Kết quả: <%= request.getAttribute("result") %></h3>
<%
    }
%>

<!-- ERROR -->
<%
    if (request.getAttribute("error") != null) {
%>
    <h3 style="color:red;"><%= request.getAttribute("error") %></h3>
<%
    }
%>

</body>
</html>