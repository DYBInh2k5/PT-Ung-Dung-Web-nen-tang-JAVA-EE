package model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Voduybinhv
 */
public class Calculator {

    public double calculate(double a, double b, String op) throws Exception {
        switch (op) {
            case "add": return a + b;
            case "sub": return a - b;
            case "mul": return a * b;
            case "div":
                if (b == 0) throw new Exception("Không thể chia cho 0!");
                return a / b;
            default:
                throw new Exception("Phép toán không hợp lệ!");
        }
    }
}
