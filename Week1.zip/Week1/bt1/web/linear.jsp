<%-- 
    Document   : linear
    Created on : Mar 20, 2026, 2:55:23 PM
    Author     : Voduybinhv
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Hello World!</h1>
        <form method="post" action="linear">
    a: <input type="text" name="a"><br>
    b: <input type="text" name="b"><br>
    <input type="submit" value="Giải">
</form>

<h3>${result}</h3>
<h3 style="color:red;">${error}</h3>
    </body>
</html>
