package controller;

import model.LinearEquation;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/linear")
public class LinearServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        req.getRequestDispatcher("linear.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        try {
            double a = Double.parseDouble(req.getParameter("a"));
            double b = Double.parseDouble(req.getParameter("b"));

            LinearEquation eq = new LinearEquation();
            String result = eq.solve(a, b);

            req.setAttribute("result", result);

        } catch (Exception e) {
            req.setAttribute("error", "Nhập sai!");
        }

        req.getRequestDispatcher("linear.jsp").forward(req, res);
    }
}