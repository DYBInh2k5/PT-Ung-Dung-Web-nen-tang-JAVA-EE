/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

public class LinearEquation {

    public String solve(double a, double b) {
        if (a == 0) {
            if (b == 0) return "Vô số nghiệm";
            else return "Vô nghiệm";
        }
        return "x = " + (-b / a);
    }
}