package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.TemperatureConverter;

@WebServlet("/convertTemp")
public class TemperatureServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        req.getRequestDispatcher("temperature.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        try {
            double value = Double.parseDouble(req.getParameter("value"));
            String type = req.getParameter("type");

            double result;

            if ("CtoF".equals(type)) {
                result = TemperatureConverter.cToF(value);
                req.setAttribute("result", value + "°C = " + result + "°F");
            } else {
                result = TemperatureConverter.fToC(value);
                req.setAttribute("result", value + "°F = " + result + "°C");
            }

        } catch (NumberFormatException e) {
            req.setAttribute("error", "Nhập sai số!");
        }

        req.getRequestDispatcher("temperature.jsp").forward(req, res);
    }
}