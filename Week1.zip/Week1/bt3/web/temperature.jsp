<%-- 
    Document   : temperature.jsp
    Created on : Mar 20, 2026, 4:01:00 PM
    Author     : Voduybinhv
--%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Đổi nhiệt độ</title>
</head>
<body>

<h2>Đổi nhiệt độ</h2>

<form method="post" action="convertTemp">
    Nhập:
    <input type="text" name="value" value="${param.value}"><br><br>

    <select name="type">
        <option value="CtoF">C → F</option>
        <option value="FtoC">F → C</option>
    </select>

    <br><br>
    <input type="submit" value="Chuyển">
</form>

<hr>

<p style="color:green;">${result}</p>
<p style="color:red;">${error}</p>

</body>
</html>