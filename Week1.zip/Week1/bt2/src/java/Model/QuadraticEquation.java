package model;

public class QuadraticEquation {

    public static Result solve(double a, double b, double c) {

        Result result = new Result();

        // bậc nhất
        if (a == 0) {
            if (b == 0) {
                result.setMessage(c == 0 ? "Vô số nghiệm" : "Vô nghiệm");
            } else {
                result.setX1(-c / b);
                result.setMessage("Phương trình bậc nhất");
            }
            return result;
        }

        double delta = b * b - 4 * a * c;

        if (delta < 0) {
            result.setMessage("Vô nghiệm");
        } else if (Math.abs(delta) < 1e-6) {
            double x = -b / (2 * a);
            result.setX1(x);
            result.setMessage("Nghiệm kép");
        } else {
            double x1 = (-b + Math.sqrt(delta)) / (2 * a);
            double x2 = (-b - Math.sqrt(delta)) / (2 * a);
            result.setX1(x1);
            result.setX2(x2);
            result.setMessage("Hai nghiệm phân biệt");
        }

        return result;
    }
}