/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

public class Result {
    private Double x1;
    private Double x2;
    private String message;

    public Result() {}

    public Result(Double x1, Double x2, String message) {
        this.x1 = x1;
        this.x2 = x2;
        this.message = message;
    }

    public Double getX1() { return x1; }
    public Double getX2() { return x2; }
    public String getMessage() { return message; }

    public void setX1(Double x1) { this.x1 = x1; }
    public void setX2(Double x2) { this.x2 = x2; }
    public void setMessage(String message) { this.message = message; }
}