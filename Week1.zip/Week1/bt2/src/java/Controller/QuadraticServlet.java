package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.QuadraticEquation;
import model.Result;

@WebServlet("/quadratic")
public class QuadraticServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        req.getRequestDispatcher("quadratic.jsp").forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        try {
            double a = Double.parseDouble(req.getParameter("a"));
            double b = Double.parseDouble(req.getParameter("b"));
            double c = Double.parseDouble(req.getParameter("c"));

            Result result = QuadraticEquation.solve(a, b, c);

            req.setAttribute("result", result);

        } catch (NumberFormatException e) {
            req.setAttribute("error", "Vui lòng nhập số hợp lệ!");
        }

        req.getRequestDispatcher("quadratic.jsp").forward(req, res);
    }
}