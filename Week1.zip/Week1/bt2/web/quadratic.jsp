<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Giải phương trình bậc 2</title>
</head>
<body>

<h2>Giải phương trình: ax² + bx + c = 0</h2>

<form method="post" action="quadratic">
    a: <input type="text" name="a" value="${param.a}"><br>
    b: <input type="text" name="b" value="${param.b}"><br>
    c: <input type="text" name="c" value="${param.c}"><br>
    <input type="submit" value="Giải">
</form>

<hr>

<!-- Hiển thị lỗi -->
<p style="color:red;">${error}</p>

<!-- Hiển thị kết quả -->
<c:if test="${not empty result}">
    <p>${result.message}</p>

    <c:if test="${result.x1 != null}">
        <p>x1 = ${result.x1}</p>
    </c:if>

    <c:if test="${result.x2 != null}">
        <p>x2 = ${result.x2}</p>
    </c:if>
</c:if>

</body>
</html>