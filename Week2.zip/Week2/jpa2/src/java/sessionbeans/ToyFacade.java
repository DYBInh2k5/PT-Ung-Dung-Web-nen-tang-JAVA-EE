/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sessionbeans;

import entities.Toy;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author PHT
 */
@Stateless
public class ToyFacade extends AbstractFacade<Toy> {

    @PersistenceContext(unitName = "jpa2PU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ToyFacade() {
        super(Toy.class);
    }

    public List<Toy> findByFilters(String keyword, String brandId, int page, int pageSize, String sortBy, String sortDir) {
        StringBuilder jpql = new StringBuilder("SELECT t FROM Toy t WHERE 1=1");

        boolean hasKeyword = keyword != null && !keyword.trim().isEmpty();
        boolean hasBrand = brandId != null && !brandId.trim().isEmpty();

        if (hasKeyword) {
            jpql.append(" AND LOWER(t.name) LIKE :keyword");
        }
        if (hasBrand) {
            jpql.append(" AND t.brand.id = :brandId");
        }

        String safeSortBy;
        if ("name".equalsIgnoreCase(sortBy)) {
            safeSortBy = "t.name";
        } else if ("price".equalsIgnoreCase(sortBy)) {
            safeSortBy = "t.price";
        } else if ("expDate".equalsIgnoreCase(sortBy)) {
            safeSortBy = "t.expDate";
        } else if ("brand".equalsIgnoreCase(sortBy)) {
            safeSortBy = "t.brand.id";
        } else {
            safeSortBy = "t.id";
        }

        String safeSortDir = "desc".equalsIgnoreCase(sortDir) ? "DESC" : "ASC";
        jpql.append(" ORDER BY ").append(safeSortBy).append(" ").append(safeSortDir);

        TypedQuery<Toy> query = em.createQuery(jpql.toString(), Toy.class);
        if (hasKeyword) {
            query.setParameter("keyword", "%" + keyword.trim().toLowerCase() + "%");
        }
        if (hasBrand) {
            query.setParameter("brandId", brandId.trim());
        }

        int safePage = page < 1 ? 1 : page;
        int safePageSize = pageSize < 1 ? 10 : pageSize;
        query.setFirstResult((safePage - 1) * safePageSize);
        query.setMaxResults(safePageSize);
        return query.getResultList();
    }

    public int countByFilters(String keyword, String brandId) {
        StringBuilder jpql = new StringBuilder("SELECT COUNT(t) FROM Toy t WHERE 1=1");

        boolean hasKeyword = keyword != null && !keyword.trim().isEmpty();
        boolean hasBrand = brandId != null && !brandId.trim().isEmpty();

        if (hasKeyword) {
            jpql.append(" AND LOWER(t.name) LIKE :keyword");
        }
        if (hasBrand) {
            jpql.append(" AND t.brand.id = :brandId");
        }

        TypedQuery<Long> query = em.createQuery(jpql.toString(), Long.class);
        if (hasKeyword) {
            query.setParameter("keyword", "%" + keyword.trim().toLowerCase() + "%");
        }
        if (hasBrand) {
            query.setParameter("brandId", brandId.trim());
        }

        Long count = query.getSingleResult();
        return count == null ? 0 : count.intValue();
    }
    
}
