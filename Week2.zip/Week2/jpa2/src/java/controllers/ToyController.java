/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import entities.Brand;
import entities.Toy;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sessionbeans.BrandFacade;
import sessionbeans.ToyFacade;

/**
 *
 * @author PHT
 */
@WebServlet(name = "ToyController", urlPatterns = {"/toy"})
public class ToyController extends HttpServlet {

    @EJB(name = "tf")
    private ToyFacade tf;

    @EJB(name = "bf")
    private BrandFacade bf;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }
        switch (action) {

            case "dashboard":
                dashboard(request, response);
                break;
            case "brands":
                brands(request, response);
                break;
            case "about":
                about(request, response);
                break;

            case "list":
                list(request, response);
                break;
            case "edit":
                // hiện view edit.jsp
                edit(request, response);
                break;
            case "detail":
                detail(request, response);
                break;
            case "deletePage":
                deletePage(request, response);
                break;
            case "new":
                newToy(request, response);
                break;
            case "confirm":
                confirm(request, response);
                break;
            case "formHandler":
                formHandler(request, response);
                break;
            case "create":
                create(request, response);
                break;
            case "update":
                update(request, response);
                break;
            case "delete":
                delete(request, response);
                break;
            case "deleteBulk":
                deleteBulk(request, response);
                break;
            default:
                list(request, response);
                break;
        }

    }

    protected void dashboard(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            request.setAttribute("toyCount", tf.count());
            request.setAttribute("brandCount", bf.count());
            request.setAttribute("generatedAt", new Date());
            request.getRequestDispatcher("/dashboard.jsp").forward(request, response);
        } catch (Exception ex) {
            forwardError(request, response, "Can't load dashboard", ex, "toy?action=dashboard");
        }
    }

    protected void brands(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            List<Brand> brands = bf.findAll();
            request.setAttribute("brands", brands);
            request.getRequestDispatcher("/brands.jsp").forward(request, response);
        } catch (Exception ex) {
            forwardError(request, response, "Can't load brands", ex, "toy?action=brands");
        }
    }

    protected void about(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/about.jsp").forward(request, response);
    }

    protected void list(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            boolean reset = "1".equals(request.getParameter("reset"));
            if (reset) {
                clearListState(request);
            }

            String keyword = getStateParam(request, "q", "");
            String brandFilter = getStateParam(request, "brandFilter", "");
            int page = parsePage(getStateParam(request, "page", "1"));
            String sortBy = normalizeSortBy(getStateParam(request, "sortBy", "id"));
            String sortDir = normalizeSortDir(getStateParam(request, "sortDir", "asc"));
            int pageSize = 5;

            int totalItems = tf.countByFilters(keyword, brandFilter);
            int totalPages = totalItems == 0 ? 1 : (int) Math.ceil((double) totalItems / pageSize);
            if (page > totalPages) {
                page = totalPages;
            }

            //doc danh sach toy co loc + phan trang
            List<Toy> list = tf.findByFilters(keyword, brandFilter, page, pageSize, sortBy, sortDir);
            List<Brand> brandList = bf.findAll();

            request.setAttribute("successMessage", popFlashMessage(request, "flashSuccess"));
            String flashError = popFlashMessage(request, "flashError");
            if (request.getAttribute("errorMessage") == null) {
                request.setAttribute("errorMessage", flashError);
            }
            request.setAttribute("highlightId", popFlashMessage(request, "flashHighlightId"));

            //luu list vao request de view truy cap để view toy.jsp truy cập
            request.setAttribute("list", list);
            request.setAttribute("brandList", brandList);
            request.setAttribute("q", keyword);
            request.setAttribute("brandFilter", brandFilter);
            request.setAttribute("currentPage", page);
            request.setAttribute("totalPages", totalPages);
            request.setAttribute("totalItems", totalItems);
            request.setAttribute("sortBy", sortBy);
            request.setAttribute("sortDir", sortDir);
            request.setAttribute("updateMarks", getUpdateMarks(request));

            saveListState(request, keyword, brandFilter, page, sortBy, sortDir);
            //chuyen request & response cho view xu ly tiep
            request.getRequestDispatcher("/toy.jsp").forward(request, response);
        } catch (Exception ex) {
            forwardError(request, response, "Can't read data", ex, "toy?action=list");
        }
    }
    protected void edit(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            //lấy thông tin từ client
            String id = request.getParameter("id");
            //đọc mẫu tin tương ứng với id
            Toy toy = tf.find(id);
            List<Brand> brandList = bf.findAll();
            if (toy == null) {
                throw new Exception("Toy not found");
            }
            
            //truyền toy cho view edit.jsp
            request.setAttribute("toy", toy);
            request.setAttribute("brandList", brandList);
            request.setAttribute("q", getTrimmed(request.getParameter("q")));
            request.setAttribute("brandFilter", getTrimmed(request.getParameter("brandFilter")));
            request.setAttribute("page", parsePage(request.getParameter("page")));
            request.setAttribute("sortBy", normalizeSortBy(request.getParameter("sortBy")));
            request.setAttribute("sortDir", normalizeSortDir(request.getParameter("sortDir")));
            //luu list vao request de view truy cap để view toy.jsp truy cập
            //chuyen request & response cho view xu ly tiep
            request.getRequestDispatcher("/edit.jsp").forward(request, response);
        } catch (Exception ex) {
            forwardError(request, response, "Can't read edit data", ex, buildListUrl(request));
        }
    }

    protected void detail(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String id = getTrimmed(request.getParameter("id"));
            if (id.isEmpty()) {
                throw new Exception("Id is required");
            }

            Toy toy = tf.find(id);
            if (toy == null) {
                throw new Exception("Toy not found");
            }

            request.setAttribute("toy", toy);
            request.setAttribute("q", getTrimmed(request.getParameter("q")));
            request.setAttribute("brandFilter", getTrimmed(request.getParameter("brandFilter")));
            request.setAttribute("page", parsePage(request.getParameter("page")));
            request.setAttribute("sortBy", normalizeSortBy(request.getParameter("sortBy")));
            request.setAttribute("sortDir", normalizeSortDir(request.getParameter("sortDir")));
            request.getRequestDispatcher("/detail.jsp").forward(request, response);
        } catch (Exception ex) {
            setFlashMessage(request, "flashError", "Can't read detail: " + ex.getMessage());
            response.sendRedirect(buildListUrl(request));
        }
    }

    protected void deletePage(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String id = getTrimmed(request.getParameter("id"));
            if (id.isEmpty()) {
                throw new Exception("Id is required");
            }

            Toy toy = tf.find(id);
            if (toy == null) {
                throw new Exception("Toy not found");
            }

            request.setAttribute("toy", toy);
            request.setAttribute("q", getTrimmed(request.getParameter("q")));
            request.setAttribute("brandFilter", getTrimmed(request.getParameter("brandFilter")));
            request.setAttribute("page", parsePage(request.getParameter("page")));
            request.setAttribute("sortBy", normalizeSortBy(request.getParameter("sortBy")));
            request.setAttribute("sortDir", normalizeSortDir(request.getParameter("sortDir")));
            request.getRequestDispatcher("/delete.jsp").forward(request, response);
        } catch (Exception ex) {
            setFlashMessage(request, "flashError", "Can't open delete page: " + ex.getMessage());
            response.sendRedirect(buildListUrl(request));
        }
    }


    protected void newToy(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        list(request, response);
    }

    protected void confirm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String formIntent = getTrimmed(request.getParameter("formIntent"));
            if (formIntent.isEmpty()) {
                throw new Exception("Missing form intent");
            }

            request.setAttribute("formIntent", formIntent);
            request.setAttribute("q", getTrimmed(request.getParameter("q")));
            request.setAttribute("brandFilter", getTrimmed(request.getParameter("brandFilter")));
            request.setAttribute("page", parsePage(request.getParameter("page")));
            request.setAttribute("sortBy", normalizeSortBy(request.getParameter("sortBy")));
            request.setAttribute("sortDir", normalizeSortDir(request.getParameter("sortDir")));

            if ("create".equals(formIntent) || "update".equals(formIntent)) {
                String id = getTrimmed(request.getParameter("id"));
                String name = getTrimmed(request.getParameter("name"));
                String price = getTrimmed(request.getParameter("price"));
                String expDate = getTrimmed(request.getParameter("expDate"));
                String brand = getTrimmed(request.getParameter("brand"));

                request.setAttribute("id", id);
                request.setAttribute("name", name);
                request.setAttribute("price", price);
                request.setAttribute("expDate", expDate);
                request.setAttribute("brand", brand);

                if (!brand.isEmpty()) {
                    Brand b = bf.find(brand);
                    request.setAttribute("brandName", b == null ? "" : b.getName());
                }
            } else if ("delete".equals(formIntent)) {
                response.sendRedirect(buildDeletePageUrl(request));
                return;
            } else if ("deleteBulk".equals(formIntent)) {
                Set<String> allIds = collectBulkIds(request.getParameterValues("ids"), request.getParameter("selectionIds"));
                if (allIds.isEmpty()) {
                    throw new Exception("Please select at least one toy");
                }
                StringBuilder csv = new StringBuilder();
                for (String id : allIds) {
                    if (csv.length() > 0) {
                        csv.append(",");
                    }
                    csv.append(id);
                }
                request.setAttribute("selectionIds", csv.toString());
                request.setAttribute("bulkCount", allIds.size());
            } else {
                throw new Exception("Unsupported form intent: " + formIntent);
            }

            request.getRequestDispatcher("/confirm.jsp").forward(request, response);
        } catch (Exception ex) {
            setFlashMessage(request, "flashError", "Can't prepare confirmation: " + ex.getMessage());
            response.sendRedirect(buildListUrl(request));
        }
    }

    protected void formHandler(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String formIntent = getTrimmed(request.getParameter("formIntent"));
        String confirmed = getTrimmed(request.getParameter("confirmed"));

        if (!"yes".equalsIgnoreCase(confirmed)) {
            setFlashMessage(request, "flashError", "Action was not confirmed.");
            response.sendRedirect(buildListUrl(request));
            return;
        }

        switch (formIntent) {
            case "create":
                create(request, response);
                break;
            case "update":
                update(request, response);
                break;
            case "deleteBulk":
                deleteBulk(request, response);
                break;
            default:
                setFlashMessage(request, "flashError", "Unsupported action. Single delete must use delete confirmation page.");
                response.sendRedirect(buildListUrl(request));
                break;
        }
    }

    protected void create(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String id = getTrimmed(request.getParameter("id"));
            String name = getTrimmed(request.getParameter("name"));
            String priceStr = getTrimmed(request.getParameter("price"));
            String expDateStr = getTrimmed(request.getParameter("expDate"));
            String brandId = getTrimmed(request.getParameter("brand"));

            if (id.isEmpty()) {
                throw new Exception("Id is required");
            }
            if (id.length() > 3) {
                throw new Exception("Id max length is 3");
            }
            if (tf.find(id) != null) {
                throw new Exception("Id already exists");
            }
            if (name.isEmpty()) {
                throw new Exception("Name is required");
            }

            Toy toy = new Toy();
            toy.setId(id);
            toy.setName(name);
            toy.setPrice(parsePrice(priceStr));
            toy.setExpDate(parseExpDate(expDateStr));
            toy.setBrand(resolveBrand(brandId));

            tf.create(toy);
            setFlashMessage(request, "flashSuccess", "Created toy: " + id);
            setUpdateMark(request, id);
            response.sendRedirect(buildListUrl(request));
        } catch (Exception ex) {
            request.setAttribute("errorMessage", "Can't create data: " + ex.getMessage());
            request.setAttribute("createId", getTrimmed(request.getParameter("id")));
            request.setAttribute("createName", getTrimmed(request.getParameter("name")));
            request.setAttribute("createPrice", getTrimmed(request.getParameter("price")));
            request.setAttribute("createExpDate", getTrimmed(request.getParameter("expDate")));
            request.setAttribute("createBrand", getTrimmed(request.getParameter("brand")));
            list(request, response);
        }
    }

    protected void update(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String id = getTrimmed(request.getParameter("id"));
            String name = getTrimmed(request.getParameter("name"));
            String priceStr = getTrimmed(request.getParameter("price"));
            String expDateStr = getTrimmed(request.getParameter("expDate"));
            String brandId = getTrimmed(request.getParameter("brand"));

            if (id.isEmpty()) {
                throw new Exception("Id is required");
            }

            Toy toy = tf.find(id);
            if (toy == null) {
                throw new Exception("Toy not found");
            }
            if (name.isEmpty()) {
                throw new Exception("Name is required");
            }

            toy.setName(name);
            toy.setPrice(parsePrice(priceStr));
            toy.setExpDate(parseExpDate(expDateStr));
            toy.setBrand(resolveBrand(brandId));

            tf.edit(toy);
            setFlashMessage(request, "flashSuccess", "Updated toy: " + id);
            setFlashMessage(request, "flashHighlightId", id);
            setUpdateMark(request, id);
            response.sendRedirect(buildListUrl(request));
        } catch (Exception ex) {
            request.setAttribute("errorMessage", "Can't update data: " + ex.getMessage());
            request.setAttribute("editName", getTrimmed(request.getParameter("name")));
            request.setAttribute("editPrice", getTrimmed(request.getParameter("price")));
            request.setAttribute("editExpDate", getTrimmed(request.getParameter("expDate")));
            request.setAttribute("editBrand", getTrimmed(request.getParameter("brand")));
            edit(request, response);
        }
    }

    protected void delete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String id = getTrimmed(request.getParameter("id"));
            if (id.isEmpty()) {
                throw new Exception("Id is required");
            }
            Toy toy = tf.find(id);
            if (toy == null) {
                setFlashMessage(request, "flashSuccess", "Toy " + id + " was already deleted.");
                setFlashMessage(request, "flashHighlightId", "");
                response.sendRedirect(buildListUrl(request));
                return;
            }
            tf.remove(toy);
            removeUpdateMark(request, id);
            setFlashMessage(request, "flashSuccess", "Deleted toy: " + id);
            setFlashMessage(request, "flashHighlightId", "");
            response.sendRedirect(buildListUrl(request));
        } catch (Exception ex) {
            setFlashMessage(request, "flashError", "Can't delete data: " + ex.getMessage());
            response.sendRedirect(buildListUrl(request));
        }
    }

    protected void deleteBulk(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            Set<String> allIds = collectBulkIds(request.getParameterValues("ids"), request.getParameter("selectionIds"));
            if (allIds.isEmpty()) {
                throw new Exception("Please select at least one toy");
            }

            int deletedCount = 0;
            int notFoundCount = 0;
            for (String id : allIds) {
                Toy toy = tf.find(id);
                if (toy == null) {
                    notFoundCount++;
                    continue;
                }
                tf.remove(toy);
                removeUpdateMark(request, id);
                deletedCount++;
            }

            StringBuilder msg = new StringBuilder();
            msg.append("Deleted ").append(deletedCount).append(" toy(s)");
            if (notFoundCount > 0) {
                msg.append(", ").append(notFoundCount).append(" not found");
            }
            setFlashMessage(request, "flashSuccess", msg.toString());
            setFlashMessage(request, "flashHighlightId", "");
            response.sendRedirect(buildListUrl(request));
        } catch (Exception ex) {
            setFlashMessage(request, "flashError", "Can't delete selected data: " + ex.getMessage());
            response.sendRedirect(buildListUrl(request));
        }
    }

    private java.util.Date parseExpDate(String expDateStr) {
        if (expDateStr == null || expDateStr.trim().isEmpty()) {
            return null;
        }

        String value = expDateStr.trim();
        if (value.contains("T")) {
            LocalDateTime ldt = LocalDateTime.parse(value, DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
            return java.sql.Timestamp.valueOf(ldt);
        }

        LocalDate ld = LocalDate.parse(value, DateTimeFormatter.ISO_LOCAL_DATE);
        return java.sql.Date.valueOf(ld);
    }

    private Brand resolveBrand(String brandId) {
        if (brandId == null || brandId.trim().isEmpty()) {
            return null;
        }
        Brand brand = bf.find(brandId.trim());
        if (brand == null) {
            throw new IllegalArgumentException("Brand not found");
        }
        return brand;
    }

    private BigDecimal parsePrice(String priceStr) {
        if (priceStr == null || priceStr.trim().isEmpty()) {
            throw new IllegalArgumentException("Price is required");
        }
        BigDecimal price = new BigDecimal(priceStr.trim());
        if (price.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Price must be >= 0");
        }
        return price;
    }

    private String getTrimmed(String value) {
        return value == null ? "" : value.trim();
    }

    private int parsePage(String pageStr) {
        try {
            int page = Integer.parseInt(pageStr);
            return page < 1 ? 1 : page;
        } catch (Exception ex) {
            return 1;
        }
    }

    private String buildListUrl(HttpServletRequest request) {
        String q = getTrimmed(request.getParameter("q"));
        String brandFilter = getTrimmed(request.getParameter("brandFilter"));
        int page = parsePage(request.getParameter("page"));
        String sortBy = normalizeSortBy(request.getParameter("sortBy"));
        String sortDir = normalizeSortDir(request.getParameter("sortDir"));

        StringBuilder sb = new StringBuilder("toy?action=list");
        appendQueryParam(sb, "q", q);
        appendQueryParam(sb, "brandFilter", brandFilter);
        appendQueryParam(sb, "page", String.valueOf(page));
        appendQueryParam(sb, "sortBy", sortBy);
        appendQueryParam(sb, "sortDir", sortDir);
        return sb.toString();
    }

    private String buildDeletePageUrl(HttpServletRequest request) {
        String id = getTrimmed(request.getParameter("id"));
        String q = getTrimmed(request.getParameter("q"));
        String brandFilter = getTrimmed(request.getParameter("brandFilter"));
        int page = parsePage(request.getParameter("page"));
        String sortBy = normalizeSortBy(request.getParameter("sortBy"));
        String sortDir = normalizeSortDir(request.getParameter("sortDir"));

        StringBuilder sb = new StringBuilder("toy?action=deletePage");
        appendQueryParam(sb, "id", id);
        appendQueryParam(sb, "q", q);
        appendQueryParam(sb, "brandFilter", brandFilter);
        appendQueryParam(sb, "page", String.valueOf(page));
        appendQueryParam(sb, "sortBy", sortBy);
        appendQueryParam(sb, "sortDir", sortDir);
        return sb.toString();
    }

    private String normalizeSortBy(String sortBy) {
        if ("name".equalsIgnoreCase(sortBy)
                || "price".equalsIgnoreCase(sortBy)
                || "expDate".equalsIgnoreCase(sortBy)
                || "brand".equalsIgnoreCase(sortBy)) {
            return sortBy;
        }
        return "id";
    }

    private String normalizeSortDir(String sortDir) {
        return "desc".equalsIgnoreCase(sortDir) ? "desc" : "asc";
    }

    private String getStateParam(HttpServletRequest request, String key, String defaultValue) {
        String fromRequest = request.getParameter(key);
        if (fromRequest != null) {
            return fromRequest.trim();
        }

        Object fromSession = request.getSession().getAttribute("toy." + key);
        return fromSession == null ? defaultValue : String.valueOf(fromSession);
    }

    private void saveListState(HttpServletRequest request, String q, String brandFilter,
            int page, String sortBy, String sortDir) {
        request.getSession().setAttribute("toy.q", q);
        request.getSession().setAttribute("toy.brandFilter", brandFilter);
        request.getSession().setAttribute("toy.page", String.valueOf(page));
        request.getSession().setAttribute("toy.sortBy", sortBy);
        request.getSession().setAttribute("toy.sortDir", sortDir);
    }

    private void clearListState(HttpServletRequest request) {
        request.getSession().removeAttribute("toy.q");
        request.getSession().removeAttribute("toy.brandFilter");
        request.getSession().removeAttribute("toy.page");
        request.getSession().removeAttribute("toy.sortBy");
        request.getSession().removeAttribute("toy.sortDir");
    }

    private Set<String> collectBulkIds(String[] ids, String selectionIdsCsv) {
        Set<String> allIds = new LinkedHashSet<String>();
        if (ids != null) {
            for (String rawId : ids) {
                String id = getTrimmed(rawId);
                if (!id.isEmpty()) {
                    allIds.add(id);
                }
            }
        }

        if (selectionIdsCsv != null && !selectionIdsCsv.trim().isEmpty()) {
            String[] parts = selectionIdsCsv.split(",");
            for (String part : parts) {
                String id = getTrimmed(part);
                if (!id.isEmpty()) {
                    allIds.add(id);
                }
            }
        }
        return allIds;
    }

    private Map<String, String> getUpdateMarks(HttpServletRequest request) {
        Object data = request.getSession().getAttribute("toy.updateMarks");
        if (data instanceof Map) {
            return (Map<String, String>) data;
        }
        Map<String, String> map = new HashMap<String, String>();
        request.getSession().setAttribute("toy.updateMarks", map);
        return map;
    }

    private void setUpdateMark(HttpServletRequest request, String id) {
        Map<String, String> marks = getUpdateMarks(request);
        String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        marks.put(id, now);
    }

    private void removeUpdateMark(HttpServletRequest request, String id) {
        Map<String, String> marks = getUpdateMarks(request);
        marks.remove(id);
    }

    private void setFlashMessage(HttpServletRequest request, String key, String message) {
        request.getSession().setAttribute(key, message);
    }

    private String popFlashMessage(HttpServletRequest request, String key) {
        Object value = request.getSession().getAttribute(key);
        if (value != null) {
            request.getSession().removeAttribute(key);
            return String.valueOf(value);
        }
        return null;
    }

    private void forwardError(HttpServletRequest request, HttpServletResponse response,
            String userMessage, Exception ex, String backUrl)
            throws ServletException, IOException {
        request.setAttribute("errorMessage", userMessage);
        request.setAttribute("errorDetail", ex == null ? "" : ex.getMessage());
        request.setAttribute("errorTime", new Date());
        request.setAttribute("backUrl", (backUrl == null || backUrl.isEmpty()) ? "toy?action=list" : backUrl);
        request.getRequestDispatcher("/error.jsp").forward(request, response);
    }

    private void appendQueryParam(StringBuilder sb, String key, String value) {
        if (value == null || value.isEmpty()) {
            return;
        }
        try {
            sb.append("&")
                    .append(key)
                    .append("=")
                    .append(URLEncoder.encode(value, "UTF-8"));
        } catch (Exception ex) {
            sb.append("&")
                    .append(key)
                    .append("=")
                    .append(value);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
