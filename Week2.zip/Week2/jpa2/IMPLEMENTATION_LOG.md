# Implementation Log

Date: 2026-04-03

## Completed Features

- CRUD for `Toy`:
  - List toys
  - Create toy
  - Edit/update toy
  - Delete toy
  - Detail view with back/edit/delete shortcuts
  - Bulk delete (multi-select)
- Brand combobox loaded from `Brand` table in create/edit forms.
- Date-time editing and display:
  - Input uses `datetime-local`
  - Backend parses date-only and date-time values
  - List shows `dd/MM/yyyy HH:mm`
- Validation hardening in controller:
  - Required fields (`id`, `name`, `price`)
  - `id` max length = 3
  - Reject duplicate `id`
  - Reject negative `price`
  - Reject unknown brand id
  - Detailed delete feedback (not-found vs deleted)
- Search + filter:
  - Keyword filter by toy name
  - Brand filter
- Pagination:
  - 5 items per page
  - Previous/Next + page numbers
- Sorting:
  - Sort by id, name, price, expDate, brand id
  - Asc/desc toggle per column
  - Active sort direction indicator on header
  - Server-side safe whitelist for sortable fields
- State persistence for UX:
  - Keep `q`, `brandFilter`, `page`, `sortBy`, `sortDir` after create/update/delete
  - Keep same context when navigating edit/cancel
  - Persist list state in session when revisiting list
  - `Reset` clears persisted list state (`reset=1`)
  - Create form has explicit `Cancel` action
  - Save confirmations for create/update and bulk delete
  - Highlight updated row when returning to list
  - Fixed invalid nested forms in list table operations
  - Keep bulk selected rows across pagination/filter using sessionStorage
  - Clear stored selections automatically after delete/reset

- Additional list detail:
  - `Updated At` column based on latest create/update action per toy

- Delete safety UX:
  - Dedicated `delete.jsp` confirmation page
  - Prominent irreversible-action warning message

## Stability Fixes

- Fixed parameter name conflict between filter brand and entity brand:
  - Filter uses `brandFilter`
  - Entity uses `brand`
- Updated JSP string comparisons to use EL `eq`.
- Added `glassfish-web.xml` with fixed context root `/jpa2`.
- Set deploy-on-save to false in NetBeans project properties to reduce Weld redeploy inconsistency issues.

## Main Edited Files

- `src/java/controllers/ToyController.java`
- `src/java/sessionbeans/ToyFacade.java`
- `web/toy.jsp`
- `web/edit.jsp`
- `web/detail.jsp`
- `web/WEB-INF/glassfish-web.xml`
- `nbproject/project.properties`
