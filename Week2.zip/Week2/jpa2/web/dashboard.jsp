<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Dashboard</title>
    </head>
    <body>
        <h1>Dashboard</h1>
        <hr/>
        <table border="1" cellspacing="0" cellpadding="6">
            <tr>
                <th align="left">Total Toys</th>
                <td>${toyCount}</td>
            </tr>
            <tr>
                <th align="left">Total Brands</th>
                <td>${brandCount}</td>
            </tr>
            <tr>
                <th align="left">Generated At</th>
                <td><fmt:formatDate value="${generatedAt}" pattern="dd/MM/yyyy HH:mm:ss"/></td>
            </tr>
        </table>
        <br/>
        <a href="toy?action=list">Toy Management</a> |
        <a href="toy?action=brands">Brand List</a> |
        <a href="toy?action=about">About</a>
    </body>
</html>
