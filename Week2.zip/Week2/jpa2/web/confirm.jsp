<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Confirm Action</title>
    </head>
    <body>
        <h1>Confirm Action</h1>
        <hr/>

        <c:choose>
            <c:when test="${formIntent eq 'create'}">
                <h3>Create Toy</h3>
            </c:when>
            <c:when test="${formIntent eq 'update'}">
                <h3>Update Toy</h3>
            </c:when>
            <c:when test="${formIntent eq 'delete'}">
                <h3>Delete Toy</h3>
            </c:when>
            <c:when test="${formIntent eq 'deleteBulk'}">
                <h3>Delete Selected Toys</h3>
            </c:when>
        </c:choose>

        <c:if test="${formIntent eq 'create' || formIntent eq 'update'}">
            <table border="1" cellspacing="0" cellpadding="6">
                <tr><th align="left">Id</th><td>${id}</td></tr>
                <tr><th align="left">Name</th><td>${name}</td></tr>
                <tr><th align="left">Price</th><td>${price}</td></tr>
                <tr><th align="left">Expired Date</th><td>${expDate}</td></tr>
                <tr><th align="left">Brand</th><td>${brand} ${not empty brandName ? '- '.concat(brandName) : ''}</td></tr>
            </table>
        </c:if>

        <c:if test="${formIntent eq 'delete'}">
            <table border="1" cellspacing="0" cellpadding="6">
                <tr><th align="left">Id</th><td>${id}</td></tr>
                <tr><th align="left">Name</th><td>${name}</td></tr>
                <tr><th align="left">Price</th><td><fmt:formatNumber value="${price}" type="currency"/></td></tr>
            </table>
        </c:if>

        <c:if test="${formIntent eq 'deleteBulk'}">
            <p>You are about to delete <strong>${bulkCount}</strong> selected toy(s).</p>
        </c:if>

        <br/>
        <c:url var="cancelUrl" value="toy">
            <c:param name="action" value="list"/>
            <c:param name="q" value="${q}"/>
            <c:param name="brandFilter" value="${brandFilter}"/>
            <c:param name="page" value="${page}"/>
            <c:param name="sortBy" value="${sortBy}"/>
            <c:param name="sortDir" value="${sortDir}"/>
        </c:url>

        <form action="toy" method="post" style="display:inline;">
            <input type="hidden" name="action" value="formHandler"/>
            <input type="hidden" name="formIntent" value="${formIntent}"/>
            <input type="hidden" name="confirmed" value="yes"/>
            <input type="hidden" name="q" value="${q}"/>
            <input type="hidden" name="brandFilter" value="${brandFilter}"/>
            <input type="hidden" name="page" value="${page}"/>
            <input type="hidden" name="sortBy" value="${sortBy}"/>
            <input type="hidden" name="sortDir" value="${sortDir}"/>

            <c:if test="${formIntent eq 'create' || formIntent eq 'update'}">
                <input type="hidden" name="id" value="${id}"/>
                <input type="hidden" name="name" value="${name}"/>
                <input type="hidden" name="price" value="${price}"/>
                <input type="hidden" name="expDate" value="${expDate}"/>
                <input type="hidden" name="brand" value="${brand}"/>
            </c:if>

            <c:if test="${formIntent eq 'delete'}">
                <input type="hidden" name="id" value="${id}"/>
            </c:if>

            <c:if test="${formIntent eq 'deleteBulk'}">
                <input type="hidden" name="selectionIds" value="${selectionIds}"/>
            </c:if>

            <input type="submit" value="Confirm"/>
        </form>
        <a href="${cancelUrl}">Cancel</a>
    </body>
</html>
