<%-- 
    Document   : error
    Created on : Apr 3, 2026, 1:33:34 PM
    Author     : Voduybinhv
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Error</title>
    </head>
    <body>
        <h1>Error</h1>
        <hr/>
        <div style="color: #b00020; margin-bottom: 8px;">
            <strong>${errorMessage}</strong>
        </div>

        <c:if test="${not empty errorDetail}">
            <div style="margin-bottom: 8px;">
                <strong>Detail:</strong> ${errorDetail}
            </div>
        </c:if>

        <c:if test="${not empty errorTime}">
            <div style="margin-bottom: 8px;">
                <strong>Time:</strong>
                <fmt:formatDate value="${errorTime}" pattern="dd/MM/yyyy HH:mm:ss"/>
            </div>
        </c:if>

        <a href="${empty backUrl ? 'toy?action=list' : backUrl}">Back</a>
    </body>
</html>
