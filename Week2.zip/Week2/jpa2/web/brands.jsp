<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Brand List</title>
    </head>
    <body>
        <h1>Brand List</h1>
        <hr/>
        <table border="1" cellspacing="0" cellpadding="6">
            <tr>
                <th>Brand Id</th>
                <th>Brand Name</th>
            </tr>
            <c:forEach var="b" items="${brands}">
                <tr>
                    <td>${b.id}</td>
                    <td>${b.name}</td>
                </tr>
            </c:forEach>
        </table>
        <br/>
        <a href="toy?action=dashboard">Dashboard</a> |
        <a href="toy?action=list">Toy Management</a> |
        <a href="toy?action=about">About</a>
    </body>
</html>
