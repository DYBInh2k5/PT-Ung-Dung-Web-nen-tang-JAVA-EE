<%-- 
    Document   : edit
    Created on : Apr 3, 2026, 1:43:14 PM
    Author     : Voduybinhv
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Toy Edit</h1>
        <hr/>
        <c:if test="${not empty errorMessage}">
            <div style="color: red; margin-bottom: 8px;">${errorMessage}</div>
        </c:if>
        <fmt:formatDate value="${toy.expDate}" pattern="yyyy-MM-dd'T'HH:mm" var="expDateVal"/>
        <c:set var="nameVal" value="${not empty editName ? editName : toy.name}"/>
        <c:set var="priceVal" value="${not empty editPrice ? editPrice : toy.price}"/>
        <c:set var="expDateInput" value="${not empty editExpDate ? editExpDate : expDateVal}"/>
        <c:set var="brandVal" value="${not empty editBrand ? editBrand : (toy.brand != null ? toy.brand.id : '')}"/>
        <c:url var="cancelUrl" value="toy">
            <c:param name="action" value="list"/>
            <c:param name="q" value="${q}"/>
            <c:param name="brandFilter" value="${brandFilter}"/>
            <c:param name="page" value="${page}"/>
            <c:param name="sortBy" value="${sortBy}"/>
            <c:param name="sortDir" value="${sortDir}"/>
        </c:url>
        <form action="toy" method="post">
            <input type="hidden" name="action" value="confirm"/>
            <input type="hidden" name="formIntent" value="update"/>
            <input type="hidden" name="q" value="${q}"/>
            <input type="hidden" name="brandFilter" value="${brandFilter}"/>
            <input type="hidden" name="page" value="${page}"/>
            <input type="hidden" name="sortBy" value="${sortBy}"/>
            <input type="hidden" name="sortDir" value="${sortDir}"/>
            Id:<br/>
            <input type="text" name="id" value="${toy.id}" readonly="readonly"/><br/>
            Name:<br/>
            <input type="text" name="name" value="${nameVal}" maxlength="20" required="required"/><br/>
            Price:<br/>
            <input type="number" step="0.01" min="0" name="price" value="${priceVal}" required="required"/><br/>
            Expired date:<br/>
            <input type="datetime-local" name="expDate" value="${expDateInput}"/><br/>
            Brand:<br/>
            <select name="brand">
                <option value="">-- Select brand --</option>
                <c:forEach var="brand" items="${brandList}">
                    <option value="${brand.id}" ${brand.id eq brandVal ? 'selected' : ''}>
                        ${brand.id} - ${brand.name}
                    </option>
                </c:forEach>
            </select><br/><br/>
            <input type="submit" value="Save" class="submitBtn"/>
            <a href="${cancelUrl}">Cancel</a>
        </form>
    </body>
</html>
