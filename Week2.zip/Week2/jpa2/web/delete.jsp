<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Delete Toy</title>
    </head>
    <body>
        <h1>Delete Confirmation</h1>
        <hr/>
        <div style="background:#ffe9e9; color:#8b0000; border:1px solid #d33; padding:8px; margin-bottom:10px;">
            <strong>Warning:</strong> This action cannot be undone.
        </div>
        <p>Are you sure you want to delete this toy?</p>

        <table border="1" cellspacing="0" cellpadding="6">
            <tr><th align="left">Id</th><td>${toy.id}</td></tr>
            <tr><th align="left">Name</th><td>${toy.name}</td></tr>
            <tr><th align="left">Price</th><td><fmt:formatNumber value="${toy.price}" type="currency"/></td></tr>
            <tr><th align="left">Expired Date</th><td><fmt:formatDate value="${toy.expDate}" pattern="dd/MM/yyyy HH:mm"/></td></tr>
            <tr><th align="left">Brand</th><td>${toy.brand != null ? toy.brand.id : ''} ${toy.brand != null ? '- '.concat(toy.brand.name) : ''}</td></tr>
        </table>

        <br/>
        <c:url var="cancelUrl" value="toy">
            <c:param name="action" value="list"/>
            <c:param name="q" value="${q}"/>
            <c:param name="brandFilter" value="${brandFilter}"/>
            <c:param name="page" value="${page}"/>
            <c:param name="sortBy" value="${sortBy}"/>
            <c:param name="sortDir" value="${sortDir}"/>
        </c:url>

        <form action="toy" method="post" style="display:inline;" onsubmit="return lockSubmit(this);">
            <input type="hidden" name="action" value="delete"/>
            <input type="hidden" name="id" value="${toy.id}"/>
            <input type="hidden" name="q" value="${q}"/>
            <input type="hidden" name="brandFilter" value="${brandFilter}"/>
            <input type="hidden" name="page" value="${page}"/>
            <input type="hidden" name="sortBy" value="${sortBy}"/>
            <input type="hidden" name="sortDir" value="${sortDir}"/>
            <input type="submit" value="Delete"/>
        </form>
        <a href="${cancelUrl}">Cancel</a>

        <script type="text/javascript">
            function lockSubmit(form) {
                var buttons = form.querySelectorAll('input[type="submit"],button[type="submit"]');
                for (var i = 0; i < buttons.length; i++) {
                    buttons[i].disabled = true;
                }
                return true;
            }
        </script>
    </body>
</html>
