<%-- 
    Document   : detail
    Created on : Apr 3, 2026
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Toy Detail</title>
    </head>
    <body>
        <h1>Toy Detail</h1>
        <hr/>
        <table border="1" cellspacing="0" cellpadding="6">
            <tr><th align="left">Id</th><td>${toy.id}</td></tr>
            <tr><th align="left">Name</th><td>${toy.name}</td></tr>
            <tr><th align="left">Price</th><td><fmt:formatNumber value="${toy.price}" type="currency"/></td></tr>
            <tr><th align="left">Expired Date</th><td><fmt:formatDate value="${toy.expDate}" pattern="dd/MM/yyyy HH:mm"/></td></tr>
            <tr><th align="left">Brand Id</th><td>${toy.brand != null ? toy.brand.id : ''}</td></tr>
            <tr><th align="left">Brand Name</th><td>${toy.brand != null ? toy.brand.name : ''}</td></tr>
        </table>
        <br/>
        <c:url var="backUrl" value="toy">
            <c:param name="action" value="list"/>
            <c:param name="q" value="${q}"/>
            <c:param name="brandFilter" value="${brandFilter}"/>
            <c:param name="page" value="${page}"/>
            <c:param name="sortBy" value="${sortBy}"/>
            <c:param name="sortDir" value="${sortDir}"/>
        </c:url>
        <c:url var="editUrl" value="toy">
            <c:param name="action" value="edit"/>
            <c:param name="id" value="${toy.id}"/>
            <c:param name="q" value="${q}"/>
            <c:param name="brandFilter" value="${brandFilter}"/>
            <c:param name="page" value="${page}"/>
            <c:param name="sortBy" value="${sortBy}"/>
            <c:param name="sortDir" value="${sortDir}"/>
        </c:url>

        <a href="${backUrl}">Back</a>
        |
        <a href="${editUrl}">Edit</a>
        |
        <c:url var="deletePageUrl" value="toy">
            <c:param name="action" value="deletePage"/>
            <c:param name="id" value="${toy.id}"/>
            <c:param name="q" value="${q}"/>
            <c:param name="brandFilter" value="${brandFilter}"/>
            <c:param name="page" value="${page}"/>
            <c:param name="sortBy" value="${sortBy}"/>
            <c:param name="sortDir" value="${sortDir}"/>
        </c:url>
        <a href="${deletePageUrl}">Delete</a>
    </body>
</html>
