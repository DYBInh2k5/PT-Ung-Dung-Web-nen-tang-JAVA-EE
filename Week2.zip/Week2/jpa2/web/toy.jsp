<%-- 
    Document   : toy
    Created on : Mar 27, 2026, 5:23:15 PM
    Author     : PHT
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<fmt:setLocale value="en_US"/>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h1>Toy List</h1>
        <a href="toy?action=dashboard">Dashboard</a> |
        <a href="toy?action=brands">Brand List</a> |
        <a href="toy?action=about">About</a>
        <hr/>
        <h2>Search</h2>
        <form action="toy" method="get" style="margin-bottom: 12px;">
            <input type="hidden" name="action" value="list"/>
            <input type="hidden" name="sortBy" value="${sortBy}"/>
            <input type="hidden" name="sortDir" value="${sortDir}"/>
            <input type="hidden" name="page" value="1"/>
            Name:
            <input type="text" name="q" value="${q}"/>
            Brand:
            <select name="brandFilter">
                <option value="">-- All brands --</option>
                <c:forEach var="b" items="${brandList}">
                    <option value="${b.id}" ${b.id eq brandFilter ? 'selected' : ''}>${b.id} - ${b.name}</option>
                </c:forEach>
            </select>
            <input type="submit" value="Filter"/>
            <a href="toy?action=list&reset=1">Reset</a>
        </form>
        <h2>Create New Toy</h2>
        <c:if test="${not empty successMessage}">
            <div style="color: green; margin-bottom: 8px;">${successMessage}</div>
        </c:if>
        <c:if test="${not empty errorMessage}">
            <div style="color: red; margin-bottom: 8px;">${errorMessage}</div>
        </c:if>
        <form action="toy" method="post">
            <input type="hidden" name="action" value="confirm"/>
            <input type="hidden" name="formIntent" value="create"/>
            <input type="hidden" name="q" value="${q}"/>
            <input type="hidden" name="brandFilter" value="${brandFilter}"/>
            <input type="hidden" name="page" value="${currentPage}"/>
            <input type="hidden" name="sortBy" value="${sortBy}"/>
            <input type="hidden" name="sortDir" value="${sortDir}"/>
            Id:
            <input type="text" name="id" value="${createId}" maxlength="3" required="required"/>
            Name:
            <input type="text" name="name" value="${createName}" maxlength="20" required="required"/>
            Price:
            <input type="number" step="0.01" min="0" name="price" value="${createPrice}" required="required"/>
            Expired date:
            <input type="datetime-local" name="expDate" value="${createExpDate}"/>
            Brand:
            <select name="brand">
                <option value="">-- Select brand --</option>
                <c:forEach var="brand" items="${brandList}">
                    <option value="${brand.id}" ${brand.id eq createBrand ? 'selected' : ''}>${brand.id} - ${brand.name}</option>
                </c:forEach>
            </select>
            <input type="submit" value="Create" class="submitBtn"/>
            <a href="toy?action=list&reset=1">Cancel</a>
        </form>
        <hr/>
        <c:set var="idNextDir" value="${sortBy eq 'id' and sortDir eq 'asc' ? 'desc' : 'asc'}"/>
        <c:set var="nameNextDir" value="${sortBy eq 'name' and sortDir eq 'asc' ? 'desc' : 'asc'}"/>
        <c:set var="priceNextDir" value="${sortBy eq 'price' and sortDir eq 'asc' ? 'desc' : 'asc'}"/>
        <c:set var="expDateNextDir" value="${sortBy eq 'expDate' and sortDir eq 'asc' ? 'desc' : 'asc'}"/>
        <c:set var="brandNextDir" value="${sortBy eq 'brand' and sortDir eq 'asc' ? 'desc' : 'asc'}"/>
        <form action="toy" method="post" onsubmit="return prepareBulkConfirm();">
            <input type="hidden" name="action" value="confirm"/>
            <input type="hidden" name="formIntent" value="deleteBulk"/>
            <input type="hidden" name="q" value="${q}"/>
            <input type="hidden" name="brandFilter" value="${brandFilter}"/>
            <input type="hidden" name="page" value="${currentPage}"/>
            <input type="hidden" name="sortBy" value="${sortBy}"/>
            <input type="hidden" name="sortDir" value="${sortDir}"/>
            <input type="hidden" name="selectionIds" id="selectionIds"/>
        <table border="1" cellspacing="0" cellpadding="4">
            <tr>
                    <th><input type="checkbox" id="selectAll" onclick="toggleAll(this)"/></th>
                    <th><a href="toy?action=list&q=${q}&brandFilter=${brandFilter}&page=1&sortBy=id&sortDir=${idNextDir}">Id ${sortBy eq 'id' ? (sortDir eq 'asc' ? '↑' : '↓') : ''}</a></th>
                    <th><a href="toy?action=list&q=${q}&brandFilter=${brandFilter}&page=1&sortBy=name&sortDir=${nameNextDir}">Name ${sortBy eq 'name' ? (sortDir eq 'asc' ? '↑' : '↓') : ''}</a></th>
                    <th style="text-align: right;"><a href="toy?action=list&q=${q}&brandFilter=${brandFilter}&page=1&sortBy=price&sortDir=${priceNextDir}">Price ${sortBy eq 'price' ? (sortDir eq 'asc' ? '↑' : '↓') : ''}</a></th>
                    <th><a href="toy?action=list&q=${q}&brandFilter=${brandFilter}&page=1&sortBy=expDate&sortDir=${expDateNextDir}">Expired Date ${sortBy eq 'expDate' ? (sortDir eq 'asc' ? '↑' : '↓') : ''}</a></th>
                    <th><a href="toy?action=list&q=${q}&brandFilter=${brandFilter}&page=1&sortBy=brand&sortDir=${brandNextDir}">Brand Id ${sortBy eq 'brand' ? (sortDir eq 'asc' ? '↑' : '↓') : ''}</a></th>
                    <th>Brand Name</th>
                    <th>Updated At</th>
                    <th>Operations</th>
                </tr>
            <c:forEach var="toy" items="${list}">
                <tr style="${toy.id eq highlightId ? 'background-color:#fff9d6;' : ''}">
                    <c:url var="editUrl" value="toy">
                        <c:param name="action" value="edit"/>
                        <c:param name="id" value="${toy.id}"/>
                        <c:param name="q" value="${q}"/>
                        <c:param name="brandFilter" value="${brandFilter}"/>
                        <c:param name="page" value="${currentPage}"/>
                        <c:param name="sortBy" value="${sortBy}"/>
                        <c:param name="sortDir" value="${sortDir}"/>
                    </c:url>
                    <td><input type="checkbox" name="ids" value="${toy.id}" class="rowCheck"/></td>
                    <td>${toy.id}</td>
                    <td>${toy.name}</td>
                    <td style="text-align: right;"><fmt:formatNumber value="${toy.price}" type="currency" /></td>
                    <td><fmt:formatDate value="${toy.expDate}" pattern="dd/MM/yyyy HH:mm" /></td>
                    <td>${toy.brand != null ? toy.brand.id : ''}</td>
                    <td>${toy.brand != null ? toy.brand.name : ''}</td>
                    <td>${updateMarks[toy.id]}</td>
                    <td>
                        <c:url var="detailUrl" value="toy">
                            <c:param name="action" value="detail"/>
                            <c:param name="id" value="${toy.id}"/>
                            <c:param name="q" value="${q}"/>
                            <c:param name="brandFilter" value="${brandFilter}"/>
                            <c:param name="page" value="${currentPage}"/>
                            <c:param name="sortBy" value="${sortBy}"/>
                            <c:param name="sortDir" value="${sortDir}"/>
                        </c:url>
                        <a href="${detailUrl}">Detail</a> |
                        <a href="${editUrl}">Edit</a> | 
                        <c:url var="deletePageUrl" value="toy">
                            <c:param name="action" value="deletePage"/>
                            <c:param name="id" value="${toy.id}"/>
                            <c:param name="q" value="${q}"/>
                            <c:param name="brandFilter" value="${brandFilter}"/>
                            <c:param name="page" value="${currentPage}"/>
                            <c:param name="sortBy" value="${sortBy}"/>
                            <c:param name="sortDir" value="${sortDir}"/>
                        </c:url>
                        <a href="${deletePageUrl}" onclick="removeSelectedId('${toy.id}');">Delete</a>
                        
                    </td>
                </tr>
            </c:forEach>
        </table>
        <div style="margin-top: 8px;">
            <input type="submit" value="Delete Selected" class="submitBtn"/>
        </div>
        </form>

        <div style="margin-top: 10px;">
            <strong>Total:</strong> ${totalItems} record(s)
        </div>
        <c:if test="${totalPages > 1}">
            <div style="margin-top: 8px;">
                <c:if test="${currentPage > 1}">
                    <a href="toy?action=list&q=${q}&brandFilter=${brandFilter}&page=${currentPage - 1}&sortBy=${sortBy}&sortDir=${sortDir}">Previous</a>
                </c:if>
                <c:forEach begin="1" end="${totalPages}" var="p">
                    <c:choose>
                        <c:when test="${p == currentPage}">
                            <strong>[${p}]</strong>
                        </c:when>
                        <c:otherwise>
                            <a href="toy?action=list&q=${q}&brandFilter=${brandFilter}&page=${p}&sortBy=${sortBy}&sortDir=${sortDir}">${p}</a>
                        </c:otherwise>
                    </c:choose>
                </c:forEach>
                <c:if test="${currentPage < totalPages}">
                    <a href="toy?action=list&q=${q}&brandFilter=${brandFilter}&page=${currentPage + 1}&sortBy=${sortBy}&sortDir=${sortDir}">Next</a>
                </c:if>
            </div>
        </c:if>

        <script type="text/javascript">
            function lockSubmit(form) {
                var buttons = form.querySelectorAll('input[type="submit"],button[type="submit"]');
                for (var i = 0; i < buttons.length; i++) {
                    buttons[i].disabled = true;
                }
            }

            function toggleAll(source) {
                var items = document.getElementsByClassName('rowCheck');
                for (var i = 0; i < items.length; i++) {
                    items[i].checked = source.checked;
                }
                syncSelectionFromPage();
            }

            function prepareBulkConfirm() {
                var selectedIds = getSelectedIds();
                var selected = selectedIds.length;
                if (selected === 0) {
                    alert('Please select at least one toy.');
                    return false;
                }
                document.getElementById('selectionIds').value = selectedIds.join(',');
                return true;
            }

            var STORAGE_KEY = 'toy.bulk.selected.ids';

            function getSelectedIds() {
                try {
                    var raw = sessionStorage.getItem(STORAGE_KEY);
                    var parsed = raw ? JSON.parse(raw) : [];
                    return Array.isArray(parsed) ? parsed : [];
                } catch (e) {
                    return [];
                }
            }

            function setSelectedIds(ids) {
                sessionStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
            }

            function removeSelectedId(id) {
                var ids = getSelectedIds();
                var next = [];
                for (var i = 0; i < ids.length; i++) {
                    if (ids[i] !== id) {
                        next.push(ids[i]);
                    }
                }
                setSelectedIds(next);
            }

            function syncSelectionFromPage() {
                var ids = getSelectedIds();
                var map = {};
                for (var i = 0; i < ids.length; i++) {
                    map[ids[i]] = true;
                }

                var items = document.getElementsByClassName('rowCheck');
                for (var j = 0; j < items.length; j++) {
                    var id = items[j].value;
                    if (items[j].checked) {
                        map[id] = true;
                    } else {
                        delete map[id];
                    }
                }

                var next = [];
                for (var key in map) {
                    if (map.hasOwnProperty(key)) {
                        next.push(key);
                    }
                }
                setSelectedIds(next);
            }

            function applySelectionToPage() {
                var ids = getSelectedIds();
                var map = {};
                for (var i = 0; i < ids.length; i++) {
                    map[ids[i]] = true;
                }

                var items = document.getElementsByClassName('rowCheck');
                var checkedCount = 0;
                for (var j = 0; j < items.length; j++) {
                    var checked = !!map[items[j].value];
                    items[j].checked = checked;
                    if (checked) {
                        checkedCount++;
                    }
                    items[j].addEventListener('change', syncSelectionFromPage);
                }

                var selectAll = document.getElementById('selectAll');
                if (selectAll) {
                    selectAll.checked = (items.length > 0 && checkedCount === items.length);
                }
            }

            (function initSelectionPersistence() {
                applySelectionToPage();

                if ('${successMessage}'.indexOf('Deleted ') === 0) {
                    setSelectedIds([]);
                }

                var resetLinks = document.querySelectorAll('a[href*="reset=1"]');
                for (var i = 0; i < resetLinks.length; i++) {
                    resetLinks[i].addEventListener('click', function() {
                        setSelectedIds([]);
                    });
                }
            })();
        </script>
    </body>
</html>
