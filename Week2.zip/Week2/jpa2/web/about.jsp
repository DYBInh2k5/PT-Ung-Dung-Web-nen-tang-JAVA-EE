<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>About</title>
    </head>
    <body>
        <h1>About This Project</h1>
        <hr/>
        <p>Java EE Toy Management demo using Servlet, JSP, EJB and JPA.</p>
        <ul>
            <li>Manage toy records (create, edit, detail, delete, bulk delete).</li>
            <li>Filter, sort, pagination and state persistence.</li>
            <li>Brand lookup and date-time handling.</li>
        </ul>
        <a href="toy?action=dashboard">Dashboard</a> |
        <a href="toy?action=list">Toy Management</a> |
        <a href="toy?action=brands">Brand List</a>
    </body>
</html>
