<%-- 
    Document   : brand
    Created on : Mar 28, 2026
    Author     : PHT
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Brand List</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    <body>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <h1>Brand List</h1>
                    <hr/>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <a href="toy">View Toy List</a>
                    <table class="table table-striped">
                        <tr>
                            <th>No.</th>
                            <th>Id</th>
                            <th>Name</th>
                        </tr>
                        <c:forEach var="brand" items="${list}" varStatus="loop">
                            <tr>
                                <td>${loop.count}</td>
                                <td>${brand.id}</td>
                                <td>${brand.name}</td>
                            </tr>
                        </c:forEach>
                    </table>
                    ${message}
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <hr/>
                    Copyrights &copy; HSU Students
                </div>
            </div>
        </div>
    </body>
</html>
