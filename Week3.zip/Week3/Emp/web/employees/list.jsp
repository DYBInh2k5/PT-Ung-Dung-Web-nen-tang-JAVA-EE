<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="java.net.URLEncoder"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Danh Sach Nhan Vien</title>
    <style>
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            margin: 24px;
            background: #f5f7fb;
        }
        .container {
            max-width: 980px;
            margin: 0 auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.08);
            padding: 20px;
        }
        h1 {
            margin-top: 0;
            color: #1f2937;
        }
        .toolbar {
            display: flex;
            gap: 10px;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
            flex-wrap: wrap;
        }
        .search-form {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
        }
        .search-form input {
            border: 1px solid #d1d5db;
            border-radius: 6px;
            padding: 8px 10px;
            min-width: 240px;
        }
        .search-form select {
            border: 1px solid #d1d5db;
            border-radius: 6px;
            padding: 8px 10px;
            background: #fff;
        }
        .search-form button {
            border: none;
            background: #111827;
            color: #fff;
            border-radius: 6px;
            padding: 8px 12px;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border-bottom: 1px solid #e5e7eb;
            padding: 10px;
            text-align: left;
        }
        th {
            background: #f3f4f6;
            color: #111827;
        }
        a.button {
            display: inline-block;
            text-decoration: none;
            color: #fff;
            background: #2563eb;
            padding: 6px 12px;
            border-radius: 6px;
            margin-right: 6px;
            font-size: 14px;
        }
        a.delete {
            background: #dc2626;
        }
        .status {
            border-radius: 6px;
            padding: 8px 10px;
            margin-bottom: 10px;
            background: #ecfdf5;
            border: 1px solid #10b981;
            color: #065f46;
            font-size: 14px;
        }
        .pagination {
            margin-top: 14px;
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }
        .pagination a,
        .pagination span {
            padding: 6px 10px;
            border-radius: 6px;
            text-decoration: none;
            border: 1px solid #d1d5db;
            color: #111827;
            background: #fff;
            font-size: 14px;
        }
        .pagination .active {
            background: #2563eb;
            color: #fff;
            border-color: #2563eb;
        }
        .muted {
            color: #6b7280;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Danh Sach Nhan Vien</h1>
        <p class="muted">Chuc nang: them moi, tim kiem, phan trang, sua va xoa nhan vien.</p>

        <%
            String msg = request.getParameter("msg");
            String qRaw = String.valueOf(request.getAttribute("q") == null ? "" : request.getAttribute("q"));
            String qEncoded = URLEncoder.encode(qRaw, "UTF-8");
            String sortBy = String.valueOf(request.getAttribute("sortBy") == null ? "id" : request.getAttribute("sortBy"));
            String sortDir = String.valueOf(request.getAttribute("sortDir") == null ? "asc" : request.getAttribute("sortDir"));
            if ("created".equals(msg)) {
        %>
        <div class="status">Them moi nhan vien thanh cong.</div>
        <%
            } else if ("updated".equals(msg)) {
        %>
        <div class="status">Cap nhat nhan vien thanh cong.</div>
        <%
            } else if ("deleted".equals(msg)) {
        %>
        <div class="status">Xoa nhan vien thanh cong.</div>
        <%
            }
        %>

        <div class="toolbar">
            <form class="search-form" method="get" action="<%= request.getContextPath()%>/employees">
                <input type="text" name="q" placeholder="Tim theo ho ten..." value="<%= request.getAttribute("q") != null ? request.getAttribute("q") : ""%>">
                <select name="sortBy">
                    <option value="id" <%= "id".equalsIgnoreCase(sortBy) ? "selected" : ""%>>Sap xep: ID</option>
                    <option value="fullname" <%= "fullname".equalsIgnoreCase(sortBy) ? "selected" : ""%>>Sap xep: Ho ten</option>
                    <option value="dob" <%= "dob".equalsIgnoreCase(sortBy) ? "selected" : ""%>>Sap xep: Ngay sinh</option>
                    <option value="salary" <%= "salary".equalsIgnoreCase(sortBy) ? "selected" : ""%>>Sap xep: Luong</option>
                </select>
                <select name="sortDir">
                    <option value="asc" <%= "asc".equalsIgnoreCase(sortDir) ? "selected" : ""%>>Tang dan</option>
                    <option value="desc" <%= "desc".equalsIgnoreCase(sortDir) ? "selected" : ""%>>Giam dan</option>
                </select>
                <button type="submit">Tim</button>
            </form>
            <a class="button" href="<%= request.getContextPath()%>/employees?action=create&q=<%= qEncoded%>&page=<%= request.getAttribute("page")%>&sortBy=<%= sortBy%>&sortDir=<%= sortDir%>">+ Them Nhan Vien</a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Ho Ten</th>
                    <th>Ngay Sinh</th>
                    <th>Luong</th>
                    <th>Hanh Dong</th>
                </tr>
            </thead>
            <tbody>
                <%
                    List rows = (List) request.getAttribute("employeeRows");
                    if (rows != null && !rows.isEmpty()) {
                        for (Object item : rows) {
                            java.util.Map row = (java.util.Map) item;
                %>
                <tr>
                    <td><%= row.get("id")%></td>
                    <td><%= row.get("fullName")%></td>
                    <td><%= row.get("dob")%></td>
                    <td><%= String.format("%,.0f", row.get("salary"))%></td>
                    <td>
                        <a class="button" href="<%= request.getContextPath()%>/employees?action=edit&id=<%= row.get("id")%>&q=<%= qEncoded%>&page=<%= request.getAttribute("page")%>&sortBy=<%= sortBy%>&sortDir=<%= sortDir%>">Sua</a>
                        <a class="button delete" href="<%= request.getContextPath()%>/employees?action=delete&id=<%= row.get("id")%>&q=<%= qEncoded%>&page=<%= request.getAttribute("page")%>&sortBy=<%= sortBy%>&sortDir=<%= sortDir%>"
                           onclick="return confirm('Ban co chac muon xoa nhan vien nay?');">Xoa</a>
                    </td>
                </tr>
                <%
                        }
                    } else {
                %>
                <tr>
                    <td colspan="5" class="muted">Khong co du lieu nhan vien.</td>
                </tr>
                <%
                    }
                %>
            </tbody>
        </table>

        <%
            Integer currentPage = (Integer) request.getAttribute("page");
            Integer totalPages = (Integer) request.getAttribute("totalPages");
            if (currentPage != null && totalPages != null && totalPages > 1) {
        %>
        <div class="pagination">
            <%
                for (int i = 1; i <= totalPages; i++) {
                    if (i == currentPage) {
            %>
            <span class="active"><%= i%></span>
            <%
                    } else {
            %>
                    <a href="<%= request.getContextPath()%>/employees?page=<%= i%>&q=<%= qEncoded%>&sortBy=<%= sortBy%>&sortDir=<%= sortDir%>"><%= i%></a>
            <%
                    }
                }
            %>
        </div>
        <%
            }
        %>
    </div>
</body>
</html>
