<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.net.URLEncoder"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Them Nhan Vien</title>
    <style>
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            margin: 24px;
            background: #f5f7fb;
        }
        .container {
            max-width: 560px;
            margin: 0 auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.08);
            padding: 20px;
        }
        h1 {
            margin-top: 0;
            color: #1f2937;
        }
        label {
            display: block;
            margin-bottom: 6px;
            margin-top: 12px;
            color: #111827;
            font-weight: 600;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            box-sizing: border-box;
        }
        .actions {
            margin-top: 16px;
        }
        button, a {
            display: inline-block;
            padding: 8px 14px;
            border-radius: 6px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }
        button {
            background: #2563eb;
            color: #fff;
        }
        a {
            background: #e5e7eb;
            color: #111827;
            margin-left: 8px;
        }
        .error {
            color: #b91c1c;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <%
        String q = request.getAttribute("q") == null ? "" : String.valueOf(request.getAttribute("q"));
        String qEncoded = URLEncoder.encode(q, "UTF-8");
        String page = request.getAttribute("page") == null ? "1" : String.valueOf(request.getAttribute("page"));
        String sortBy = request.getAttribute("sortBy") == null ? "id" : String.valueOf(request.getAttribute("sortBy"));
        String sortDir = request.getAttribute("sortDir") == null ? "asc" : String.valueOf(request.getAttribute("sortDir"));
    %>
    <div class="container">
        <h1>Them Nhan Vien</h1>

        <% if (request.getAttribute("error") != null) { %>
        <div class="error"><%= request.getAttribute("error")%></div>
        <% } %>

        <form method="post" action="<%= request.getContextPath()%>/employees">
            <input type="hidden" name="action" value="create">
            <input type="hidden" name="q" value="<%= q%>">
            <input type="hidden" name="page" value="<%= page%>">
            <input type="hidden" name="sortBy" value="<%= sortBy%>">
            <input type="hidden" name="sortDir" value="<%= sortDir%>">

            <label for="fullName">Ho Ten</label>
            <input id="fullName" name="fullName" value="<%= request.getAttribute("fullName") != null ? request.getAttribute("fullName") : ""%>" required>

            <label for="dob">Ngay Sinh</label>
            <input id="dob" type="date" name="dob" value="<%= request.getAttribute("dob") != null ? request.getAttribute("dob") : ""%>" required>

            <label for="salary">Luong</label>
            <input id="salary" type="number" step="0.01" min="0" name="salary" value="<%= request.getAttribute("salary") != null ? request.getAttribute("salary") : ""%>" required>

            <div class="actions">
                <button type="submit">Luu</button>
                <a href="<%= request.getContextPath()%>/employees?q=<%= qEncoded%>&page=<%= page%>&sortBy=<%= sortBy%>&sortDir=<%= sortDir%>">Huy</a>
            </div>
        </form>
    </div>
</body>
</html>
