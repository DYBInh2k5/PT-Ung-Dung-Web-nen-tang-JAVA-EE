package com.emp.controller;

import com.emp.jpa.EmployeeJpaController;
import com.emp.model.Employee;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.net.URLEncoder;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "EmployeeServlet", urlPatterns = {"/employees"})
public class EmployeeServlet extends HttpServlet {

    private final EmployeeJpaController employeeJpaController = new EmployeeJpaController();
    private static final int PAGE_SIZE = 5;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String keyword = normalize(request.getParameter("q"));
        int page = parsePositiveInt(request.getParameter("page"), 1);
        String sortBy = normalizeSortBy(request.getParameter("sortBy"));
        String sortDir = normalizeSortDir(request.getParameter("sortDir"));

        if ("create".equals(action)) {
            setListState(request, keyword, page, sortBy, sortDir);
            request.getRequestDispatcher("/employees/create.jsp").forward(request, response);
            return;
        }

        if ("edit".equals(action)) {
            showEditForm(request, response, keyword, page, sortBy, sortDir);
            return;
        }

        if ("delete".equals(action)) {
            deleteEmployee(request, response, keyword, page, sortBy, sortDir);
            return;
        }

        int totalItems = employeeJpaController.countEmployees(keyword);
        int totalPages = (int) Math.ceil(totalItems / (double) PAGE_SIZE);
        if (totalPages == 0) {
            totalPages = 1;
        }
        if (page > totalPages) {
            page = totalPages;
        }

        List<Employee> employees = employeeJpaController.findEmployeePage(keyword, page, PAGE_SIZE, sortBy, sortDir);
        List<Map<String, Object>> rows = new ArrayList<>();
        for (Employee employee : employees) {
            Map<String, Object> row = new HashMap<>();
            row.put("id", employee.getEmployeeId());
            row.put("fullName", employee.getFullName());
            row.put("dob", new SimpleDateFormat("yyyy-MM-dd").format(employee.getDob()));
            row.put("salary", employee.getSalary());
            rows.add(row);
        }

        request.setAttribute("employeeRows", rows);
        request.setAttribute("q", keyword);
        request.setAttribute("page", page);
        request.setAttribute("totalPages", totalPages);
        request.setAttribute("totalItems", totalItems);
        request.setAttribute("sortBy", sortBy);
        request.setAttribute("sortDir", sortDir);
        request.getRequestDispatcher("/employees/list.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        if ("create".equals(action)) {
            createEmployee(request, response);
            return;
        }

        if ("update".equals(action)) {
            updateEmployee(request, response);
            return;
        }

        response.sendRedirect(request.getContextPath() + "/employees");
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        showEditForm(request, response,
                normalize(request.getParameter("q")),
                parsePositiveInt(request.getParameter("page"), 1),
                normalizeSortBy(request.getParameter("sortBy")),
                normalizeSortDir(request.getParameter("sortDir")));
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response,
            String keyword, int page, String sortBy, String sortDir)
            throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            Employee employee = employeeJpaController.findEmployee(id);

            if (employee == null) {
                response.sendRedirect(buildListUrl(request, keyword, page, sortBy, sortDir, null));
                return;
            }

            setEditFormData(request, employee);
            setListState(request, keyword, page, sortBy, sortDir);
            request.getRequestDispatcher("/employees/edit.jsp").forward(request, response);
        } catch (NumberFormatException ex) {
            response.sendRedirect(buildListUrl(request, keyword, page, sortBy, sortDir, null));
        }
    }

    private void updateEmployee(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        try {
            int id = Integer.parseInt(request.getParameter("employeeId"));
            String fullName = request.getParameter("fullName");
            String dobRaw = request.getParameter("dob");
            String salaryRaw = request.getParameter("salary");
            String keyword = normalize(request.getParameter("q"));
            int page = parsePositiveInt(request.getParameter("page"), 1);
            String sortBy = normalizeSortBy(request.getParameter("sortBy"));
            String sortDir = normalizeSortDir(request.getParameter("sortDir"));

            String validationError = validateInput(fullName, dobRaw, salaryRaw);
            if (validationError != null) {
                request.setAttribute("error", validationError);
                request.setAttribute("employeeId", id);
                request.setAttribute("fullName", fullName);
                request.setAttribute("dob", dobRaw);
                request.setAttribute("salary", salaryRaw);
                setListState(request, keyword, page, sortBy, sortDir);
                request.getRequestDispatcher("/employees/edit.jsp").forward(request, response);
                return;
            }

            Date dob = new SimpleDateFormat("yyyy-MM-dd").parse(dobRaw);
            double salary = Double.parseDouble(salaryRaw);

            Employee employee = new Employee(id, fullName, dob, salary);
            employeeJpaController.edit(employee);
            response.sendRedirect(buildListUrl(request, keyword, page, sortBy, sortDir, "updated"));
        } catch (Exception ex) {
            try {
                int id = Integer.parseInt(request.getParameter("employeeId"));
                Employee employee = employeeJpaController.findEmployee(id);
                if (employee != null) {
                    setEditFormData(request, employee);
                }
            } catch (Exception ignored) {
                // Ignore and show generic error.
            }
            setListState(request,
                    normalize(request.getParameter("q")),
                    parsePositiveInt(request.getParameter("page"), 1),
                    normalizeSortBy(request.getParameter("sortBy")),
                    normalizeSortDir(request.getParameter("sortDir")));
            request.setAttribute("error", "Cap nhat that bai: " + ex.getMessage());
            request.getRequestDispatcher("/employees/edit.jsp").forward(request, response);
        }
    }

    private void createEmployee(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        try {
            String fullName = request.getParameter("fullName");
            String dobRaw = request.getParameter("dob");
            String salaryRaw = request.getParameter("salary");
            String keyword = normalize(request.getParameter("q"));
            int page = parsePositiveInt(request.getParameter("page"), 1);
            String sortBy = normalizeSortBy(request.getParameter("sortBy"));
            String sortDir = normalizeSortDir(request.getParameter("sortDir"));

            String validationError = validateInput(fullName, dobRaw, salaryRaw);
            if (validationError != null) {
                request.setAttribute("error", validationError);
                request.setAttribute("fullName", fullName);
                request.setAttribute("dob", dobRaw);
                request.setAttribute("salary", salaryRaw);
                setListState(request, keyword, page, sortBy, sortDir);
                request.getRequestDispatcher("/employees/create.jsp").forward(request, response);
                return;
            }

            Date dob = new SimpleDateFormat("yyyy-MM-dd").parse(dobRaw);
            double salary = Double.parseDouble(salaryRaw);

            Employee employee = new Employee();
            employee.setFullName(fullName.trim());
            employee.setDob(dob);
            employee.setSalary(salary);
            employeeJpaController.create(employee);

            response.sendRedirect(buildListUrl(request, keyword, 1, sortBy, sortDir, "created"));
        } catch (Exception ex) {
            request.setAttribute("error", "Them moi that bai: " + ex.getMessage());
            request.setAttribute("fullName", request.getParameter("fullName"));
            request.setAttribute("dob", request.getParameter("dob"));
            request.setAttribute("salary", request.getParameter("salary"));
            setListState(request,
                    normalize(request.getParameter("q")),
                    parsePositiveInt(request.getParameter("page"), 1),
                    normalizeSortBy(request.getParameter("sortBy")),
                    normalizeSortDir(request.getParameter("sortDir")));
            request.getRequestDispatcher("/employees/create.jsp").forward(request, response);
        }
    }

    private String validateInput(String fullName, String dobRaw, String salaryRaw) {
        if (fullName == null || fullName.trim().isEmpty()) {
            return "Ho ten khong duoc de trong.";
        }

        if (dobRaw == null || dobRaw.trim().isEmpty()) {
            return "Ngay sinh khong duoc de trong.";
        }

        if (salaryRaw == null || salaryRaw.trim().isEmpty()) {
            return "Luong khong duoc de trong.";
        }

        try {
            Date dob = new SimpleDateFormat("yyyy-MM-dd").parse(dobRaw);
            if (dob.after(new Date())) {
                return "Ngay sinh khong hop le (khong duoc lon hon hien tai).";
            }
        } catch (Exception ex) {
            return "Dinh dang ngay sinh khong hop le.";
        }

        try {
            double salary = Double.parseDouble(salaryRaw);
            if (salary < 0) {
                return "Luong phai lon hon hoac bang 0.";
            }
        } catch (Exception ex) {
            return "Luong khong hop le.";
        }

        return null;
    }

    private int parsePositiveInt(String value, int defaultValue) {
        try {
            int parsed = Integer.parseInt(value);
            return parsed > 0 ? parsed : defaultValue;
        } catch (Exception ex) {
            return defaultValue;
        }
    }

    private void setEditFormData(HttpServletRequest request, Employee employee) {
        request.setAttribute("employeeId", employee.getEmployeeId());
        request.setAttribute("fullName", employee.getFullName());
        request.setAttribute("dob", new SimpleDateFormat("yyyy-MM-dd").format(employee.getDob()));
        request.setAttribute("salary", employee.getSalary());
    }

    private void deleteEmployee(HttpServletRequest request, HttpServletResponse response,
            String keyword, int page, String sortBy, String sortDir)
            throws IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            employeeJpaController.destroy(id);
        } catch (Exception ex) {
            // Ignore invalid id and return to list page.
        }

        response.sendRedirect(buildListUrl(request, keyword, page, sortBy, sortDir, "deleted"));
    }

    private void setListState(HttpServletRequest request, String keyword, int page, String sortBy, String sortDir) {
        request.setAttribute("q", keyword);
        request.setAttribute("page", page);
        request.setAttribute("sortBy", sortBy);
        request.setAttribute("sortDir", sortDir);
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim();
    }

    private String normalizeSortBy(String value) {
        if ("fullname".equalsIgnoreCase(value)) {
            return "fullname";
        }
        if ("dob".equalsIgnoreCase(value)) {
            return "dob";
        }
        if ("salary".equalsIgnoreCase(value)) {
            return "salary";
        }
        return "id";
    }

    private String normalizeSortDir(String value) {
        return "desc".equalsIgnoreCase(value) ? "desc" : "asc";
    }

    private String buildListUrl(HttpServletRequest request, String keyword, int page,
            String sortBy, String sortDir, String msg) throws IOException {
        StringBuilder sb = new StringBuilder();
        sb.append(request.getContextPath()).append("/employees");
        sb.append("?q=").append(URLEncoder.encode(keyword == null ? "" : keyword, "UTF-8"));
        sb.append("&page=").append(page);
        sb.append("&sortBy=").append(sortBy);
        sb.append("&sortDir=").append(sortDir);
        if (msg != null && !msg.isEmpty()) {
            sb.append("&msg=").append(msg);
        }
        return sb.toString();
    }
}
