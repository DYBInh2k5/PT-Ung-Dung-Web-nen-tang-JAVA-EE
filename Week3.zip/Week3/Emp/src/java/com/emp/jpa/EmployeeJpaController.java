package com.emp.jpa;

import com.emp.model.Employee;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class EmployeeJpaController {

    private static final EntityManagerFactory EMF =
            Persistence.createEntityManagerFactory("EmpPU");

    public List<Employee> findEmployeeEntities() {
        return findEmployeePage("", 1, Integer.MAX_VALUE, "id", "asc");
    }

        public List<Employee> findEmployeePage(String keyword, int page, int pageSize, String sortBy, String sortDir) {
        EntityManager em = EMF.createEntityManager();
        try {
            String normalized = keyword == null ? "" : keyword.trim();
            int validPage = Math.max(1, page);
            int offset = (validPage - 1) * pageSize;
            String orderBy = resolveOrderBy(sortBy, sortDir);

            String sql = "SELECT Id, FullName, DoB, Salary FROM dbo.Employee "
                    + "WHERE LOWER(FullName) LIKE ? "
                + orderBy
                + " OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

            Query query = em.createNativeQuery(sql);
            query.setParameter(1, "%" + normalized.toLowerCase() + "%");
            query.setParameter(2, offset);
            query.setParameter(3, pageSize);

            @SuppressWarnings("unchecked")
            List<Object[]> rows = query.getResultList();

            List<Employee> employees = new ArrayList<>();
            for (Object[] row : rows) {
                employees.add(mapRowToEmployee(row));
            }

            return employees;
        } finally {
            em.close();
        }
    }

    public int countEmployees(String keyword) {
        EntityManager em = EMF.createEntityManager();
        try {
            String normalized = keyword == null ? "" : keyword.trim();
            Query query = em.createNativeQuery(
                    "SELECT COUNT(*) FROM dbo.Employee WHERE LOWER(FullName) LIKE ?");
            query.setParameter(1, "%" + normalized.toLowerCase() + "%");

            Object total = query.getSingleResult();
            if (total instanceof Number) {
                return ((Number) total).intValue();
            }
            return Integer.parseInt(String.valueOf(total));
        } finally {
            em.close();
        }
    }

    public void create(Employee employee) {
        EntityManager em = EMF.createEntityManager();
        try {
            em.getTransaction().begin();
            Query query = em.createNativeQuery(
                    "INSERT INTO dbo.Employee (FullName, DoB, Salary) VALUES (?, ?, ?)");
            query.setParameter(1, employee.getFullName());
            query.setParameter(2, new java.sql.Date(employee.getDob().getTime()));
            query.setParameter(3, employee.getSalary());
            query.executeUpdate();
            em.getTransaction().commit();
        } finally {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            em.close();
        }
    }

    public Employee findEmployee(int id) {
        EntityManager em = EMF.createEntityManager();
        try {
            Query query = em.createNativeQuery(
                    "SELECT Id, FullName, DoB, Salary FROM dbo.Employee WHERE Id = ?");
            query.setParameter(1, id);

            @SuppressWarnings("unchecked")
            List<Object[]> rows = query.getResultList();
            if (rows == null || rows.isEmpty()) {
                return null;
            }

            return mapRowToEmployee(rows.get(0));
        } finally {
            em.close();
        }
    }

    public void edit(Employee employee) {
        EntityManager em = EMF.createEntityManager();
        try {
            em.getTransaction().begin();
            Query query = em.createNativeQuery(
                    "UPDATE dbo.Employee SET FullName = ?, DoB = ?, Salary = ? WHERE Id = ?");
            query.setParameter(1, employee.getFullName());
            query.setParameter(2, new java.sql.Date(employee.getDob().getTime()));
            query.setParameter(3, employee.getSalary());
            query.setParameter(4, employee.getEmployeeId());
            query.executeUpdate();
            em.getTransaction().commit();
        } finally {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            em.close();
        }
    }

    public void destroy(int id) {
        EntityManager em = EMF.createEntityManager();
        try {
            em.getTransaction().begin();
            Query query = em.createNativeQuery("DELETE FROM dbo.Employee WHERE Id = ?");
            query.setParameter(1, id);
            query.executeUpdate();
            em.getTransaction().commit();
        } finally {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            em.close();
        }
    }

    private Employee mapRowToEmployee(Object[] row) {
        int id = ((Number) row[0]).intValue();
        String fullName = String.valueOf(row[1]);
        java.util.Date dob = toUtilDate(row[2]);
        double salary = toDouble(row[3]);
        return new Employee(id, fullName, dob, salary);
    }

    private java.util.Date toUtilDate(Object value) {
        if (value instanceof Timestamp) {
            return new java.util.Date(((Timestamp) value).getTime());
        }
        if (value instanceof Date) {
            return new java.util.Date(((Date) value).getTime());
        }
        if (value instanceof java.util.Date) {
            return (java.util.Date) value;
        }
        return Date.valueOf(String.valueOf(value));
    }

    private double toDouble(Object value) {
        if (value instanceof BigDecimal) {
            return ((BigDecimal) value).doubleValue();
        }
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        return Double.parseDouble(String.valueOf(value));
    }

    private String resolveOrderBy(String sortBy, String sortDir) {
        String column;
        if ("fullname".equalsIgnoreCase(sortBy)) {
            column = "FullName";
        } else if ("dob".equalsIgnoreCase(sortBy)) {
            column = "DoB";
        } else if ("salary".equalsIgnoreCase(sortBy)) {
            column = "Salary";
        } else {
            column = "Id";
        }

        String direction = "desc".equalsIgnoreCase(sortDir) ? "DESC" : "ASC";
        return "ORDER BY " + column + " " + direction;
    }
}
