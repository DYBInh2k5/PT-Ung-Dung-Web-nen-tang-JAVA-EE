# Emp Project Implementation Log

## Date
- 2026-04-05

## Scope Completed
- Tao script SQL [EmpDb.sql] de doc du lieu tu EmpDB (khong tao moi/xoa du lieu).
- Chuyen model Employee thanh JPA Entity mapping bang dbo.Employee.
- Tao persistence.xml (EmpPU) ket noi SQL Server EmpDB.
- Tao EmployeeJpaController voi cac chuc nang: xem danh sach, xem chi tiet theo id, cap nhat, xoa.
- Tao EmployeeServlet map /employees su dung JPA controller de xu ly list, edit, update, delete.
- Tao giao dien JSP:
  - web/employees/list.jsp
  - web/employees/edit.jsp
- Chinh trang index de dieu huong sang danh sach nhan vien.

## Extension Completed
- Them chuc nang them moi nhan vien (create.jsp + create action trong servlet).
- Them validate server-side cho ho ten, ngay sinh, luong.
- Them tim kiem theo ho ten tren danh sach.
- Them phan trang danh sach (PAGE_SIZE = 5).
- Them thong bao trang thai thao tac: created, updated, deleted.
- Them sap xep du lieu (ID, Ho ten, Ngay sinh, Luong; tang/giam).
- Giu trang thai q/page/sort khi sua, xoa, them moi va quay lai danh sach.

## Notes
- Du an dang dung Java EE 7 (GlassFish 4.1.1, JDK 8) nen su dung javax.*.
- Luong hien tai dung JPA2 theo mau: Entity + persistence.xml + JPA Controller.
- Cau hinh ket noi CSDL nam trong src/conf/persistence.xml.
- Yeu cau du lieu: lay tu bang co san trong SQL Server Management, khong seed du lieu mau.
- Bang dang su dung theo du lieu thuc te: dbo.Employee(Id, FullName, DoB, Salary).
- Da doi Employee thanh POJO va thao tac du lieu bang native SQL de tranh loi classloader ClassCastException tren GlassFish.
- URL ket noi da canh theo SQLExpress: localhost + instanceName=SQLEXPRESS.
