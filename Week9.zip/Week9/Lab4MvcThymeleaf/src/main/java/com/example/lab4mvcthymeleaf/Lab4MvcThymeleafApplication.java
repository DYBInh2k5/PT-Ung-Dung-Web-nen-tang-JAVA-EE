package com.example.lab4mvcthymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab4MvcThymeleafApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab4MvcThymeleafApplication.class, args);
    }

}
