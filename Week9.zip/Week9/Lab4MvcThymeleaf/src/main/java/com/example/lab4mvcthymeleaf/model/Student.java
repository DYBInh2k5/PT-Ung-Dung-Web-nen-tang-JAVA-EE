package com.example.lab4mvcthymeleaf.model;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class Student {
    @NotBlank(message = "Mã sinh viên không được để trống")
    private String id;

    @NotBlank(message = "Họ tên không được để trống")
    @Size(min = 3, max = 50, message = "Họ tên phải từ 3 đến 50 ký tự")
    private String name;

    @NotBlank(message = "Email không được để trống")
    @Email(message = "Email chưa đúng định dạng")
    private String email;

    @NotBlank(message = "Chuyên ngành không được để trống")
    private String major;

    @DecimalMin(value = "0.0", message = "Điểm phải từ 0")
    @DecimalMax(value = "10.0", message = "Điểm tối đa là 10")
    private double mark;

    private String description;

    public Student() {
    }

    public Student(String id, String name, String email, String major, double mark, String description) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.major = major;
        this.mark = mark;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public double getMark() {
        return mark;
    }

    public void setMark(double mark) {
        this.mark = mark;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
