package com.example.lab4mvcthymeleaf.controller;

import com.example.lab4mvcthymeleaf.model.Student;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/students")
public class StudentController {
    private final List<Student> students = new ArrayList<>();

    public StudentController() {
        students.add(new Student("SV01", "Nguyen Van An", "an@example.com", "Java Web", 8.5, "<b>Chăm chỉ</b> và chủ động"));
        students.add(new Student("SV02", "Tran Thi Binh", "binh@example.com", "Spring Boot", 7.0, "Hoàn thành bài tốt"));
        students.add(new Student("SV03", "Le Minh Chau", "chau@example.com", "Database", 6.0, "Cần luyện thêm validation"));
    }

    @ModelAttribute("majors")
    public List<String> majors() {
        return Arrays.asList("Java Web", "Spring Boot", "Database", "Frontend");
    }

    @GetMapping
    public String list(
            @RequestParam(name = "keyword", required = false, defaultValue = "") String keyword,
            @RequestParam(name = "minMark", required = false, defaultValue = "0") double minMark,
            @RequestParam(name = "major", required = false, defaultValue = "") String major,
            Model model) {
        List<Student> result = new ArrayList<>();
        for (Student student : students) {
            boolean matchName = student.getName().toLowerCase().contains(keyword.toLowerCase());
            boolean matchMark = student.getMark() >= minMark;
            boolean matchMajor = major.isBlank() || student.getMajor().equalsIgnoreCase(major);
            if (matchName && matchMark && matchMajor) {
                result.add(student);
            }
        }
        model.addAttribute("students", result);
        model.addAttribute("keyword", keyword);
        model.addAttribute("minMark", minMark);
        model.addAttribute("major", major);
        model.addAttribute("htmlNote", "<strong>Lưu ý:</strong> th:utext render HTML thô");
        return "students/list";
    }

    @GetMapping("/top")
    public String top(Model model) {
        List<Student> result = new ArrayList<>();
        for (Student student : students) {
            if (student.getMark() >= 8) {
                result.add(student);
            }
        }
        model.addAttribute("students", result);
        return "students/top";
    }

    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("student", new Student());
        model.addAttribute("isEdit", false);
        return "students/form";
    }

    @PostMapping("/save")
    public String save(
            @Valid @ModelAttribute("student") Student student,
            BindingResult bindingResult,
            Model model) {
        if (!bindingResult.hasFieldErrors("id") && existsById(student.getId())) {
            bindingResult.rejectValue("id", "duplicate", "Mã sinh viên đã tồn tại");
        }
        if (bindingResult.hasErrors()) {
            model.addAttribute("isEdit", false);
            return "students/form";
        }
        students.add(student);
        return "redirect:/students";
    }

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable String id, Model model) {
        Student student = findById(id);
        if (student == null) {
            return "redirect:/students";
        }
        model.addAttribute("student", student);
        model.addAttribute("isEdit", true);
        return "students/form";
    }

    @PostMapping("/{id}/update")
    public String update(
            @PathVariable String id,
            @Valid @ModelAttribute("student") Student student,
            BindingResult bindingResult,
            Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("isEdit", true);
            return "students/form";
        }
        Student existing = findById(id);
        if (existing == null) {
            return "redirect:/students";
        }
        existing.setName(student.getName());
        existing.setEmail(student.getEmail());
        existing.setMajor(student.getMajor());
        existing.setMark(student.getMark());
        existing.setDescription(student.getDescription());
        return "redirect:/students/" + existing.getId();
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable("id") String studentId, Model model) {
        Student student = findById(studentId);
        if (student == null) {
            return "redirect:/students";
        }
        model.addAttribute("student", student);
        return "students/detail";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable String id) {
        students.removeIf(student -> student.getId().equalsIgnoreCase(id));
        return "redirect:/students";
    }

    private Student findById(String id) {
        for (Student student : students) {
            if (student.getId().equalsIgnoreCase(id)) {
                return student;
            }
        }
        return null;
    }

    private boolean existsById(String id) {
        for (Student student : students) {
            if (student.getId().equalsIgnoreCase(id)) {
                return true;
            }
        }
        return false;
    }
}
