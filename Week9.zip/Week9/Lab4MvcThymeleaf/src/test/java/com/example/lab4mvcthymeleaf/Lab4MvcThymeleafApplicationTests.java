package com.example.lab4mvcthymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab4MvcThymeleafApplicationTests {

    @Test
    void contextLoads() {
    }

}
