package com.example.studentmanager.controller;

import com.example.studentmanager.model.Student;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

@Controller
public class StudentController {
    private final List<Student> list = new ArrayList<>();

    public StudentController() {
        list.add(new Student("SV01", "Nguyen Hai Nam", "nam@gmail.com", 8.5));
        list.add(new Student("SV02", "Tran Thuy Hong", "hong@gmail.com", 9.0));
    }

    @GetMapping("/students")
    public String index(@RequestParam(value = "keyword", required = false) String keyword, Model model) {
        String keywordValue = keyword == null ? "" : keyword.trim();
        List<Student> students = list.stream()
                .filter(student -> {
                    if (keywordValue.isBlank()) {
                        return true;
                    }
                    String name = student.getName();
                    if (name == null) {
                        return false;
                    }
                    return name.toLowerCase(Locale.ROOT).contains(keywordValue.toLowerCase(Locale.ROOT));
                })
                .sorted(Comparator.comparingDouble(Student::getMark).reversed())
                .toList();
        model.addAttribute("students", students);
        model.addAttribute("student", new Student());
        model.addAttribute("keyword", keywordValue);
        return "students";
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/students";
    }

    @PostMapping("/students/save")
    public String save(@ModelAttribute Student student) {
        list.add(student);
        return "redirect:/students";
    }

    @PostMapping("/students/delete/{id}")
    public String delete(@PathVariable String id) {
        list.removeIf(student -> student.getId() != null && student.getId().equalsIgnoreCase(id));
        return "redirect:/students";
    }
}
