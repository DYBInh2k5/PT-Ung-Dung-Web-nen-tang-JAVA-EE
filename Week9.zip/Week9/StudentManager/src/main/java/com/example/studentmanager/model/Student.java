package com.example.studentmanager.model;

public class Student {
    private String id;
    private String name;
    private String email;
    private double mark;

    public Student() {
    }

    public Student(String id, String name, String email, double mark) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.mark = mark;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getMark() {
        return mark;
    }

    public void setMark(double mark) {
        this.mark = mark;
    }

    public String getRank() {
        if (mark >= 8) {
            return "Gioi";
        }
        if (mark >= 6.5) {
            return "Kha";
        }
        return "Trung binh";
    }
}
