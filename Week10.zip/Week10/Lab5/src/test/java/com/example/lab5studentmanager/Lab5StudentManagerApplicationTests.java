package com.example.lab5studentmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab5StudentManagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
