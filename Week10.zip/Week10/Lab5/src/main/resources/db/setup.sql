-- ============================================================
-- SETUP SCRIPT FOR Lab5Db
-- This script must be run MANUALLY in SQL Server Management Studio
-- against the Lab5Db database BEFORE starting the application.
--
-- Steps:
--   1. Open SQL Server Management Studio (SSMS)
--   2. Connect to your SQL Server instance
--   3. Open this file and execute it (F5)
-- ============================================================

-- Create the database
CREATE DATABASE Lab5Db;
GO

USE Lab5Db;
GO

-- Create the student table
CREATE TABLE student (
    id           BIGINT IDENTITY(1,1) PRIMARY KEY,
    student_code NVARCHAR(20)   NOT NULL UNIQUE,
    full_name    NVARCHAR(100)  NOT NULL,
    email        NVARCHAR(100)  NOT NULL,
    major        NVARCHAR(100)  NOT NULL,
    gpa          DECIMAL(3,2)   NOT NULL
);
GO

-- Insert 10 sample students
INSERT INTO student (student_code, full_name, email, major, gpa) VALUES
    (N'SV001', N'Nguyễn Minh Anh',   N'anh.nm@example.com',  N'Công nghệ thông tin',    3.20),
    (N'SV002', N'Trần Quốc Bảo',     N'bao.tq@example.com',  N'Công nghệ phần mềm',     3.45),
    (N'SV003', N'Lê Hoàng Chi',       N'chi.lh@example.com',  N'Hệ thống thông tin',     3.10),
    (N'SV004', N'Phạm Gia Huy',       N'huy.pg@example.com',  N'Công nghệ thông tin',    2.95),
    (N'SV005', N'Võ Ngọc Linh',       N'linh.vn@example.com', N'Thương mại điện tử',     3.60),
    (N'SV006', N'Đặng Tuấn Kiệt',    N'kiet.dt@example.com', N'Công nghệ phần mềm',     3.05),
    (N'SV007', N'Hoàng Thanh Mai',    N'mai.ht@example.com',  N'Hệ thống thông tin',     3.70),
    (N'SV008', N'Bùi Đức Nam',        N'nam.bd@example.com',  N'Công nghệ thông tin',    2.80),
    (N'SV009', N'Phan Hà My',         N'my.ph@example.com',   N'Thương mại điện tử',     3.35),
    (N'SV010', N'Đỗ Quang Vinh',      N'vinh.dq@example.com', N'Công nghệ phần mềm',    3.15);
GO

-- Verify inserted data
SELECT * FROM student;
GO
