package com.example.lab5studentmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab5StudentManagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab5StudentManagerApplication.class, args);
    }
}
