package com.example.lab5studentmanager.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;

@Entity
@Table(name = "student")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Mã sinh viên không được rỗng")
    @Column(name = "student_code", nullable = false, unique = true, length = 20)
    private String studentCode;

    @NotBlank(message = "Họ tên không được rỗng")
    @Column(name = "full_name", nullable = false, length = 100)
    private String fullName;

    @NotBlank(message = "Email không được rỗng")
    @Email(message = "Email không hợp lệ")
    @Column(nullable = false, length = 100)
    private String email;

    @NotBlank(message = "Ngành học không được rỗng")
    @Column(nullable = false, length = 100)
    private String major;

    @NotNull(message = "GPA không được rỗng")
    @DecimalMin(value = "0.00", inclusive = true, message = "GPA phải >= 0")
    @DecimalMax(value = "4.00", inclusive = true, message = "GPA phải <= 4")
    @Column(nullable = false, precision = 3, scale = 2)
    private BigDecimal gpa;

    // No-arg constructor
    public Student() {
    }

    // All-arg constructor (excluding id)
    public Student(String studentCode, String fullName, String email, String major, BigDecimal gpa) {
        this.studentCode = studentCode;
        this.fullName = fullName;
        this.email = email;
        this.major = major;
        this.gpa = gpa;
    }

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStudentCode() {
        return studentCode;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public BigDecimal getGpa() {
        return gpa;
    }

    public void setGpa(BigDecimal gpa) {
        this.gpa = gpa;
    }
}
