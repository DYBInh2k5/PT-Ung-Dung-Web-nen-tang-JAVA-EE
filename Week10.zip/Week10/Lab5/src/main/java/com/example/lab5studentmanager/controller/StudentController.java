package com.example.lab5studentmanager.controller;

import com.example.lab5studentmanager.entity.Student;
import com.example.lab5studentmanager.service.StudentService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/students")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    /**
     * GET /students
     * List all students, or filter by keyword if provided.
     */
    @GetMapping
    public String listStudents(@RequestParam(required = false) String keyword, Model model) {
        model.addAttribute("students", studentService.findAll(keyword));
        model.addAttribute("keyword", keyword);
        return "students/list";
    }

    /**
     * GET /students/new
     * Show the form for adding a new student.
     */
    @GetMapping("/new")
    public String showAddForm(Model model) {
        model.addAttribute("student", new Student());
        model.addAttribute("title", "Thêm sinh viên");
        return "students/form";
    }

    /**
     * GET /students/edit/{id}
     * Show the form pre-populated with the student's current data.
     */
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        try {
            Student student = studentService.findById(id);
            model.addAttribute("student", student);
            model.addAttribute("title", "Cập nhật sinh viên");
            return "students/form";
        } catch (EntityNotFoundException e) {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy sinh viên");
            return "redirect:/students";
        }
    }

    /**
     * POST /students/save
     * Validate and save (create or update) a student.
     */
    @PostMapping("/save")
    public String saveStudent(@Valid @ModelAttribute("student") Student student,
                              BindingResult bindingResult,
                              Model model,
                              RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            String title = (student.getId() == null) ? "Thêm sinh viên" : "Cập nhật sinh viên";
            model.addAttribute("title", title);
            return "students/form";
        }

        try {
            studentService.save(student);
        } catch (DataIntegrityViolationException e) {
            model.addAttribute("error", "Mã sinh viên đã tồn tại");
            String title = (student.getId() == null) ? "Thêm sinh viên" : "Cập nhật sinh viên";
            model.addAttribute("title", title);
            return "students/form";
        }

        redirectAttributes.addFlashAttribute("message", "Lưu sinh viên thành công");
        return "redirect:/students";
    }

    /**
     * GET /students/delete/{id}
     * Delete a student by id and redirect to the list.
     */
    @GetMapping("/delete/{id}")
    public String deleteStudent(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        studentService.deleteById(id);
        redirectAttributes.addFlashAttribute("message", "Xóa sinh viên thành công");
        return "redirect:/students";
    }
}
