# Requirements Document

## Introduction

This feature implements a Student Management Website using Spring Boot, Spring Data JPA, Thymeleaf, and SQL Server. The system allows users to view, add, edit, delete, and search students stored in a SQL Server database (Lab5Db). The website exposes a web interface at `/students` and performs full CRUD operations on the `student` table. The database schema is pre-created via SQL script; the application does not manage DDL.

---

## Glossary

- **System**: The Spring Boot Student Management Web Application
- **Student**: A record in the `student` table with fields: id, studentCode, fullName, email, major, gpa
- **StudentRepository**: The Spring Data JPA repository interface extending `JpaRepository<Student, Long>`
- **StudentService**: The service layer component that orchestrates business logic for student operations
- **StudentController**: The Spring MVC controller mapped to `/students` that handles HTTP requests
- **Lab5Db**: The SQL Server database used by the application
- **Thymeleaf**: The server-side HTML template engine used to render views
- **Bean Validation**: The Jakarta Bean Validation annotations (e.g., `@NotBlank`, `@DecimalMin`) applied to the Student entity
- **Keyword**: A search string entered by the user to filter students by full name (case-insensitive, partial match)
- **list.html**: The Thymeleaf template at `templates/students/list.html` that displays the student list and search form
- **form.html**: The Thymeleaf template at `templates/students/form.html` used for both add and edit operations

---

## Requirements

### Requirement 1: Database Connectivity

**User Story:** As a developer, I want the application to connect to a SQL Server database, so that student data is persisted and retrieved reliably.

#### Acceptance Criteria

1. THE System SHALL connect to SQL Server at `localhost:1433` using the database `Lab5Db` with username `sa` and a configurable password via `application.properties`.
2. THE System SHALL use `spring.jpa.hibernate.ddl-auto=none` so that the application does not modify the existing database schema.
3. THE System SHALL log all executed SQL statements to the console when `spring.jpa.show-sql=true` is configured.
4. IF the database connection cannot be established at startup, THEN THE System SHALL fail to start and log a descriptive error message.

---

### Requirement 2: Student Entity Mapping

**User Story:** As a developer, I want the Student entity to map to the `student` table, so that JPA can read and write student records correctly.

#### Acceptance Criteria

1. THE System SHALL map the `Student` entity class to the `student` table in `Lab5Db` with the following columns:
   - `id` — `BIGINT IDENTITY` primary key, auto-generated
   - `student_code` — `NVARCHAR(20)`, unique, not null
   - `full_name` — `NVARCHAR(100)`, not null
   - `email` — `NVARCHAR(100)`, not null
   - `major` — `NVARCHAR(100)`, not null
   - `gpa` — `DECIMAL(3,2)`, not null
2. THE System SHALL enforce Bean Validation constraints on the `Student` entity such that `studentCode`, `fullName`, `email`, and `major` are not blank, and `gpa` is a decimal value between `0.00` and `4.00` inclusive.
3. WHEN a `Student` object fails Bean Validation, THE System SHALL reject the object and return validation error messages to the view without persisting the invalid data.

---

### Requirement 3: Student Repository

**User Story:** As a developer, I want a repository interface for Student, so that CRUD operations and name-based search are available without writing boilerplate SQL.

#### Acceptance Criteria

1. THE StudentRepository SHALL extend `JpaRepository<Student, Long>` to provide standard CRUD operations including `findAll`, `findById`, `save`, and `deleteById`.
2. THE StudentRepository SHALL declare the method `findByFullNameContainingIgnoreCase(String keyword)` that returns a list of `Student` records whose `fullName` contains the given keyword, case-insensitively.
3. WHEN `findByFullNameContainingIgnoreCase` is called with an empty string, THE StudentRepository SHALL return all student records.

---

### Requirement 4: Student Service Layer

**User Story:** As a developer, I want a service layer for student operations, so that business logic is separated from the controller and repository.

#### Acceptance Criteria

1. THE StudentService SHALL provide a `findAll(String keyword)` method that delegates to `StudentRepository.findByFullNameContainingIgnoreCase(keyword)` when the keyword is not blank, and to `StudentRepository.findAll()` when the keyword is blank or null.
2. THE StudentService SHALL provide a `findById(Long id)` method that returns the `Student` with the given id, or throws an exception if no student with that id exists.
3. THE StudentService SHALL provide a `save(Student student)` method that persists a new or updated `Student` record via the repository.
4. THE StudentService SHALL provide a `deleteById(Long id)` method that removes the `Student` record with the given id from the database.

---

### Requirement 5: Display Student List

**User Story:** As a user, I want to see a list of all students on the website, so that I can review the current student records.

#### Acceptance Criteria

1. WHEN a GET request is made to `/students`, THE StudentController SHALL retrieve all students via `StudentService.findAll` and render `list.html` with the student data.
2. THE `list.html` template SHALL display each student's `studentCode`, `fullName`, `email`, `major`, and `gpa` in a tabular format.
3. THE `list.html` template SHALL display an Edit button and a Delete button for each student row.
4. WHEN no students exist in the database, THE `list.html` template SHALL display an appropriate empty-state message instead of an empty table.

---

### Requirement 6: Search Students by Name

**User Story:** As a user, I want to search students by name, so that I can quickly find a specific student without scrolling through the entire list.

#### Acceptance Criteria

1. THE `list.html` template SHALL display a search form with a text input field and a submit button.
2. WHEN a GET request is made to `/students` with a `keyword` query parameter, THE StudentController SHALL pass the keyword to `StudentService.findAll(keyword)` and render `list.html` with the filtered results.
3. WHEN the search returns no matching students, THE `list.html` template SHALL display a message indicating no students were found for the given keyword.
4. WHEN the search form is submitted with a blank keyword, THE StudentController SHALL return the full list of students.
5. THE search SHALL be case-insensitive and match students whose `fullName` contains the keyword as a substring.

---

### Requirement 7: Add a New Student

**User Story:** As a user, I want to fill in a form to add a new student, so that I can register new students in the system.

#### Acceptance Criteria

1. WHEN a GET request is made to `/students/new`, THE StudentController SHALL render `form.html` with an empty `Student` object bound to the form.
2. THE `form.html` template SHALL display input fields for `studentCode`, `fullName`, `email`, `major`, and `gpa`.
3. WHEN a POST request is made to `/students/save` with valid student data, THE StudentController SHALL invoke `StudentService.save` and redirect to `/students`.
4. WHEN a POST request is made to `/students/save` with invalid student data (Bean Validation failure), THE StudentController SHALL re-render `form.html` with the submitted data and display field-level validation error messages.
5. IF a `studentCode` that already exists in the database is submitted, THEN THE System SHALL reject the submission and display an error message indicating the student code must be unique.

---

### Requirement 8: Edit an Existing Student

**User Story:** As a user, I want to edit a student's information, so that I can correct or update student records.

#### Acceptance Criteria

1. WHEN a GET request is made to `/students/edit/{id}`, THE StudentController SHALL retrieve the student with the given `id` via `StudentService.findById` and render `form.html` pre-populated with the student's current data.
2. WHEN a POST request is made to `/students/save` with valid updated student data, THE StudentController SHALL invoke `StudentService.save` and redirect to `/students`.
3. WHEN a POST request is made to `/students/save` with invalid updated data, THE StudentController SHALL re-render `form.html` with the submitted data and display field-level validation error messages.
4. IF the `id` in the edit URL does not correspond to any existing student, THEN THE System SHALL redirect to `/students` and display an error message.

---

### Requirement 9: Delete a Student

**User Story:** As a user, I want to delete a student record, so that I can remove students who are no longer enrolled.

#### Acceptance Criteria

1. WHEN a GET request is made to `/students/delete/{id}`, THE StudentController SHALL invoke `StudentService.deleteById` with the given `id` and redirect to `/students`.
2. IF the `id` in the delete URL does not correspond to any existing student, THEN THE System SHALL redirect to `/students` without throwing an unhandled exception.

---

### Requirement 10: Initial Sample Data

**User Story:** As a developer, I want 10 sample students pre-inserted in the database, so that the application has data to display immediately after setup.

#### Acceptance Criteria

1. THE Lab5Db database SHALL contain exactly 10 pre-inserted student records with student codes `SV001` through `SV010` after the SQL setup script is executed.
2. THE System SHALL display all 10 sample students on the `/students` page when no search keyword is provided and no records have been deleted.

---

### Requirement 11: Application Configuration

**User Story:** As a developer, I want the application to be correctly configured via `application.properties`, so that the server, database, and template engine behave as expected.

#### Acceptance Criteria

1. THE System SHALL start the embedded web server on port `8080` as configured by `server.port=8080`.
2. THE System SHALL disable Thymeleaf template caching when `spring.thymeleaf.cache=false` is configured, so that template changes are reflected without restarting the server.
3. THE System SHALL include `spring-boot-devtools` as a dependency to support automatic application restart during development.
