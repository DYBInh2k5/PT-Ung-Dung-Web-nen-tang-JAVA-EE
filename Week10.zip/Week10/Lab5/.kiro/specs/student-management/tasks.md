# Implementation Plan: Student Management

## Overview

Build a complete, runnable Spring Boot 3 Maven project that can be opened and run directly in IntelliJ IDEA. The project implements full CRUD + keyword search for student records stored in a SQL Server database (`Lab5Db`), rendered via Thymeleaf templates with Bootstrap 5.

## Tasks

- [x] 1. Create Maven project structure and `pom.xml`
  - Create `pom.xml` at the workspace root with:
    - `groupId`: `com.example`, `artifactId`: `lab5-student-manager`, `version`: `0.0.1-SNAPSHOT`
    - Parent: `spring-boot-starter-parent` 3.x
    - Java 17 source/target (`<java.version>17</java.version>`)
    - Dependencies: `spring-boot-starter-web`, `spring-boot-starter-thymeleaf`, `spring-boot-starter-data-jpa`, `spring-boot-starter-validation`, `mssql-jdbc` (runtime), `spring-boot-devtools` (runtime, optional), `spring-boot-starter-test` (test), `jqwik 1.8.4` (test)
    - Plugin: `spring-boot-maven-plugin`
  - Create all required source directories:
    - `src/main/java/com/example/lab5studentmanager/`
    - `src/main/java/com/example/lab5studentmanager/entity/`
    - `src/main/java/com/example/lab5studentmanager/repository/`
    - `src/main/java/com/example/lab5studentmanager/service/`
    - `src/main/java/com/example/lab5studentmanager/controller/`
    - `src/main/resources/templates/students/`
    - `src/test/java/com/example/lab5studentmanager/`
  - _Requirements: 11.1, 11.3_

- [x] 2. Configure `application.properties`
  - Create `src/main/resources/application.properties` with:
    - `server.port=8080`
    - SQL Server datasource URL pointing to `localhost:1433`, database `Lab5Db`, `encrypt=false`, `trustServerCertificate=true`
    - Username `sa`, password placeholder `YourPassword`
    - Driver class `com.microsoft.sqlserver.jdbc.SQLServerDriver`
    - `spring.jpa.hibernate.ddl-auto=none`
    - `spring.jpa.show-sql=true`
    - `spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.SQLServerDialect`
    - `spring.jpa.properties.hibernate.format_sql=true`
    - `spring.thymeleaf.cache=false`
  - _Requirements: 1.1, 1.2, 1.3, 11.1, 11.2_

- [x] 3. Create the main application entry point
  - Create `src/main/java/com/example/lab5studentmanager/Lab5StudentManagerApplication.java`
  - Annotate with `@SpringBootApplication`
  - Implement `main` method calling `SpringApplication.run(...)`
  - _Requirements: 1.4_

- [x] 4. Implement the `Student` entity
  - Create `src/main/java/com/example/lab5studentmanager/entity/Student.java`
  - Annotate with `@Entity`, `@Table(name = "student")`
  - Map all six fields to their columns as specified in the design:
    - `id` — `@Id @GeneratedValue(strategy = GenerationType.IDENTITY)`
    - `studentCode` — `@Column(name = "student_code", unique = true)`, `@NotBlank`
    - `fullName` — `@Column(name = "full_name")`, `@NotBlank`
    - `email` — `@NotBlank`
    - `major` — `@NotBlank`
    - `gpa` — `@NotNull @DecimalMin("0.00") @DecimalMax("4.00")`
  - Add no-arg constructor, all-arg constructor, and getters/setters
  - _Requirements: 2.1, 2.2_

- [x] 5. Implement `StudentRepository`
  - Create `src/main/java/com/example/lab5studentmanager/repository/StudentRepository.java`
  - Extend `JpaRepository<Student, Long>`
  - Declare `List<Student> findByFullNameContainingIgnoreCase(String keyword)`
  - _Requirements: 3.1, 3.2, 3.3_

- [x] 6. Implement `StudentService`
  - Create `src/main/java/com/example/lab5studentmanager/service/StudentService.java`
  - Annotate with `@Service`; inject `StudentRepository` via constructor
  - Implement `findAll(String keyword)`: call `findByFullNameContainingIgnoreCase` when keyword is non-blank, otherwise `findAll()`
  - Implement `findById(Long id)`: use `orElseThrow(EntityNotFoundException::new)`
  - Implement `save(Student student)`: delegate to `repository.save`
  - Implement `deleteById(Long id)`: delegate to `repository.deleteById`
  - _Requirements: 4.1, 4.2, 4.3, 4.4_

- [x] 7. Implement `StudentController`
  - Create `src/main/java/com/example/lab5studentmanager/controller/StudentController.java`
  - Annotate with `@Controller @RequestMapping("/students")`; inject `StudentService` via constructor
  - `GET /students` (`listStudents`): accept optional `keyword` param, call `service.findAll(keyword)`, add to model, return `"students/list"`
  - `GET /students/new` (`showAddForm`): add empty `new Student()` to model as `"student"`, return `"students/form"`
  - `GET /students/edit/{id}` (`showEditForm`): call `service.findById(id)`, add to model, return `"students/form"`; catch `EntityNotFoundException` → redirect to `/students`
  - `POST /students/save` (`saveStudent`): use `@Valid @ModelAttribute Student student, BindingResult result`; if `result.hasErrors()` return `"students/form"`; catch `DataIntegrityViolationException` for duplicate code → add global error and return form; otherwise `service.save(student)` and redirect to `/students`
  - `GET /students/delete/{id}` (`deleteStudent`): call `service.deleteById(id)`, redirect to `/students`
  - _Requirements: 5.1, 6.2, 6.4, 7.1, 7.3, 7.4, 7.5, 8.1, 8.2, 8.3, 8.4, 9.1, 9.2_

- [x] 8. Create `list.html` Thymeleaf template
  - Create `src/main/resources/templates/students/list.html`
  - Bootstrap 5 layout with navbar and container
  - Search form: `GET /students`, text input bound to `keyword`, submit button
  - Table with columns: Student Code, Full Name, Email, Major, GPA, Actions
  - Iterate students with `th:each`; display each field with `th:text`
  - Edit button: link to `/students/edit/{id}` using `th:href`
  - Delete button: link to `/students/delete/{id}` using `th:href`
  - Empty-state message (`th:if="${#lists.isEmpty(students)}"`) when no students exist
  - "No results" message when search returns nothing (keyword present but list empty)
  - "Add New Student" button linking to `/students/new`
  - _Requirements: 5.2, 5.3, 5.4, 6.1, 6.3_

- [x] 9. Create `form.html` Thymeleaf template
  - Create `src/main/resources/templates/students/form.html`
  - Bootstrap 5 form bound to `student` object via `th:object="${student}"`
  - Hidden `id` field: `th:field="*{id}"`
  - Input fields for `studentCode`, `fullName`, `email`, `major`, `gpa` using `th:field`
  - Field-level validation errors via `th:errors` for each field
  - Global error display for duplicate student code
  - Submit button (POST to `/students/save`) and Cancel link back to `/students`
  - Dynamic page title: "Add Student" vs "Edit Student" based on whether `id` is null
  - _Requirements: 7.2, 7.4, 7.5, 8.1, 8.3_

- [x] 10. Create the SQL setup script
  - Create `src/main/resources/db/setup.sql` with:
    - `CREATE TABLE student (...)` DDL matching the design schema
    - 10 `INSERT` statements for sample students `SV001`–`SV010` with Vietnamese names and majors as specified in the design
  - Add a comment at the top explaining this script must be run manually against `Lab5Db` before starting the application
  - _Requirements: 10.1, 10.2_

- [x] 11. Create the application test class
  - Create `src/test/java/com/example/lab5studentmanager/Lab5StudentManagerApplicationTests.java`
  - Annotate with `@SpringBootTest`
  - Add a `contextLoads()` test method (empty body — verifies the Spring context starts without errors)
  - _Requirements: 1.4_

- [ ] 12. Checkpoint — Verify project compiles and structure is complete
  - Ensure all files listed in the project structure exist:
    - `pom.xml`
    - `src/main/java/com/example/lab5studentmanager/Lab5StudentManagerApplication.java`
    - `src/main/java/com/example/lab5studentmanager/entity/Student.java`
    - `src/main/java/com/example/lab5studentmanager/repository/StudentRepository.java`
    - `src/main/java/com/example/lab5studentmanager/service/StudentService.java`
    - `src/main/java/com/example/lab5studentmanager/controller/StudentController.java`
    - `src/main/resources/application.properties`
    - `src/main/resources/templates/students/list.html`
    - `src/main/resources/templates/students/form.html`
    - `src/test/java/com/example/lab5studentmanager/Lab5StudentManagerApplicationTests.java`
  - Run `mvn compile` to confirm zero compilation errors
  - Ask the user if any questions arise before proceeding to property tests

- [ ] 13. Write property-based tests
  - [ ] 13.1 Add jqwik dependency to `pom.xml` (if not already present) and create test base classes
    - Confirm `net.jqwik:jqwik:1.8.4` is in `pom.xml` test scope
    - _Requirements: 2.2, 4.2, 4.3, 4.4_

  - [ ]* 13.2 Write property test for Student save round-trip (Property 1)
    - Create `src/test/java/com/example/lab5studentmanager/StudentServicePropertyTest.java`
    - Use `@DataJpaTest` + `@ExtendWith(JqwikExtension.class)` (or `@SpringBootTest` with H2)
    - Generate valid `Student` objects (non-blank fields, GPA in [0.00, 4.00])
    - Save via service, retrieve by id, assert all fields equal
    - Tag: `// Feature: student-management, Property 1: Save round-trip preserves all fields`
    - **Property 1: Student Save Round-Trip**
    - **Validates: Requirements 2.1, 4.3**

  - [ ]* 13.3 Write property test for Bean Validation rejects invalid students (Property 2)
    - Create `src/test/java/com/example/lab5studentmanager/StudentValidationPropertyTest.java`
    - Generate `Student` objects with at least one blank required field or GPA outside [0.00, 4.00]
    - Assert `Validator.validate(student)` returns at least one `ConstraintViolation`
    - Assert the invalid student is not persisted
    - Tag: `// Feature: student-management, Property 2: Invalid students produce constraint violations`
    - **Property 2: Bean Validation Rejects Invalid Students**
    - **Validates: Requirements 2.2**

  - [ ]* 13.4 Write property test for name search returns correct subset (Property 3)
    - Create `src/test/java/com/example/lab5studentmanager/StudentRepositoryPropertyTest.java`
    - Use `@DataJpaTest`
    - Generate a list of students and a keyword; save all; call `findByFullNameContainingIgnoreCase(keyword)`
    - Assert result contains exactly those students whose `fullName` contains keyword (case-insensitive)
    - Tag: `// Feature: student-management, Property 3: Name search returns correct subset`
    - **Property 3: Name Search Returns Correct Subset**
    - **Validates: Requirements 3.2, 3.3, 6.2, 6.5**

  - [ ]* 13.5 Write property test for findById returns existing or throws for missing (Property 4)
    - In `StudentServicePropertyTest.java`
    - For saved students: assert `findById(id)` returns the student
    - For arbitrary ids not in the DB: assert `findById(id)` throws an exception
    - Tag: `// Feature: student-management, Property 4: findById returns existing or throws for missing`
    - **Property 4: findById Returns Existing or Throws for Missing**
    - **Validates: Requirements 4.2**

  - [ ]* 13.6 Write property test for delete removes student from repository (Property 5)
    - In `StudentServicePropertyTest.java`
    - Save a student, call `deleteById(id)`, assert `findAll("")` does not contain the student, assert `findById(id)` throws
    - Tag: `// Feature: student-management, Property 5: Delete removes student from repository`
    - **Property 5: Delete Removes Student from Repository**
    - **Validates: Requirements 4.4, 9.1**

  - [ ]* 13.7 Write property test for list rendering completeness (Property 6)
    - Create `src/test/java/com/example/lab5studentmanager/StudentControllerPropertyTest.java`
    - Use `@SpringBootTest` + `@AutoConfigureMockMvc`
    - Generate a non-empty list of students; mock service to return them; perform `GET /students`
    - Assert rendered HTML contains each student's `studentCode`, `fullName`, `email`, `major`, `gpa`, edit link, and delete link
    - Tag: `// Feature: student-management, Property 6: List rendering completeness`
    - **Property 6: List Rendering Completeness**
    - **Validates: Requirements 5.2, 5.3**

  - [ ]* 13.8 Write property test for valid POST saves and redirects (Property 7)
    - In `StudentControllerPropertyTest.java`
    - Generate valid student form data; perform `POST /students/save`
    - Assert HTTP 3xx redirect to `/students` and student is persisted
    - Tag: `// Feature: student-management, Property 7: Valid POST saves and redirects`
    - **Property 7: Valid POST Save Persists and Redirects**
    - **Validates: Requirements 7.3, 8.2**

  - [ ]* 13.9 Write property test for invalid POST re-renders form with errors (Property 8)
    - In `StudentControllerPropertyTest.java`
    - Generate invalid student form data (blank field or out-of-range GPA); perform `POST /students/save`
    - Assert HTTP 200, view is `students/form`, at least one validation error present, no new record persisted
    - Tag: `// Feature: student-management, Property 8: Invalid POST re-renders with errors`
    - **Property 8: Invalid POST Re-renders Form with Errors**
    - **Validates: Requirements 7.4, 8.3**

- [ ] 14. Final checkpoint — Ensure all tests pass
  - Run `mvn test` and confirm all non-optional tests pass
  - Ensure the project compiles cleanly with `mvn compile`
  - Ask the user if any questions arise

## Notes

- Tasks marked with `*` are optional and can be skipped for a faster MVP
- Update `spring.datasource.password` in `application.properties` to match your SQL Server `sa` password before running
- Run `src/main/resources/db/setup.sql` against `Lab5Db` in SQL Server Management Studio (or Azure Data Studio) before starting the application
- To run in IntelliJ IDEA: open the workspace root as a Maven project, wait for dependencies to download, then run `Lab5StudentManagerApplication`
- Each task references specific requirements for traceability
- Property tests use jqwik and require an H2 or Testcontainers SQL Server instance for data-layer tests
