# Design Document — Student Management

## Overview

This document describes the technical design for the Student Management Web Application built with Spring Boot 3, Spring Data JPA, Thymeleaf, and Microsoft SQL Server. The application exposes a web interface at `/students` and supports full CRUD operations (Create, Read, Update, Delete) plus keyword-based search on student records stored in the `Lab5Db` SQL Server database.

The project follows the standard Maven directory layout and is designed to be opened and run directly in IntelliJ IDEA by importing the `pom.xml` and clicking **Run** on `Lab5StudentManagerApplication`.

### Technology Stack

| Layer | Technology |
|---|---|
| Language | Java 17 |
| Framework | Spring Boot 3.x |
| Persistence | Spring Data JPA (Hibernate) |
| Database | Microsoft SQL Server 2019+ (localhost:1433, database `Lab5Db`) |
| JDBC Driver | `com.microsoft.sqlserver:mssql-jdbc` (runtime) |
| View Layer | Thymeleaf 3 + Bootstrap 5 |
| Validation | Jakarta Bean Validation (`spring-boot-starter-validation`) |
| Build Tool | Apache Maven |
| Dev Tooling | Spring Boot DevTools (optional, runtime) |

---

## Architecture

The application follows the classic **MVC layered architecture** used by Spring Boot web applications:

```
Browser
  │  HTTP GET/POST
  ▼
StudentController  (Spring MVC — @Controller)
  │  calls
  ▼
StudentService     (Business Logic — @Service)
  │  calls
  ▼
StudentRepository  (Spring Data JPA — @Repository)
  │  JDBC / Hibernate
  ▼
SQL Server (Lab5Db — table: student)
```

```mermaid
graph TD
    Browser -->|HTTP| Controller[StudentController\n/students]
    Controller -->|findAll / save / delete| Service[StudentService]
    Service -->|JPA queries| Repo[StudentRepository]
    Repo -->|JDBC| DB[(SQL Server\nLab5Db.student)]
    Controller -->|Model + View name| Thymeleaf[Thymeleaf Templates\nlist.html / form.html]
    Thymeleaf -->|HTML| Browser
```

### Request Flow

1. Browser sends an HTTP request to `/students` (or sub-paths).
2. `StudentController` receives the request, calls `StudentService` for data.
3. `StudentService` applies business logic and delegates to `StudentRepository`.
4. `StudentRepository` executes the JPA/SQL query against SQL Server.
5. Results flow back up; the controller adds data to the Spring `Model`.
6. Thymeleaf renders the appropriate template (`list.html` or `form.html`) and returns HTML.

---

## Components and Interfaces

### 1. `Lab5StudentManagerApplication`

```
package com.example.lab5studentmanager;

@SpringBootApplication
public class Lab5StudentManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(Lab5StudentManagerApplication.class, args);
    }
}
```

Entry point. Bootstraps the Spring context.

---

### 2. `Student` (Entity)

```
package com.example.lab5studentmanager.entity;
```

Annotated with `@Entity`, `@Table(name = "student")`. Fields:

| Java Field | Column | Type | Constraints |
|---|---|---|---|
| `id` | `id` | `BIGINT IDENTITY` | `@Id @GeneratedValue(strategy = IDENTITY)` |
| `studentCode` | `student_code` | `NVARCHAR(20)` | `@NotBlank`, `@Column(unique=true)` |
| `fullName` | `full_name` | `NVARCHAR(100)` | `@NotBlank` |
| `email` | `email` | `NVARCHAR(100)` | `@NotBlank` |
| `major` | `major` | `NVARCHAR(100)` | `@NotBlank` |
| `gpa` | `gpa` | `DECIMAL(3,2)` | `@DecimalMin("0.00") @DecimalMax("4.00") @NotNull` |

---

### 3. `StudentRepository`

```
package com.example.lab5studentmanager.repository;

public interface StudentRepository extends JpaRepository<Student, Long> {
    List<Student> findByFullNameContainingIgnoreCase(String keyword);
}
```

Spring Data JPA derives the query automatically from the method name. No SQL needed.

---

### 4. `StudentService`

```
package com.example.lab5studentmanager.service;

@Service
public class StudentService {
    List<Student> findAll(String keyword);
    Student findById(Long id);          // throws EntityNotFoundException if missing
    Student save(Student student);
    void deleteById(Long id);
}
```

Business logic:
- `findAll(keyword)`: delegates to `findByFullNameContainingIgnoreCase` when keyword is non-blank; otherwise calls `findAll()`.
- `findById(id)`: wraps `repository.findById(id).orElseThrow(...)`.
- `save(student)`: calls `repository.save(student)`.
- `deleteById(id)`: calls `repository.deleteById(id)` (no-op if id absent, per Spring Data contract).

---

### 5. `StudentController`

```
package com.example.lab5studentmanager.controller;

@Controller
@RequestMapping("/students")
public class StudentController { ... }
```

| Method | HTTP | Path | Description |
|---|---|---|---|
| `listStudents` | GET | `/students` | List all / search by keyword |
| `showAddForm` | GET | `/students/new` | Show empty add form |
| `showEditForm` | GET | `/students/edit/{id}` | Show pre-populated edit form |
| `saveStudent` | POST | `/students/save` | Validate + save (add or update) |
| `deleteStudent` | GET | `/students/delete/{id}` | Delete by id, redirect |

---

### 6. Thymeleaf Templates

Located in `src/main/resources/templates/students/`.

#### `list.html`
- Bootstrap 5 navbar + container layout.
- Search form (`GET /students?keyword=...`).
- Table with columns: Student Code, Full Name, Email, Major, GPA, Actions.
- Edit and Delete buttons per row.
- Empty-state message when list is empty.
- "No results" message when search returns nothing.

#### `form.html`
- Bootstrap 5 form.
- Input fields for all editable fields (`studentCode`, `fullName`, `email`, `major`, `gpa`).
- Hidden `id` field for edit mode.
- Field-level validation error display via Thymeleaf `th:errors`.
- Submit button + Cancel link back to `/students`.

---

## Data Models

### SQL Server Table: `student`

```sql
CREATE TABLE student (
    id           BIGINT IDENTITY(1,1) PRIMARY KEY,
    student_code NVARCHAR(20)   NOT NULL UNIQUE,
    full_name    NVARCHAR(100)  NOT NULL,
    email        NVARCHAR(100)  NOT NULL,
    major        NVARCHAR(100)  NOT NULL,
    gpa          DECIMAL(3,2)   NOT NULL
);
```

### Sample Data (10 records)

```sql
INSERT INTO student (student_code, full_name, email, major, gpa) VALUES
('SV001', N'Nguyễn Văn An',    'an.nguyen@example.com',    N'Công nghệ thông tin', 3.50),
('SV002', N'Trần Thị Bình',    'binh.tran@example.com',    N'Kỹ thuật phần mềm',   3.75),
('SV003', N'Lê Văn Cường',     'cuong.le@example.com',     N'Hệ thống thông tin',  3.20),
('SV004', N'Phạm Thị Dung',    'dung.pham@example.com',    N'Công nghệ thông tin', 3.90),
('SV005', N'Hoàng Văn Em',     'em.hoang@example.com',     N'Kỹ thuật máy tính',   2.80),
('SV006', N'Ngô Thị Phương',   'phuong.ngo@example.com',   N'Kỹ thuật phần mềm',   3.60),
('SV007', N'Đặng Văn Giang',   'giang.dang@example.com',   N'Hệ thống thông tin',  3.10),
('SV008', N'Bùi Thị Hoa',      'hoa.bui@example.com',      N'Công nghệ thông tin', 3.45),
('SV009', N'Vũ Văn Inh',       'inh.vu@example.com',       N'Kỹ thuật máy tính',   2.95),
('SV010', N'Đinh Thị Kim',     'kim.dinh@example.com',     N'Kỹ thuật phần mềm',   3.80);
```

### `application.properties`

```properties
# Server
server.port=8080

# SQL Server DataSource
spring.datasource.url=jdbc:sqlserver://localhost:1433;databaseName=Lab5Db;encrypt=false;trustServerCertificate=true
spring.datasource.username=sa
spring.datasource.password=YourPassword
spring.datasource.driver-class-name=com.microsoft.sqlserver.jdbc.SQLServerDriver

# JPA / Hibernate
spring.jpa.hibernate.ddl-auto=none
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.SQLServerDialect
spring.jpa.properties.hibernate.format_sql=true

# Thymeleaf
spring.thymeleaf.cache=false
```

### `pom.xml` Dependencies

```xml
<dependencies>
    <!-- Spring Boot Web (MVC + Tomcat) -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <!-- Thymeleaf template engine -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-thymeleaf</artifactId>
    </dependency>

    <!-- Spring Data JPA -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>

    <!-- Bean Validation -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-validation</artifactId>
    </dependency>

    <!-- Microsoft SQL Server JDBC driver -->
    <dependency>
        <groupId>com.microsoft.sqlserver</groupId>
        <artifactId>mssql-jdbc</artifactId>
        <scope>runtime</scope>
    </dependency>

    <!-- DevTools (hot reload) -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-devtools</artifactId>
        <scope>runtime</scope>
        <optional>true</optional>
    </dependency>

    <!-- Test -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

---

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*


### Property 1: Student Save Round-Trip

*For any* valid `Student` object (non-blank required fields, GPA in [0.00, 4.00]), saving it via `StudentService.save` and then retrieving it by its assigned `id` via `StudentService.findById` should return a student with all fields equal to the original.

**Validates: Requirements 2.1, 4.3**

---

### Property 2: Bean Validation Rejects Invalid Students

*For any* `Student` object where at least one required field (`studentCode`, `fullName`, `email`, `major`) is blank, or where `gpa` is outside the range [0.00, 4.00], the Jakarta Bean Validation engine should produce at least one constraint violation and the object should not be persisted.

**Validates: Requirements 2.2**

---

### Property 3: Name Search Returns Correct Subset

*For any* non-empty list of students stored in the repository and any search keyword string, `StudentRepository.findByFullNameContainingIgnoreCase(keyword)` should return exactly those students whose `fullName` contains the keyword as a case-insensitive substring — no more, no fewer.

**Validates: Requirements 3.2, 3.3, 6.2, 6.5**

---

### Property 4: findById Returns Existing or Throws for Missing

*For any* student that has been saved to the repository, `StudentService.findById(id)` should return that student. *For any* id that does not correspond to a saved student, `StudentService.findById(id)` should throw an exception rather than returning null or an empty result.

**Validates: Requirements 4.2**

---

### Property 5: Delete Removes Student from Repository

*For any* student that exists in the repository, after calling `StudentService.deleteById(id)`, the student should no longer be returned by `StudentService.findAll("")` and `StudentService.findById(id)` should throw an exception.

**Validates: Requirements 4.4, 9.1**

---

### Property 6: List Rendering Completeness

*For any* non-empty list of students passed to the `list.html` template model, the rendered HTML should contain each student's `studentCode`, `fullName`, `email`, `major`, and `gpa`, as well as an edit link and a delete link for each student row.

**Validates: Requirements 5.2, 5.3**

---

### Property 7: Valid POST Save Persists and Redirects

*For any* valid `Student` form submission (all required fields non-blank, GPA in [0.00, 4.00], unique `studentCode`), a POST to `/students/save` should persist the student to the database and respond with a redirect (HTTP 3xx) to `/students`.

**Validates: Requirements 7.3, 8.2**

---

### Property 8: Invalid POST Re-renders Form with Errors

*For any* `Student` form submission that fails Bean Validation (blank required field or out-of-range GPA), a POST to `/students/save` should re-render `form.html` (HTTP 200) with at least one field-level validation error message visible, and no new record should be persisted.

**Validates: Requirements 7.4, 8.3**

---

## Error Handling

### Startup Failure
If the SQL Server connection cannot be established at startup, Spring Boot will throw a `DataSourceLookupFailureException` or `HikariPool` initialization error. The application will fail to start and log a descriptive error. No special handling is needed — this is standard Spring Boot behavior.

### Entity Not Found
`StudentService.findById(Long id)` throws `jakarta.persistence.EntityNotFoundException` (or a custom `RuntimeException`) when no student with the given id exists. The controller catches this in the edit and delete handlers and redirects to `/students` with a flash error message.

### Duplicate Student Code
SQL Server enforces the `UNIQUE` constraint on `student_code`. If a duplicate is submitted, Hibernate throws a `DataIntegrityViolationException`. The controller catches this and re-renders `form.html` with an error message: *"Student code already exists."*

### Bean Validation Errors
Spring MVC's `@Valid` + `BindingResult` pattern handles validation errors. When `BindingResult.hasErrors()` is true, the controller returns the form view without calling the service. Thymeleaf renders `th:errors` for each field.

### Unknown Routes
Spring Boot's default error handling returns a 404 page for unmapped paths. No custom error page is required for this feature.

---

## Testing Strategy

### Dual Testing Approach

This feature uses both **unit/example-based tests** and **property-based tests** for comprehensive coverage.

### Property-Based Testing Library

Use **[jqwik](https://jqwik.net/)** for Java property-based testing. Add to `pom.xml` test scope:

```xml
<dependency>
    <groupId>net.jqwik</groupId>
    <artifactId>jqwik</artifactId>
    <version>1.8.4</version>
    <scope>test</scope>
</dependency>
```

Each property test runs a minimum of **100 iterations** (jqwik default is 1000).

### Property Tests

Each property test references its design property via a comment tag:
`// Feature: student-management, Property N: <property_text>`

| Test Class | Property | Description |
|---|---|---|
| `StudentServicePropertyTest` | Property 1 | Save round-trip preserves all fields |
| `StudentValidationPropertyTest` | Property 2 | Invalid students produce constraint violations |
| `StudentRepositoryPropertyTest` | Property 3 | Name search returns correct subset |
| `StudentServicePropertyTest` | Property 4 | findById returns existing or throws for missing |
| `StudentServicePropertyTest` | Property 5 | Delete removes student from repository |
| `StudentControllerPropertyTest` | Property 6 | List rendering completeness |
| `StudentControllerPropertyTest` | Property 7 | Valid POST saves and redirects |
| `StudentControllerPropertyTest` | Property 8 | Invalid POST re-renders with errors |

### Unit / Example-Based Tests

Focus on specific scenarios not covered by property tests:

| Test | Description |
|---|---|
| `GET /students` returns 200 with list.html | Requirement 5.1 |
| `GET /students/new` returns empty form | Requirement 7.1 |
| `GET /students/edit/{id}` returns pre-populated form | Requirement 8.1 |
| `GET /students/edit/{nonExistentId}` redirects | Requirement 8.4 |
| `GET /students/delete/{nonExistentId}` redirects without error | Requirement 9.2 |
| POST with duplicate studentCode shows error | Requirement 7.5 |
| Empty list shows empty-state message | Requirement 5.4 |
| Search with no results shows no-results message | Requirement 6.3 |
| Blank keyword returns full list | Requirement 6.4 |
| `GET /students` with 10 sample students shows 10 rows | Requirement 10.2 |

### Integration Tests

Run against an in-memory H2 database (configured for SQL Server compatibility mode) or a Testcontainers SQL Server instance:

| Test | Description |
|---|---|
| Application context loads | Requirement 1.1, 1.4 |
| `findByFullNameContainingIgnoreCase` with real DB | Requirement 3.2 |
| Full CRUD flow end-to-end | Requirements 7, 8, 9 |

### Test Configuration Notes

- Use `@SpringBootTest` + `@AutoConfigureMockMvc` for controller tests.
- Use `@DataJpaTest` for repository tests (auto-configures in-memory DB).
- Use `@ExtendWith(JqwikExtension.class)` for jqwik property tests.
- Property generators should produce: valid students (all fields non-blank, GPA in [0.00, 4.00]), invalid students (blank fields, GPA out of range), random keywords (empty, single char, full name, partial name, mixed case).
