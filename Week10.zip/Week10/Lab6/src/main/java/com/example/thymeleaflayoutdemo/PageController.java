package com.example.thymeleaflayoutdemo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class PageController {
    @GetMapping("/")
    public String home() {
        return "home";
    }

    @GetMapping("/students")
    public String students(Model model) {
        List<Student> students = List.of(
            new Student("Nguyen Van An", "an@example.com"),
            new Student("Tran Thi Binh", "binh@example.com"),
            new Student("Le Minh Chi", "chi@example.com")
        );
        model.addAttribute("students", students);
        return "students/list";
    }

    @GetMapping("/courses")
    public String courses(Model model) {
        List<Course> courses = List.of(
            new Course("Lap trinh Java", 3),
            new Course("Co so du lieu", 4),
            new Course("Lap trinh Web", 3)
        );
        model.addAttribute("courses", courses);
        return "courses/list";
    }

    @GetMapping("/about")
    public String about() {
        return "about";
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact";
    }
}
