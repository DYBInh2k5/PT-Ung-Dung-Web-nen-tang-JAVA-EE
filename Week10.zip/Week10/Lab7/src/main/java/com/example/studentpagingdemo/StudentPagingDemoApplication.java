package com.example.studentpagingdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentPagingDemoApplication {
    public static void main(String[] args) {
        SpringApplication.run(StudentPagingDemoApplication.class, args);
    }
}
