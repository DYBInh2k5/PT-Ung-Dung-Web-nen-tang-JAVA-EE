package com.example.studentpagingdemo.repository;

import com.example.studentpagingdemo.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Integer> {
}
