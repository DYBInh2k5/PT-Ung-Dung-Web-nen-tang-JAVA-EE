package com.example.lab14ajax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab14AjaxApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab14AjaxApplication.class, args);
    }

}
