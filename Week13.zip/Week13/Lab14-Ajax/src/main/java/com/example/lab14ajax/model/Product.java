package com.example.lab14ajax.model;

/**
 * Model san pham dung de tao du lieu mau va tra JSON cho browser.
 */
public class Product {

    private final String code;
    private final String name;
    private final long price;
    private final String categoryCode;

    /**
     * Khoi tao mot san pham trong bo nho.
     *
     * @param code         ma san pham
     * @param name         ten san pham
     * @param price        gia ban
     * @param categoryCode ma danh muc con
     */
    public Product(String code, String name, long price, String categoryCode) {
        this.code = code;
        this.name = name;
        this.price = price;
        this.categoryCode = categoryCode;
    }

    /** @return ma san pham */
    public String getCode() {
        return code;
    }

    /** @return ten san pham */
    public String getName() {
        return name;
    }

    /** @return gia ban */
    public long getPrice() {
        return price;
    }

    /** @return ma danh muc con */
    public String getCategoryCode() {
        return categoryCode;
    }
}
