package com.example.lab14ajax.model;

/**
 * Model bieu dien mot lua chon trong danh muc con.
 */
public class CategoryItem {

    private final String code;
    private final String name;

    /**
     * Khoi tao mot danh muc con.
     *
     * @param code ma danh muc
     * @param name ten hien thi
     */
    public CategoryItem(String code, String name) {
        this.code = code;
        this.name = name;
    }

    /** @return ma danh muc */
    public String getCode() {
        return code;
    }

    /** @return ten hien thi cua danh muc */
    public String getName() {
        return name;
    }
}
