package com.example.lab14ajax.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Service kiem tra, luu va doc file anh tren filesystem cua Web Server.
 */
@Service
public class FileStorageService {

    private static final long MAX_UPLOAD_SIZE = 5L * 1024 * 1024;
    private static final Set<String> ALLOWED_EXTENSIONS =
            Set.of("jpg", "jpeg", "png", "webp", "gif");

    @Value("${app.upload-dir:uploads/lab14}")
    private String uploadDir;

    /**
     * Kiem tra va luu anh bang mot ten duy nhat do server sinh ra.
     *
     * @param file file anh browser gui len
     * @return ten file da luu tren Web Server
     */
    public String storeImage(MultipartFile file) {
        validateImage(file);

        String originalName = getSafeOriginalName(file);
        String extension    = getExtension(originalName).toLowerCase(Locale.ROOT);
        String savedName    = UUID.randomUUID() + "." + extension;

        try {
            Path uploadPath = getUploadPath();
            // Tu tao thu muc uploads/lab14 neu thu muc chua ton tai.
            Files.createDirectories(uploadPath);

            Path target = uploadPath.resolve(savedName).normalize();
            if (!target.startsWith(uploadPath)) {
                throw new IllegalArgumentException("Duong dan luu file khong hop le");
            }

            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
            return savedName;

        } catch (IOException ex) {
            throw new IllegalStateException("Khong the luu file len Web Server", ex);
        }
    }

    /**
     * Doc file da luu duoi dang Resource de Controller tra ve browser.
     *
     * @param fileName ten file do server da sinh
     * @return Resource dai dien cho file anh
     */
    public Resource loadAsResource(String fileName) {
        try {
            Path uploadPath = getUploadPath();
            Path filePath   = uploadPath.resolve(fileName).normalize();

            // Khong cho phep URL su dung ../ de doc file ngoai thu muc upload.
            if (!filePath.startsWith(uploadPath)) {
                throw new IllegalArgumentException("Duong dan file khong hop le");
            }

            Resource resource = new UrlResource(filePath.toUri());
            if (!resource.exists() || !resource.isReadable()) {
                throw new IllegalStateException("Khong tim thay file anh");
            }
            return resource;

        } catch (MalformedURLException ex) {
            throw new IllegalArgumentException("Ten file khong hop le", ex);
        }
    }

    /**
     * Kiem tra file co phai anh hop le va khong vuot qua 5 MB.
     *
     * @param file file upload can kiem tra
     */
    private void validateImage(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Vui long chon file anh");
        }
        if (file.getSize() > MAX_UPLOAD_SIZE) {
            throw new IllegalArgumentException("Dung luong anh khong duoc vuot qua 5 MB");
        }
        String contentType = file.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            throw new IllegalArgumentException("File duoc chon khong phai la anh");
        }
        String extension = getExtension(getSafeOriginalName(file)).toLowerCase(Locale.ROOT);
        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            throw new IllegalArgumentException("Chi cho phep file jpg, jpeg, png, webp hoac gif");
        }
    }

    /**
     * Lay va lam sach ten file goc.
     *
     * @param file file upload
     * @return ten file an toan hon sau khi cleanPath
     */
    private String getSafeOriginalName(MultipartFile file) {
        String originalName = StringUtils.cleanPath(
                file.getOriginalFilename() == null ? "" : file.getOriginalFilename());
        if (!StringUtils.hasText(originalName) || originalName.contains("..")) {
            throw new IllegalArgumentException("Ten file khong hop le");
        }
        return originalName;
    }

    /**
     * Lay phan mo rong cua ten file.
     *
     * @param fileName ten file can xu ly
     * @return phan mo rong khong co dau cham
     */
    private String getExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        if (dotIndex < 0 || dotIndex == fileName.length() - 1) {
            throw new IllegalArgumentException("File anh phai co phan mo rong");
        }
        return fileName.substring(dotIndex + 1);
    }

    /**
     * Lay duong dan tuyet doi cua thu muc upload.
     *
     * @return Path tro den uploads/lab14 tren Web Server
     */
    private Path getUploadPath() {
        return Paths.get(uploadDir).toAbsolutePath().normalize();
    }
}
