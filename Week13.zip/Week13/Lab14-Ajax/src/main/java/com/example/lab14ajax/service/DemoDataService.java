package com.example.lab14ajax.service;

import com.example.lab14ajax.model.CategoryItem;
import com.example.lab14ajax.model.Product;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/**
 * Service giu toan bo du lieu mau trong bo nho.
 *
 * Du lieu se duoc tao lai moi lan ung dung khoi dong.
 */
@Service
public class DemoDataService {

    private final List<Product> products = List.of(
            new Product("SP001", "Laptop ASUS Vivobook 15",   15990000, "laptop"),
            new Product("SP002", "Laptop Dell Inspiron 14",   17490000, "laptop"),
            new Product("SP003", "Man hinh Dell 24 inch",      3290000, "monitor"),
            new Product("SP004", "Man hinh LG UltraGear 27 inch", 5890000, "monitor"),
            new Product("SP005", "Tai nghe Sony WH-CH520",    1190000, "audio"),
            new Product("SP006", "Loa Bluetooth JBL Go 4",     990000, "audio"),
            new Product("SP007", "Ban phim co Keychron K2",   1890000, "keyboard"),
            new Product("SP008", "Chuot Logitech M650",        790000, "mouse"),
            new Product("SP009", "O cung SSD Samsung 1TB",    2490000, "storage"),
            new Product("SP010", "Ban lam viec FlexiDesk",    3490000, "desk"),
            new Product("SP011", "Ghe cong thai hoc Sihoo M57", 4290000, "chair"),
            new Product("SP012", "Den ban Xiaomi Mi Desk Lamp", 1190000, "lighting")
    );

    private final Map<String, List<CategoryItem>> childCategories = new LinkedHashMap<>();

    /**
     * Khoi tao quan he giua danh muc cha va danh muc con.
     */
    public DemoDataService() {
        childCategories.put("electronics", List.of(
                new CategoryItem("laptop",  "Laptop"),
                new CategoryItem("monitor", "Man hinh"),
                new CategoryItem("audio",   "Thiet bi am thanh")
        ));
        childCategories.put("accessories", List.of(
                new CategoryItem("keyboard", "Ban phim"),
                new CategoryItem("mouse",    "Chuot"),
                new CategoryItem("storage",  "Thiet bi luu tru")
        ));
        childCategories.put("office", List.of(
                new CategoryItem("desk",     "Ban lam viec"),
                new CategoryItem("chair",    "Ghe van phong"),
                new CategoryItem("lighting", "Den ban")
        ));
    }

    /**
     * Tim mot san pham theo ma, khong phan biet chu hoa va chu thuong.
     *
     * @param code ma san pham can tim
     * @return Optional chua san pham neu tim thay
     */
    public Optional<Product> findByCode(String code) {
        return products.stream()
                .filter(product -> product.getCode().equalsIgnoreCase(code))
                .findFirst();
    }

    /**
     * Lay toan bo san pham.
     *
     * @return danh sach san pham trong bo nho
     */
    public List<Product> findAll() {
        return products;
    }

    /**
     * Tim toi da sau san pham co ten chua tu khoa.
     *
     * @param keyword tu khoa autocomplete
     * @return danh sach san pham goi y
     */
    public List<Product> suggestByName(String keyword) {
        String normalizedKeyword = keyword.trim().toLowerCase(Locale.ROOT);
        if (normalizedKeyword.length() < 2) {
            return List.of();
        }
        return products.stream()
                .filter(product -> product.getName().toLowerCase(Locale.ROOT)
                        .contains(normalizedKeyword))
                .limit(6)
                .toList();
    }

    /**
     * Lay danh muc con cua mot danh muc cha.
     *
     * @param parentCode ma danh muc cha
     * @return danh sach danh muc con hoac danh sach rong
     */
    public List<CategoryItem> findChildCategories(String parentCode) {
        return childCategories.getOrDefault(parentCode, List.of());
    }

    /**
     * Lay san pham thuoc mot danh muc con.
     *
     * @param categoryCode ma danh muc con
     * @return danh sach san pham phu hop
     */
    public List<Product> findByCategory(String categoryCode) {
        return products.stream()
                .filter(product -> product.getCategoryCode().equals(categoryCode))
                .toList();
    }
}
