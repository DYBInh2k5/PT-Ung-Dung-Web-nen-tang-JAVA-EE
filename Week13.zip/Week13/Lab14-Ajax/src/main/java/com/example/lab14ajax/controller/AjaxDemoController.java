package com.example.lab14ajax.controller;

import com.example.lab14ajax.model.CategoryItem;
import com.example.lab14ajax.model.Product;
import com.example.lab14ajax.service.DemoDataService;
import com.example.lab14ajax.service.FileStorageService;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.MediaTypeFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * Controller tra cac view Thymeleaf va cung cap API cho sau bai thuc hanh AJAX.
 */
@Controller
public class AjaxDemoController {

    private final DemoDataService    demoDataService;
    private final FileStorageService fileStorageService;

    /**
     * Khoi tao controller voi cac service can dung.
     *
     * @param demoDataService    service cung cap du lieu mau trong bo nho
     * @param fileStorageService service luu va doc file tren Web Server
     */
    public AjaxDemoController(DemoDataService demoDataService,
                               FileStorageService fileStorageService) {
        this.demoDataService    = demoDataService;
        this.fileStorageService = fileStorageService;
    }

    // -------------------------------------------------------------------------
    // Views
    // -------------------------------------------------------------------------

    /**
     * Hien thi trang chu chua link den cac bai thuc hanh.
     *
     * @return ten view index
     */
    @GetMapping("/")
    public String index() {
        return "index";
    }

    /** @return view Simple AJAX */
    @GetMapping("/simple-ajax")
    public String simpleAjax() {
        return "simple-ajax";
    }

    /** @return view AJAX Loader */
    @GetMapping("/ajax-loader")
    public String ajaxLoader() {
        return "ajax-loader";
    }

    /** @return view Digital Clock */
    @GetMapping("/digital-clock")
    public String digitalClock() {
        return "digital-clock";
    }

    /** @return view Search Autocomplete */
    @GetMapping("/autocomplete")
    public String autocomplete() {
        return "autocomplete";
    }

    /** @return view Dependent Dropdown */
    @GetMapping("/dependent-dropdown")
    public String dependentDropdown() {
        return "dependent-dropdown";
    }

    /** @return view Upload Progress */
    @GetMapping("/upload-progress")
    public String uploadProgress() {
        return "upload-progress";
    }

    // -------------------------------------------------------------------------
    // API - Muc 1: Simple AJAX
    // -------------------------------------------------------------------------

    /**
     * API tim san pham theo ma.
     *
     * @param code ma san pham nguoi dung nhap
     * @return JSON san pham hoac JSON loi 404
     */
    @ResponseBody
    @GetMapping("/api/products/{code}")
    public ResponseEntity<?> findProductByCode(@PathVariable String code) {
        Product product = demoDataService.findByCode(code.trim()).orElse(null);
        if (product == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("message", "Khong tim thay san pham " + code));
        }
        return ResponseEntity.ok(product);
    }

    // -------------------------------------------------------------------------
    // API - Muc 2: AJAX Loader
    // -------------------------------------------------------------------------

    /**
     * API tra toan bo san pham va co y cho mot giay de quan sat loader.
     *
     * @return danh sach san pham dang JSON
     */
    @ResponseBody
    @GetMapping("/api/products")
    public List<Product> getProducts() {
        simulateDelay(1000);
        return demoDataService.findAll();
    }

    /**
     * Tao do tre gia lap cho muc dich hoc loader.
     *
     * Khong nen dung Thread.sleep de xu ly cham trong ung dung that.
     *
     * @param milliseconds so mili giay can cho
     */
    private void simulateDelay(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException ex) {
            // Khoi phuc co interrupted de thread co the duoc xu ly dung o tang cao hon.
            Thread.currentThread().interrupt();
        }
    }

    // -------------------------------------------------------------------------
    // API - Muc 3: Digital Clock / Polling
    // -------------------------------------------------------------------------

    /**
     * API tra gio hien tai cua server theo mui gio Viet Nam.
     *
     * @return JSON gom gio va ten mui gio
     */
    @ResponseBody
    @GetMapping("/api/time")
    public Map<String, String> getServerTime() {
        ZoneId zoneId = ZoneId.of("Asia/Ho_Chi_Minh");
        ZonedDateTime now = ZonedDateTime.now(zoneId);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        return Map.of(
                "time", now.format(formatter),
                "zone", zoneId.getId()
        );
    }

    // -------------------------------------------------------------------------
    // API - Muc 4: Search Autocomplete
    // -------------------------------------------------------------------------

    /**
     * API goi y san pham theo ten cho autocomplete.
     *
     * @param keyword tu khoa nguoi dung dang go
     * @return toi da sau san pham phu hop
     */
    @ResponseBody
    @GetMapping("/api/products/suggest")
    public List<Product> suggestProducts(
            @RequestParam(defaultValue = "") String keyword) {
        return demoDataService.suggestByName(keyword);
    }

    // -------------------------------------------------------------------------
    // API - Muc 5: Dependent Dropdown
    // -------------------------------------------------------------------------

    /**
     * API lay danh muc con theo danh muc cha.
     *
     * @param parentCode ma danh muc cha
     * @return danh sach danh muc con
     */
    @ResponseBody
    @GetMapping("/api/categories/{parentCode}/children")
    public List<CategoryItem> getChildCategories(@PathVariable String parentCode) {
        return demoDataService.findChildCategories(parentCode);
    }

    /**
     * API lay san pham theo danh muc con.
     *
     * @param category ma danh muc con
     * @return danh sach san pham trong danh muc
     */
    @ResponseBody
    @GetMapping("/api/products/by-category")
    public List<Product> getProductsByCategory(@RequestParam String category) {
        return demoDataService.findByCategory(category);
    }

    // -------------------------------------------------------------------------
    // API - Muc 6: Upload anh
    // -------------------------------------------------------------------------

    /**
     * API luu file anh len filesystem cua Web Server.
     *
     * @param file file anh browser gui len
     * @return JSON chua ten file da luu va URL truy cap anh
     */
    @ResponseBody
    @PostMapping("/api/upload")
    public ResponseEntity<?> uploadImage(@RequestParam("file") MultipartFile file) {
        try {
            String savedName   = fileStorageService.storeImage(file);
            String imageUrl    = "/uploads/lab14/" + savedName;
            String originalName = file.getOriginalFilename() == null
                    ? "unknown"
                    : file.getOriginalFilename();

            return ResponseEntity.ok(Map.of(
                    "message",      "Da luu file len Web Server",
                    "originalName", originalName,
                    "savedName",    savedName,
                    "size",         file.getSize(),
                    "imageUrl",     imageUrl
            ));
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return ResponseEntity.badRequest()
                    .body(Map.of("message", ex.getMessage()));
        }
    }

    /**
     * Tra file anh da luu de browser co the hien thi bang the img.
     *
     * @param fileName ten file do server da sinh
     * @return noi dung file anh hoac HTTP 404
     */
    @ResponseBody
    @GetMapping("/uploads/lab14/{fileName:.+}")
    public ResponseEntity<Resource> showUploadedImage(@PathVariable String fileName) {
        try {
            Resource  resource  = fileStorageService.loadAsResource(fileName);
            MediaType mediaType = MediaTypeFactory.getMediaType(resource)
                    .orElse(MediaType.APPLICATION_OCTET_STREAM);
            return ResponseEntity.ok()
                    .contentType(mediaType)
                    .body(resource);
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return ResponseEntity.notFound().build();
        }
    }
}
