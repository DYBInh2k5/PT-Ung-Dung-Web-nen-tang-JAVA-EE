package com.example.lab2.controller;

import com.example.lab2.model.Product;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ProductController {

    @GetMapping("/products")
    public List<Product> getProducts() {
        List<Product> list = new ArrayList<>();
        list.add(new Product(1, "Laptop", 1500.0));
        list.add(new Product(2, "Mouse", 25.0));
        list.add(new Product(3, "Keyboard", 60.0));
        return list;
    }

    @GetMapping("/products/{id}")
    public Product getProductById(@PathVariable int id) {
        return new Product(id, "Product " + id, 100.0 + id);
    }

    @PostMapping("/products")
    public Product createProduct(@RequestBody Product product) {
        return product;
    }

    @PutMapping("/products/{id}")
    public Product updateProduct(@PathVariable int id, @RequestBody Product product) {
        product.setId(id);
        return product;
    }

    @DeleteMapping("/products/{id}")
    public String deleteProduct(@PathVariable int id) {
        return "Deleted product id = " + id;
    }
}
