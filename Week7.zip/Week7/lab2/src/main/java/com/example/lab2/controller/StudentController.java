package com.example.lab2.controller;

import com.example.lab2.model.Student;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class StudentController {

    @GetMapping("/student")
    public Student getStudent() {
        return new Student(1, "Nguyen Van A", 8.5);
    }

    @GetMapping("/students")
    public List<Student> getStudents() {
        List<Student> list = new ArrayList<>();
        list.add(new Student(1, "An", 8.0));
        list.add(new Student(2, "Binh", 7.5));
        list.add(new Student(3, "Cuong", 9.0));
        return list;
    }

    @GetMapping("/students/{id}")
    public Student getStudentById(@PathVariable int id) {
        return new Student(id, "Student " + id, 8.0);
    }

    @PostMapping("/students")
    public Student createStudent(@RequestBody Student student) {
        return student;
    }

    @PutMapping("/students/{id}")
    public Student updateStudent(@PathVariable int id, @RequestBody Student student) {
        student.setId(id);
        return student;
    }

    @DeleteMapping("/students/{id}")
    public String deleteStudent(@PathVariable int id) {
        return "Deleted student id = " + id;
    }
}
