package com.example.lab8securitydemo.controller;

import com.example.lab8securitydemo.dto.RegisterForm;
import com.example.lab8securitydemo.repository.AccountRepository;
import com.example.lab8securitydemo.service.AccountRegistrationService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class RegisterController {

    private final AccountRepository accountRepository;
    private final AccountRegistrationService registrationService;

    public RegisterController(AccountRepository accountRepository,
                              AccountRegistrationService registrationService) {
        this.accountRepository = accountRepository;
        this.registrationService = registrationService;
    }

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        if (!model.containsAttribute("registerForm")) {
            model.addAttribute("registerForm", new RegisterForm());
        }
        return "register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("registerForm") RegisterForm form,
                           BindingResult bindingResult,
                           RedirectAttributes redirectAttributes) {
        String email = form.getEmail() == null ? "" : form.getEmail().trim().toLowerCase();
        form.setEmail(email);

        if (form.getPassword() != null && !form.getPassword().equals(form.getConfirmPassword())) {
            bindingResult.rejectValue("confirmPassword", "password.mismatch", "Password nhập lại không khớp");
        }

        if (!email.isBlank() && accountRepository.existsByEmail(email)) {
            bindingResult.rejectValue("email", "email.exists", "Email này đã được sử dụng");
        }

        if (bindingResult.hasErrors()) {
            return "register";
        }

        registrationService.registerUser(form);
        redirectAttributes.addFlashAttribute("message", "Đăng ký thành công. Vui lòng đăng nhập.");
        return "redirect:/login";
    }
}
