package com.example.lab8securitydemo.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/session")
public class SessionController {

    @GetMapping
    public String index(HttpSession session, Authentication authentication, Model model) {
        Integer visitCount = (Integer) session.getAttribute("visitCount");
        if (visitCount == null) {
            visitCount = 0;
        }
        visitCount++;
        session.setAttribute("visitCount", visitCount);

        model.addAttribute("sessionId", session.getId());
        model.addAttribute("visitCount", visitCount);
        model.addAttribute("email", authentication.getName());
        model.addAttribute("authorities", authentication.getAuthorities());
        return "session/index";
    }

    @PostMapping("/reset-count")
    public String resetCount(HttpSession session) {
        session.removeAttribute("visitCount");
        return "redirect:/session";
    }
}
