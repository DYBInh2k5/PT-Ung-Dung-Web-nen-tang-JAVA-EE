package com.example.lab8securitydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab8SecurityDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab8SecurityDemoApplication.class, args);
    }

}
