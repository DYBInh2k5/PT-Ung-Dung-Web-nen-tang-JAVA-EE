package com.example.lab8securitydemo.service;

import com.example.lab8securitydemo.dto.RegisterForm;
import com.example.lab8securitydemo.entity.Account;
import com.example.lab8securitydemo.repository.AccountRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AccountRegistrationService {

    private final AccountRepository accountRepository;
    private final PasswordEncoder passwordEncoder;

    public AccountRegistrationService(AccountRepository accountRepository,
                                      PasswordEncoder passwordEncoder) {
        this.accountRepository = accountRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public void registerUser(RegisterForm form) {
        Account account = new Account();
        account.setFirstname(form.getFirstname().trim());
        account.setLastname(form.getLastname().trim());
        account.setEmail(form.getEmail().trim().toLowerCase());
        account.setPassword(passwordEncoder.encode(form.getPassword()));
        account.setRole("ROLE_USER");
        account.setEnabled(true);
        accountRepository.save(account);
    }
}
