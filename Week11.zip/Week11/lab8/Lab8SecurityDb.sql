-- Tạo database Lab8SecurityDb
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'Lab8SecurityDb')
BEGIN
    CREATE DATABASE Lab8SecurityDb;
END
GO

USE Lab8SecurityDb;
GO

-- Tạo bảng account
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'account')
BEGIN
    CREATE TABLE account (
        id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        firstname NVARCHAR(50) NOT NULL,
        lastname NVARCHAR(50) NOT NULL,
        email VARCHAR(150) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL,
        enabled BIT NOT NULL DEFAULT 1,
        CONSTRAINT CK_account_role CHECK (role IN ('ROLE_ADMIN', 'ROLE_USER'))
    );
END
GO

-- Tạo bảng product
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'product')
BEGIN
    CREATE TABLE product (
        id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        name NVARCHAR(120) NOT NULL,
        price DECIMAL(18,2) NOT NULL,
        quantity INT NOT NULL,
        active BIT NOT NULL DEFAULT 1
    );
END
GO

-- Insert tài khoản ADMIN: quan@gmail.com / 1
-- BCrypt hash của '1' (cost 10)
IF NOT EXISTS (SELECT 1 FROM account WHERE email = 'quan@gmail.com')
BEGIN
    INSERT INTO account (firstname, lastname, email, password, role, enabled)
    VALUES ('Quan', 'Nguyen', 'quan@gmail.com', '$2b$10$W1lsehhBJSkYAjUvCcZduO.xGvixTc8kxJTrbCsb7ZoqCkv7vC.v6', 'ROLE_ADMIN', 1);
END
GO

-- Insert tài khoản USER: han@gmail.com / 1
IF NOT EXISTS (SELECT 1 FROM account WHERE email = 'han@gmail.com')
BEGIN
    INSERT INTO account (firstname, lastname, email, password, role, enabled)
    VALUES ('Han', 'Tran', 'han@gmail.com', '$2b$10$W1lsehhBJSkYAjUvCcZduO.xGvixTc8kxJTrbCsb7ZoqCkv7vC.v6', 'ROLE_USER', 1);
END
GO

-- Insert sản phẩm mẫu
IF NOT EXISTS (SELECT 1 FROM product WHERE name = 'Laptop Dell XPS 15')
BEGIN
    INSERT INTO product (name, price, quantity, active) VALUES ('Laptop Dell XPS 15', 25000000, 10, 1);
    INSERT INTO product (name, price, quantity, active) VALUES ('iPhone 15 Pro Max', 35000000, 5, 1);
    INSERT INTO product (name, price, quantity, active) VALUES ('Tai nghe Sony WH-1000XM5', 7000000, 20, 1);
    INSERT INTO product (name, price, quantity, active) VALUES ('Bàn phím cơ Logitech MX', 3000000, 15, 1);
    INSERT INTO product (name, price, quantity, active) VALUES ('Màn hình LG 27 inch 4K', 12000000, 8, 0);
END
GO

SELECT 'Database created successfully!' AS status;
GO
